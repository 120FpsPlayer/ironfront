/* =========================================================
   IRONFRONT — gränssnitt
   Titelskärm, hangar, butiker, inställningar, paus, draft och
   resultat. Ingen spellogik bor här: UI:t läser tillståndet,
   anropar Battle och lyssnar på bussen.
   ========================================================= */
import {
  ROBOTS, ROBOT_ORDER, WEAPONS, WEAPON_ORDER, DIFFICULTIES,
  sectorName, sectorLength, sectorIntro, mapForSector,
  GAME_MODES, MODE_ORDER, STORY_CHAPTERS, MULTI_MAX_PLAYERS, PAINTS, PAINT_ORDER,
  WEEKLY_MODS, WEEKLY_REWARD, WEEKLY_WAVES, weeklyChallenge, COOP_WAVES, TRIALS, dailyTrial, fmtRace,
  MAX_LEVEL, LEVEL_UNLOCKS, SLOT_LEVELS, unlockLevel, levelReward, TITLES, titleFor
} from './data.js';
import {
  state, save, load, hasSave, resetSave, makeSlot,
  canAfford, spend, addWeapon, ownsWeapon, selectedSlot,
  slotLevel, upgradePrice, EXTRA_MOUNT_PRICE, priceEmpty,
  slotPrice, slotUnlocked, buySlot, modesUnlocked, nextStoryChapter, chapterOpen,
  ownsPaint, slotColor, levelProgress, levelAllows, unlocksBetween, myTitle, loadFrom
} from './state.js';
import { Guide } from './guide.js';
import { createLobby, joinLobby, leaveLobby, onNet, myNetId, currentLobby, setReady, startMatch, serverUrl, setServerUrl, checkName, claimName, presence, activity, loginAccount, getTop } from './net.js';
import { cloudNow, cloud } from './cloud.js';
import { ensureDaily, dailyTemplate, checkStreak, streakReward, ACHIEVEMENTS, checkAchievements } from './progress.js';
import { weaponStats } from './entities.js';
import { RANK_LABEL } from './perks.js';
import { Battle } from './battle.js';
import { drawHangarMech, drawNameTag } from './render.js';
import { showCrosshair, toast } from './hud.js';
import * as Audio from './audio.js';
import { $, $$, el, bus, clamp, fmt, fmtTime, esc } from './util.js';

/* Tak för hur långt en uppgradering får drivas. */
const MAX_LVL = 12;

/* Baskostnader — priskurvan sköts av ECONOMY.upgradeCost. */
const COST = {
  hp: 900, shield: 1150, ability: 1250, speed: 820,
  dmg: 760, rate: 700, reload: 540, mag: 480
};

const KIND_LABEL = {
  slug: 'Kinetisk', rapid: 'Snabbeld', burst: 'Spridning',
  laser: 'Energi', shell: 'Granat', plasma: 'Plasma', missile: 'Robot'
};
const RANGE_LABEL = { close: 'Nära håll', balanced: 'Alla avstånd', long: 'Långt håll' };

let tab = 'bay';
let bayCtx = null, bayCanvas = null, bayT = 0, bayRaf = 0;
let menuCtx = null, menuCanvas = null, menuT = 0, menuRaf = 0, menuMech = null;
let draftOpen = false;
let lastSector = 1;
/* Senaste utryckningen — "Försök igen" på resultatskärmen startar samma sak. */
let lastRun = { mode: 'sectors', sector: 1, chapter: null };
let passHintShown = false;

/* =========================================================
   SKÄRMHANTERING
   ========================================================= */
const SCREENS = ['menu', 'profile', 'hangar', 'battle', 'result'];
let current = 'menu';

export function show(name){
  current = name;
  SCREENS.forEach(s => $('#screen-' + s).classList.toggle('on', s === name));
  showCrosshair(name === 'battle');
  document.body.style.cursor = name === 'battle' ? 'none' : '';

  stopMenuLoop();
  stopBayLoop();
  if (name === 'menu')   startMenuLoop();
  if (name === 'hangar'){
    startBayLoop(); refreshHangar(); requestAnimationFrame(maybeStartGuide); presence(lobbyPlayer());
    ensureDaily();
    const sk = checkStreak();
    if (sk) setTimeout(() => toast({ text: `Inloggningsbonus dag ${sk.days}: +${sk.reward.ag} Ag${sk.reward.au ? ' · +' + sk.reward.au + ' Au' : ''}${sk.reward.pl ? ' · +' + sk.reward.pl + ' Pl' : ''}`, kind: 'good' }), 700);
    checkAchievements();
    // Konton från före lösenorden: påminn en gång per session
    if (state.profile.verified && !state.profile.hasPass && !passHintShown && state.flags.tutorialDone){
      passHintShown = true;
      setTimeout(() => toast({ text: 'Tips: sätt ett lösenord under Konto i huvudmenyn — då kan du logga in och fortsätta på andra datorer.', kind: 'info' }), 1500);
    }
  }
  if (name !== 'hangar' && Guide.active && name !== 'battle') Guide.stop(true);
}

/* =========================================================
   SMÅ BYGGSTENAR
   ========================================================= */
function priceHtml(p){
  if (priceEmpty(p)) return '<span class="tag">Kostnadsfri</span>';
  const parts = [];
  if (p.ag) parts.push(`<span class="chip ag"><i class="pip"></i><b>${fmt(p.ag)}</b></span>`);
  if (p.au) parts.push(`<span class="chip au"><i class="pip"></i><b>${fmt(p.au)}</b></span>`);
  if (p.pl) parts.push(`<span class="chip pl"><i class="pip"></i><b>${fmt(p.pl)}</b></span>`);
  return parts.join(' ');
}

function statRow(k, v, cls = ''){
  return `<div class="stat"><span class="k">${esc(k)}</span><i class="dots"></i><span class="v ${cls}">${v}</span></div>`;
}

function barRow(k, pct, v){
  return `<div class="bar-row">
    <span class="k">${esc(k)}</span>
    <div class="meter seg"><div class="fill" style="width:${clamp(pct, 0, 1) * 100}%"></div></div>
    <span class="v">${v}</span>
  </div>`;
}

function click(node, fn){ node.addEventListener('click', e => { Audio.sfx('ui'); fn(e); }); return node; }

/* =========================================================
   MODAL
   ========================================================= */
let modalStack = [];

function openModal(title, sub, build, opts = {}){
  const m = $('#modal');
  $('#modalTitle').textContent = title;
  $('#modalSub').textContent = sub || '';
  const body = $('#modalBody');
  body.innerHTML = '';
  build(body);
  m.classList.add('on');
  modalStack = [{ title, sub, build }];
  m.dataset.wide = opts.wide ? '1' : '';
  m.dataset.kind = opts.kind || '';
  Audio.sfx('uiBig', { vol: .4 });
}

/** Ritar om den öppna modalen efter ett köp, så priser och nivåer stämmer. */
function refreshModal(){
  if (!modalStack.length || !$('#modal').classList.contains('on')) return;
  const { title, sub, build } = modalStack[0];
  const body = $('#modalBody');
  const scroll = body.scrollTop;
  body.innerHTML = '';
  build(body);
  body.scrollTop = scroll;
  $('#modalTitle').textContent = title;
  $('#modalSub').textContent = sub || '';
}

function closeModal(){ $('#modal').classList.remove('on'); modalStack = []; }

/** Enkel ja/nej-ruta. */
function confirmBox(title, text, onYes, yesLabel = 'Bekräfta'){
  openModal(title, 'BEKRÄFTA', body => {
    body.appendChild(el('p', 'note', esc(text)));
    const row = el('div', '', '');
    row.style.cssText = 'display:flex; gap:12px; margin-top:20px;';
    const no  = el('button', 'btn ghost', 'Avbryt');
    const yes = el('button', 'btn primary', esc(yesLabel));
    yes.style.flex = '1';
    click(no, closeModal);
    click(yes, () => { closeModal(); onYes(); });
    row.append(no, yes);
    body.appendChild(row);
  });
}

/* =========================================================
   TITELSKÄRM
   ========================================================= */
function bootMenu(){
  menuCanvas = $('#menuStage');
  menuCtx = menuCanvas.getContext('2d');

  $$('#menuNav button').forEach(b => {
    b.addEventListener('mouseenter', () => Audio.sfx('uiHover', { vol: .25 }));
    click(b, () => menuAction(b.dataset.act));
  });
}

function menuAction(act){
  switch (act){
    case 'continue':
      if (!hasSave()) { toast({ text: 'Ingen sparfil hittad — starta ett nytt spel', kind: 'bad' }); return; }
      load();
      // Äldre sparfiler utan namn får välja ett först
      if (!state.profile.name) openProfile(); else show('hangar');
      break;
    case 'new':
      if (hasSave()){
        confirmBox('Nytt spel', 'Det sparade spelet skrivs över. Robotar, vapen, nivå och framsteg nollställs och guiden börjar om. Ditt namn och inställningarna behålls.', () => {
          const keep = { ...state.profile };
          resetSave(true);
          state.profile = keep;
          save(true);
          openProfile();
        }, 'Skriv över');
      } else {
        resetSave(true);
        openProfile();
      }
      break;
    case 'profile':
      if (hasSave()) load();
      openProfile(true);
      break;
    case 'settings': openSettings(); break;
    case 'controls': openControls(); break;
    case 'credits':  openCredits();  break;
  }
}

function refreshMenu(){
  const saved = hasSave();
  $('#menuNav [data-act=continue]').disabled = !saved;
  if (saved){
    try{
      const raw = JSON.parse(localStorage.getItem('ironfront.save'));
      const sec = raw?.sector || 1;
      const kills = raw?.career?.kills || 0;
      const nm = raw?.profile?.name;
      const lv = raw?.level || 1;
      $('#menuSave').textContent = nm ? `${nm} · NIVÅ ${lv} · ${titleFor(lv).name.toUpperCase()}` : `SEKTOR ${sec} · ${fmt(kills)} NEDKÄMPADE`;
    }catch{ $('#menuSave').textContent = 'SPARFIL HITTAD'; }
  } else {
    $('#menuSave').textContent = 'INGEN SPARFIL';
  }
}

/* Bakgrunden på titelskärmen: teknisk väv, drivande partiklar och
   robotens siluett till höger. Allt ritas — inga bilder att ladda. */
function startMenuLoop(){
  refreshMenu();
  if (!menuMech){
    menuMech = document.createElement('canvas');
  }
  const step = () => {
    menuRaf = requestAnimationFrame(step);
    menuT += 1 / 60;
    drawMenuStage();
  };
  cancelAnimationFrame(menuRaf);
  menuRaf = requestAnimationFrame(step);
}
function stopMenuLoop(){ cancelAnimationFrame(menuRaf); menuRaf = 0; }

function fitCanvas(cv, ctx){
  const dpr = Math.min(devicePixelRatio || 1, 2);
  const w = cv.clientWidth || cv.parentElement.clientWidth;
  const h = cv.clientHeight || cv.parentElement.clientHeight;
  if (cv.width !== Math.round(w * dpr) || cv.height !== Math.round(h * dpr)){
    cv.width = Math.round(w * dpr);
    cv.height = Math.round(h * dpr);
  }
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  return { w, h };
}

function drawMenuStage(){
  const g = menuCtx;
  const { w, h } = fitCanvas(menuCanvas, g);
  g.clearRect(0, 0, w, h);

  // Horisontlinje med mjukt glöd — ger djup utan att ta uppmärksamhet
  const hz = h * 0.72;
  const grad = g.createLinearGradient(0, hz - 220, 0, hz + 120);
  grad.addColorStop(0, 'rgba(10,18,26,0)');
  grad.addColorStop(0.72, 'rgba(255,90,30,0.07)');
  grad.addColorStop(1, 'rgba(6,9,13,0)');
  g.fillStyle = grad;
  g.fillRect(0, hz - 220, w, 340);

  // Perspektivrutnät mot horisonten
  g.strokeStyle = 'rgba(74,108,140,0.16)';
  g.lineWidth = 1;
  const vx = w * 0.72;
  for (let i = -14; i <= 14; i++){
    g.beginPath();
    g.moveTo(vx + i * 70, hz);
    g.lineTo(vx + i * 420, h + 40);
    g.stroke();
  }
  for (let i = 1; i < 12; i++){
    const y = hz + Math.pow(i / 12, 2.4) * (h - hz + 40);
    g.globalAlpha = 0.5 - i * 0.03;
    g.beginPath(); g.moveTo(0, y); g.lineTo(w, y); g.stroke();
  }
  g.globalAlpha = 1;

  // Robotsiluett: samma ritrutin som i strid, så titelskärmen ljuger inte
  const slot = state.bays[state.selected] || state.bays.find(Boolean);
  const tpl = slot ? { ...ROBOTS[slot.tpl], color: slotColor(slot) } : ROBOTS.recon;
  const mw = Math.min(w * 0.62, 760), mh = Math.min(h * 0.92, 700);
  if (menuMech.width !== Math.round(mw) || menuMech.height !== Math.round(mh)){
    menuMech.width = Math.round(mw); menuMech.height = Math.round(mh);
  }
  const mg = menuMech.getContext('2d');
  drawHangarMech(mg, { w: mw, h: mh, tpl, t: menuT * 0.6, scale: 1.25 });
  g.save();
  g.globalAlpha = 0.9;
  g.drawImage(menuMech, w * 0.72 - mw / 2, hz - mh * 0.74, mw, mh);
  g.restore();

  // Drivande askpartiklar
  g.fillStyle = 'rgba(255,138,76,0.5)';
  for (let i = 0; i < 46; i++){
    const s = (i * 97.13) % 1;
    const x = ((s * w) + menuT * (8 + s * 22)) % (w + 40) - 20;
    const y = ((i * 53.7) % h + Math.sin(menuT * 0.5 + i) * 18 + menuT * 6) % h;
    const a = 0.12 + 0.28 * ((i * 31) % 7) / 7;
    g.globalAlpha = a;
    g.fillRect(x, y, 1.6, 1.6);
  }
  g.globalAlpha = 1;

  // Sveplinje — ett enda långsamt streck, som en sensorsvep
  const sweep = ((menuT * 0.16) % 1.4) * w - w * 0.2;
  const sg = g.createLinearGradient(sweep - 160, 0, sweep + 160, 0);
  sg.addColorStop(0, 'rgba(95,179,212,0)');
  sg.addColorStop(0.5, 'rgba(95,179,212,0.06)');
  sg.addColorStop(1, 'rgba(95,179,212,0)');
  g.fillStyle = sg;
  g.fillRect(sweep - 160, 0, 320, h);
}

/* =========================================================
   HANGAR
   ========================================================= */
function bootHangar(){
  bayCanvas = $('#bayStage');
  bayCtx = bayCanvas.getContext('2d');

  $$('#tabRail button').forEach(b => {
    b.addEventListener('mouseenter', () => Audio.sfx('uiHover', { vol: .22 }));
    click(b, () => setTab(b.dataset.tab));
  });

  click($('#btnSettings'), openSettings);
  click($('#btnMenu'), () => { save(true); show('menu'); });
  click($('#btnUpgrade'), openUpgrades);
  click($('#btnSell'), sellSelected);
  click($('#btnDeploy'), deploy);
  click($('#lvlBadge'), openLevelPath);
  // Meddelanden från adminsidan
  onNet('notice', m => toast({ text: '📢 ' + m.text, kind: 'info', ms: 9000 }));
  // Nivå upp visas på resultatskärmen; märket i toppraden uppdateras här
  bus.on('level:up', () => renderLevel());


  // På smala fönster ligger spec-panelen över scenen — ett klick
  // utanför den fäller ihop den igen.
  $('#bayStage').addEventListener('mousedown', () => {
    if (innerWidth <= 1040) $('#spec').classList.remove('open');
  });

  bus.on('state:changed', () => { if (current === 'hangar') refreshHangar(); refreshModal(); });
}

function refreshHangar(){
  const sector = state.sector;
  lastSector = sector;
  const map = mapForSector(sector);

  $('#opName').textContent = sector === 1 ? 'Träning — Sektor 1' : `Sektor ${sector} — ${sectorName(sector)}`;
  $('#opMap').textContent = map.name.toUpperCase();

  $('#curAg').textContent = fmt(state.currency.ag);
  $('#curAu').textContent = fmt(state.currency.au);
  $('#curPl').textContent = fmt(state.currency.pl);

  renderLevel();
  renderModes();
  renderDeploy();
  renderBays();
  renderSpec();
}

/* ---------- Nivåmärket i toppraden ---------- */
function renderLevel(){
  const lp = levelProgress();
  $('#lvlNum').textContent = lp.level;
  $('#lvlFill').style.width = (lp.level < 2 ? 0 : lp.pct * 100) + '%';
  $('#lvlXp').textContent = lp.level < 2 ? 'Klara träningen'
    : lp.max ? 'MAXNIVÅ' : `${fmt(lp.into)} / ${fmt(lp.need)} XP`;
}

/** Nivåvägen: alla nivåer och vad de låser upp. */
function openLevelPath(){
  const lp = levelProgress();
  openModal('Nivåer', `NIVÅ ${lp.level} AV ${MAX_LEVEL}`, body => {
    body.appendChild(el('p', 'lead-note', 'Du får XP i alla spellägen: mest när du vinner, hälften av grunden när du förlorar, inget om du lämnar. Varje ny nivå ger Argentum — och vissa nivåer låser upp nya robotar, vapen och robotplatser.'));
    const list = el('div', 'lvl-path');
    for (let L = 1; L <= MAX_LEVEL; L++){
      const u = L === 1 ? null : unlocksBetween(L - 1, L);
      if (L > 2 && !u.length && L !== lp.level && L !== lp.level + 1) continue;   // bara nivåer som ger något, plus där du står
      const r = el('div', 'lvl-row' + (L < lp.level ? ' done' : L === lp.level ? ' now' : ''));
      const what = L === 1 ? 'Start: RECON, Lätt kanon, Standardkanon'
        : L === 2 ? 'Ges direkt när träningen är klar · ' + u.map(x => x.name).join(', ')
        : u.length ? u.map(x => x.name).join(', ') : 'Belöning i Argentum';
      r.innerHTML = `<span class="lr-n">${L}</span><span class="lr-what">${esc(what)}</span>
        <span class="lr-state">${L < lp.level || (L === lp.level) ? '✓' : L === lp.level + 1 && !lp.max ? Math.round(lp.pct * 100) + ' %' : ''}</span>`;
      list.appendChild(r);
    }
    body.appendChild(list);
  }, { wide: true });
}

/* ---------- Spellägen och utskjutningslisten ---------- */
function currentMode(){ return modesUnlocked() ? state.mode : 'sectors'; }

function renderModes(){
  const wrap = $('#modeTabs');
  const open = modesUnlocked();
  const mode = currentMode();
  wrap.innerHTML = MODE_ORDER.map(id => {
    const m = GAME_MODES[id];
    const locked = !open && id !== 'sectors';
    const label = !open && id === 'sectors' ? 'Träning' : m.name;
    const sub = locked ? 'Klara Sektor 1' : !open && id === 'sectors' ? 'Lär dig grunderna' : m.short;
    return `<button class="mode${id === mode ? ' on' : ''}${locked ? ' locked' : ''}" data-mode="${id}" role="tab"
      aria-selected="${id === mode}" title="${esc(locked ? 'Låses upp när du klarat träningen (Sektor 1)' : m.short)}">
      <b>${locked ? '<i class="lock"></i>' : ''}${esc(label)}</b><span>${esc(sub)}</span></button>`;
  }).join('');
  $$('[data-mode]', wrap).forEach(b => b.addEventListener('click', () => pickMode(b.dataset.mode)));
}

function pickMode(id){
  if (!GAME_MODES[id]) return;
  if (!modesUnlocked() && id !== 'sectors'){
    toast({ text: 'Låses upp när du klarat träningen (Sektor 1)', kind: 'bad' });
    Audio.sfx('dry');
    return;
  }
  Audio.sfx('ui');
  state.mode = id;
  save();
  renderModes();
  renderDeploy();
}

function renderDeploy(){
  const mode = currentMode();
  const sector = state.sector;
  const prog = $('.deploy .progress');
  const btn = $('#btnDeploy');
  prog.style.visibility = '';

  if (mode === 'sectors'){
    const waves = sectorLength(sector);
    $('#depSector').textContent = sector === 1 ? 'TRÄNING · SEKTOR 1' : `SEKTOR ${sector} — ${sectorName(sector).toUpperCase()}`;
    $('#depDetail').textContent = sector === 1
      ? `${waves} vågor · instruktör i strid · slutboss`
      : `${waves} vågor · boss var 5:e våg · sektorsvakt sist`;
    const pct = clamp((sector - 1) / 15, 0, 1);
    $('#depFill').style.width = pct * 100 + '%';
    $('#depPct').textContent = sector === 1 ? '0%' : Math.round(pct * 100) + '%';
    btn.textContent = sector === 1 ? 'Starta träningen' : 'Skicka ut';
  } else if (mode === 'story'){
    const next = nextStoryChapter();
    const done = state.story.done.length;
    $('#depSector').textContent = next ? `STORY · KAPITEL ${next.id} — ${next.title.toUpperCase()}` : 'STORY · ALLA KAPITEL KLARA';
    $('#depDetail').textContent = next ? `${next.waves} vågor · handlingen fortsätter` : 'Spela om valfritt kapitel';
    const pct = done / STORY_CHAPTERS.length;
    $('#depFill').style.width = pct * 100 + '%';
    $('#depPct').textContent = `${done}/${STORY_CHAPTERS.length}`;
    btn.textContent = 'Välj kapitel';
  } else if (mode === 'trial'){
    $('#depSector').textContent = 'ARENA · BOSSRUSH · TIDSATTACK · DAGENS SEKTOR';
    $('#depDetail').textContent = 'Korta utmaningar med egna topplistor';
    prog.style.visibility = 'hidden';
    btn.textContent = 'Välj utmaning';
  } else if (mode === 'survival'){
    const rec = state.records?.survival;
    $('#depSector').textContent = 'ÖVERLEVNAD · OÄNDLIGA VÅGOR';
    $('#depDetail').textContent = rec ? `Ditt rekord: våg ${rec.wave} · ${fmt(rec.score)} poäng` : 'Hur långt kommer du? Boss var femte våg.';
    prog.style.visibility = 'hidden';
    btn.textContent = 'Starta överlevnad';
  } else if (mode === 'weekly'){
    const wk = weeklyChallenge();
    const done = state.weekly.id === wk.id && state.weekly.done;
    $('#depSector').textContent = `VECKANS UTMANING · VECKA ${wk.week}`;
    $('#depDetail').textContent = wk.mods.map(id => WEEKLY_MODS[id].name).join(' + ') + ` · ${WEEKLY_WAVES} vågor` + (done ? ' · klarad ✓' : '');
    prog.style.visibility = 'hidden';
    btn.textContent = 'Visa utmaningen';
  } else {
    $('#depSector').textContent = 'MULTIPLAYER';
    $('#depDetail').textContent = `Upp till ${MULTI_MAX_PLAYERS} spelare · gå med via kod`;
    prog.style.visibility = 'hidden';
    btn.textContent = 'Öppna lobby';
  }
}

function renderBays(){
  const wrap = $('#bays');
  wrap.innerHTML = '';
  for (let i = 0; i < 3; i++){
    const slot = state.bays[i];
    const locked = !slotUnlocked(i);
    const b = el('button', 'bay-slot' + (i === state.selected && slot ? ' on' : '') + (locked ? ' locked' : slot ? '' : ' empty'));
    b.dataset.idx = String(i);
    if (locked){
      const price = slotPrice(i);
      const need = SLOT_LEVELS[i];
      const lvlOk = state.level >= need;
      const buyable = lvlOk && i === state.slotsUnlocked;
      b.innerHTML = `<span class="idx"><i class="lock"></i></span>
        <span class="who"><b>PLATS ${i + 1} · LÅST</b><span>${buyable ? 'KÖP FÖR ' + priceText(price)
          : !lvlOk ? (need === 2 ? 'KLARA TRÄNINGEN' : 'LÅSES UPP PÅ NIVÅ ' + need) : 'KÖP PLATS ' + i + ' FÖRST'}</span></span>`;
      click(b, () => {
        if (!lvlOk){ toast({ text: need === 2 ? 'Robotplats 2 låses upp när du klarat träningen' : `Robotplats ${i + 1} låses upp på nivå ${need}`, kind: 'bad' }); return; }
        if (i !== state.slotsUnlocked){ toast({ text: `Köp plats ${i} först`, kind: 'bad' }); return; }
        openSlotPurchase(i);
      });
    } else if (slot){
      const tpl = ROBOTS[slot.tpl];
      b.innerHTML = `<span class="idx">${i + 1}</span>
        <span class="who"><b style="color:${tpl.color}">${esc(tpl.name)}</b><span>${esc(tpl.role.toUpperCase())} · NIVÅ ${slotLevel(slot)}</span></span>`;
      click(b, () => { state.selected = i; save(); refreshHangar(); });
    } else {
      b.innerHTML = `<span class="idx">+</span><span class="who"><b>TOM PLATS</b><span>TRYCK FÖR ATT KÖPA ROBOT</span></span>`;
      click(b, () => openRobotShop(i));
    }
    wrap.appendChild(b);
  }

  const slot = selectedSlot();
  if (slot){
    const tpl = ROBOTS[slot.tpl];
    $('#bayName').textContent = tpl.name;
    $('#bayRole').textContent = tpl.role;
    $('#bayLvl').textContent = slotLevel(slot);
  } else {
    $('#bayName').textContent = 'Ingen robot';
    $('#bayRole').textContent = 'köp en robot till den tomma platsen';
    $('#bayLvl').textContent = '—';
  }
  $('#btnUpgrade').disabled = !slot;
  $('#btnSell').disabled = !slot;
}

function priceText(p){
  if (priceEmpty(p)) return 'GRATIS';
  const out = [];
  if (p.ag) out.push(fmt(p.ag) + ' AG');
  if (p.au) out.push(fmt(p.au) + ' AU');
  if (p.pl) out.push(fmt(p.pl) + ' PL');
  return out.join(' + ');
}

/** Första lediga, upplåsta platsen — eller −1. */
function freeSlot(){
  for (let i = 0; i < state.slotsUnlocked; i++) if (!state.bays[i]) return i;
  return -1;
}

function openSlotPurchase(i){
  const price = slotPrice(i);
  openModal(`Robotplats ${i + 1}`, 'UTBYGGNAD AV HANGAREN', body => {
    body.innerHTML = `<p class="lead-note">En plats till betyder en robot till att välja mellan inför varje utryckning. Platsen är permanent.</p>
      <div class="price-line"><span>Pris</span>${priceHtml(price)}</div>`;
    const row = el('div', 'modal-actions');
    const no = el('button', 'btn ghost', 'Avbryt');
    const yes = el('button', 'btn primary', 'Köp plats');
    yes.disabled = !canAfford(price);
    if (!canAfford(price)) body.appendChild(el('p', 'note warn', 'Du har inte råd än. Spela en sektor till för att tjäna mer.'));
    click(no, closeModal);
    click(yes, () => {
      if (!buySlot(i)){ toast({ text: 'Har inte råd', kind: 'bad' }); Audio.sfx('dry'); return; }
      closeModal(); refreshHangar();
      toast({ text: `Robotplats ${i + 1} upplåst`, kind: 'good' });
      Audio.sfx('uiBig');
      Guide.signal('slot-unlocked');
    });
    row.append(no, yes);
    body.appendChild(row);
  });
}

function setTab(t){
  tab = t;
  $$('#tabRail button').forEach(x => x.classList.toggle('on', x.dataset.tab === t));
  renderSpec();
  $('#spec').classList.add('open');
}

/* ---------- Sidopanelen ---------- */
function renderSpec(){
  const body = $('#specBody');
  body.innerHTML = '';
  const showActions = tab === 'bay';
  $('.spec-actions').style.display = showActions ? '' : 'none';

  if (tab === 'bay')     specBay(body);
  if (tab === 'quests')  specQuests(body);
  if (tab === 'stats')   specStats(body);
  if (tab === 'arsenal') specArsenal(body);
  if (tab === 'top')     specTop(body);
}

/* ---------- Topplista ----------
   Hämtas från servern varje gång fliken öppnas. Fyra listor:
   nivå, högsta sektor, bästa poäng och veckans utmaning. */
let topKind = 'level';
const TOP_KINDS = [['level', 'Nivå'], ['sector', 'Sektor'], ['survival', 'Överlevn.'], ['score', 'Poäng'], ['weekly', 'Veckan']];
function specTop(body){
  const sec = el('section', 'spec-top');
  sec.innerHTML = '<h3>Topplista</h3>';
  const seg = el('div', 'top-seg');
  TOP_KINDS.forEach(([k, label]) => {
    const b = el('button', k === topKind ? 'on' : '', label);
    b.dataset.kind = k;
    click(b, () => { topKind = k; renderSpec(); });
    seg.appendChild(b);
  });
  sec.appendChild(seg);
  const list = el('div', 'top-list');
  list.innerHTML = '<p class="note">Hämtar…</p>';
  sec.appendChild(list);
  body.appendChild(sec);

  const kind = topKind;
  getTop(kind, state.profile.name).then(res => {
    if (tab !== 'top' || topKind !== kind || !list.isConnected && list.isConnected !== undefined) return;
    if (!res.ok){ list.innerHTML = '<p class="note warn">Kan inte nå servern just nu. Topplistan kräver att servern är igång.</p>'; return; }
    const unit = { level: 'NIVÅ', sector: 'SEKTOR', score: 'POÄNG', weekly: 'POÄNG', survival: 'VÅG' }[kind];
    const me = (state.profile.name || '').toLowerCase();
    const rows = res.rows.map((r, i) => {
      const t = kind === 'level' ? titleFor(r.value) : null;
      return `<div class="top-row${r.name.toLowerCase() === me ? ' me' : ''}${i < 3 ? ' podium p' + (i + 1) : ''}">
        <span class="tr-rank">${i + 1}</span>
        <span class="tr-name"><b>${esc(r.name)}</b>${t ? `<i style="color:${t.color}"${t.aura ? ' class="aura"' : ''}>${esc(t.name)}</i>` : `<i>${esc(r.extra || '')}</i>`}</span>
        <span class="tr-val">${fmt(r.value)}<small>${unit}</small></span></div>`;
    }).join('');
    list.innerHTML = (kind === 'weekly' ? `<p class="note">Veckans utmaning, ${esc(res.week || '')}. Nollställs varje måndag.</p>` : '')
      + (rows || '<p class="note">Ingen på listan än — bli först!</p>')
      + (res.me && res.me.rank > 50 ? `<div class="top-row me"><span class="tr-rank">${res.me.rank}</span><span class="tr-name"><b>${esc(res.me.name)}</b><i>Din placering</i></span><span class="tr-val">${fmt(res.me.value)}</span></div>` : '')
      + (!state.profile.verified ? '<p class="note warn">Du syns inte på listan förrän ditt namn är registrerat på servern (Konto i huvudmenyn).</p>' : '')
      + `<p class="note" style="margin-top:8px">${res.total} spelare totalt. Listan uppdateras när man sparar — efter varje utryckning.</p>`;
  });
}

function specBay(body){
  const slot = selectedSlot();
  if (!slot){
    body.innerHTML = '<section><h3>Ingen robot</h3><p class="lead-note">Du har ingen robot i den här platsen. Tryck på den tomma platsen nere i hangaren för att köpa en.</p></section>';
    const b = el('button', 'btn primary wide', 'Köp robot');
    click(b, () => openRobotShop(freeSlot()));
    body.firstChild.appendChild(b);
    return;
  }
  const tpl = ROBOTS[slot.tpl];
  const hp = Math.round(tpl.baseHp * (1 + slot.lvl.hp * 0.14));
  const speed = 3.1 * tpl.speed * (1 + slot.lvl.speed * 0.05);

  // Totalt DPS över alla montage
  let dps = 0;
  const mounts = slot.weapons.map((wid, i) => ({ wid, lvl: slot.mountLvls[i], i }));
  if (slot.extraUnlocked) mounts.push({ wid: slot.extraWeapon, lvl: slot.extraLvl, i: -1 });
  mounts.forEach(m => {
    const def = WEAPONS[m.wid];
    const st = weaponStats(def, m.lvl);
    dps += st.dmg / (st.fireRate / 1000);
  });

  const sec = el('section', 'spec-stats');
  sec.innerHTML = `
    <h3>Värden</h3>
    <p class="note" style="margin:-2px 0 12px">${esc(tpl.desc)}</p>
    <div class="bars">
      ${barRow('LIV',    hp / 7000,        fmt(hp))}
      ${barRow('SKADA',  dps / 3200,       fmt(dps) + '/s')}
      ${barRow('FART',   speed / 6.2,      speed.toFixed(2))}
      ${tpl.shield && tpl.shield.capacity
        ? barRow('SKÖLD', tpl.shield.capacity * (0.5 + slot.lvl.shield * 0.22) / 4000,
                 fmt(tpl.shield.capacity * (0.5 + slot.lvl.shield * 0.22)))
        : ''}
    </div>`;
  body.appendChild(sec);

  // Förmåga
  const ab = abilityLine(tpl, slot);
  if (ab){
    const a = el('section');
    a.innerHTML = `<h3>Förmåga</h3>
      <div class="mount" style="cursor:default">
        <span class="slotno">F</span>
        <span class="wname"><b>${esc(ab.name)}</b><span>${esc(ab.detail)}</span></span>
      </div>`;
    body.appendChild(a);
  }

  // Beväpning
  const w = el('section', 'spec-weapons');
  w.innerHTML = '<h3>Vapen</h3><p class="note" style="margin:-2px 0 10px">Tryck på ett vapen för att uppgradera eller byta det.</p>';
  const list = el('div', 'bars');
  slot.weapons.forEach((wid, i) => list.appendChild(mountRow(slot, i, wid, slot.mountLvls[i])));
  if (slot.extraUnlocked){
    list.appendChild(mountRow(slot, -1, slot.extraWeapon, slot.extraLvl));
  } else {
    const add = el('button', 'mount');
    add.innerHTML = `<span class="slotno">+</span>
      <span class="wname"><b>Extra montage</b><span>LÅS UPP · ${EXTRA_MOUNT_PRICE.au} AU</span></span>
      <span class="plus">＋</span>`;
    click(add, () => {
      if (!canAfford(EXTRA_MOUNT_PRICE)){ toast({ text: 'För lite Aurum', kind: 'bad' }); return; }
      confirmBox('Extra montage', `Svetsa fast ett tredje fäste på ${ROBOTS[slot.tpl].name}. Kostar ${EXTRA_MOUNT_PRICE.au} Aurum och går inte att ångra.`, () => {
        if (spend(EXTRA_MOUNT_PRICE)){
          slot.extraUnlocked = true;
          save(); refreshHangar();
          toast({ text: 'Montage installerat', kind: 'good' });
        }
      }, 'Installera');
    });
    list.appendChild(add);
  }
  w.appendChild(list);
  body.appendChild(w);

  // Lackering — bara utseende, betalas med Platina
  const pt = el('section', 'spec-paint');
  const cur = PAINTS[slot.paint] || PAINTS.standard;
  pt.innerHTML = `<h3>Lackering</h3>`;
  const row = el('button', 'mount paint-row');
  row.innerHTML = `<span class="swatch" style="background:${slotColor(slot)}"></span>
    <span class="wname"><b>${esc(cur.name)}</b><span>BARA UTSEENDE · BETALAS MED PLATINA</span></span>
    <span class="plus">›</span>`;
  click(row, () => openPaintShop(slot));
  pt.appendChild(row);
  body.appendChild(pt);
}

/** Egen meny för lackeringar: en rad per färg, med förhandsvisning. */
function openPaintShop(slot){
  const tpl = ROBOTS[slot.tpl];
  openModal('Lackering', tpl.name, body => {
    body.appendChild(el('p', 'lead-note', 'Lackeringen ändrar bara hur roboten ser ut, i hangaren och i strid. En köpt lackering kan läggas på alla dina robotar. Platina tjänar du på uppdrag, sektorsvakter och veckans utmaning.'));
    const list = el('div', 'wpn-list');
    PAINT_ORDER.forEach(id => {
      const p = PAINTS[id];
      const has = ownsPaint(id);
      const on = slot.paint === id;
      const color = p.color || tpl.color;
      const r = el('div', 'wpn-row paint' + (on ? ' on' : '') + (has || canAfford(p.price) ? '' : ' blocked'));
      r.dataset.paint = id;
      r.innerHTML = `
        <span class="swatch big" style="background:${color}"></span>
        <span class="wr-name"><b>${esc(p.name)}</b><span>${esc(p.desc)}</span></span>
        <span class="wr-buy"><span class="wr-price">${on ? '<span class="tag hot">PÅ ROBOTEN</span>' : has ? '<span class="tag" style="color:var(--ok)">ÄGS</span>' : priceHtml(p.price)}</span></span>`;
      if (!on){
        const b = el('button', 'btn ' + (has ? 'primary' : 'accent') + ' sm', has ? 'Lackera' : 'Köp och lackera');
        click(b, () => {
          if (!has){
            if (!spend(p.price)){ toast({ text: 'För lite Platina', kind: 'bad' }); Audio.sfx('dry'); return; }
            state.ownedPaints.push(id);
          }
          slot.paint = id;
          save(); refreshHangar(); refreshModal();
          toast({ text: `${tpl.name} lackerad: ${p.name}`, kind: 'good' });
          Audio.sfx('uiBig');
        });
        r.querySelector('.wr-buy').appendChild(b);
      }
      list.appendChild(r);
    });
    body.appendChild(list);
  }, { wide: true });
}

function abilityLine(tpl, slot){
  const l = slot.lvl.ability;
  if (tpl.shield?.type === 'purple')
    return { name: 'Prismasköld', detail: `${(tpl.shield.duration * (1 + l * 0.09) / 1000).toFixed(1)} s oskadd · ${(tpl.shield.cooldown * (1 - l * 0.07) / 1000).toFixed(0)} s omladdning` };
  if (tpl.dash)
    return { name: 'Kastdrift', detail: `${(tpl.dash.cooldown * (1 - l * 0.07) / 1000).toFixed(0)} s omladdning · sårbar efteråt` };
  if (tpl.overdrive)
    return { name: 'Överladdning', detail: `${(tpl.overdrive.duration * (1 + l * 0.09) / 1000).toFixed(1)} s dubbel eldhastighet` };
  if (tpl.special)
    return { name: tpl.special.name.charAt(0) + tpl.special.name.slice(1).toLowerCase(), detail: tpl.special.text + ` · laddar om på ${Math.round(tpl.special.cooldown * (1 - l * 0.07) / 1000)} s` };
  if (tpl.scan)
    return { name: 'Sensorpuls', detail: `Märker alla fiender i ${(tpl.scan.duration * (1 + l * 0.09) / 1000).toFixed(1)} s · +${Math.round(tpl.scan.dmgBonus * 100)} % skada mot dem` };
  if (tpl.shield)
    return { name: tpl.shield.type === 'gold' ? 'Guldsköld' : 'Blå sköld', detail: `Laddar om ${(tpl.shield.regenDelay / 1000).toFixed(1)} s efter senaste träff` };
  return null;
}

function mountRow(slot, idx, wid, lvl){
  const def = WEAPONS[wid];
  const st = weaponStats(def, lvl);
  const lv = lvl.dmg + lvl.rate + lvl.reload + lvl.mag;
  const row = el('button', 'mount');
  row.innerHTML = `<span class="slotno">${idx < 0 ? 'X' : idx + 1}</span>
    <span class="wname"><b>${esc(def.name)}</b><span>${fmt(st.dmg)} SKD · ${(1000 / st.fireRate).toFixed(1)}/S · MAG ${st.mag}${lv ? ' · +' + lv : ''}</span></span>
    <span class="plus">›</span>`;
  click(row, () => openWeaponMenu(slot, idx));
  return row;
}

/* ---------- Order ---------- */
function specQuests(body){
  // Dagliga uppdrag
  if (state.level >= 2){
    ensureDaily();
    const d = el('section', 'spec-daily');
    const left = (() => { const n = new Date(); const m = new Date(n); m.setHours(24, 0, 0, 0); const ms = m - n; return `${Math.floor(ms / 3600000)} h ${Math.floor(ms / 60000) % 60} min`; })();
    d.innerHTML = `<h3>Dagliga uppdrag</h3><p class="note" style="margin:-2px 0 10px">Nya uppdrag om ${left}. Klara uppdrag ger XP och Argentum direkt.</p>`;
    for (const m of state.daily.list){
      const t = dailyTemplate(m.id);
      if (!t) continue;
      const r = el('div', 'daily' + (m.done ? ' done' : ''));
      r.innerHTML = `<span class="box">${m.done ? '✓' : ''}</span>
        <span class="dl-body"><b>${esc(t.text(m.n))}</b>
          <span class="meter"><span class="fill" style="width:${Math.round(m.progress / m.n * 100)}%"></span></span></span>
        <span class="dl-side"><i>${fmt(m.progress)} / ${fmt(m.n)}</i><span class="reward">+${t.xp} XP</span></span>`;
      d.appendChild(r);
    }
    body.appendChild(d);

    // Inloggningsbonus
    const st = state.streak;
    const sb = el('section', 'spec-streak');
    const days = [];
    for (let k = 1; k <= 7; k++){
      const rw = streakReward(k);
      days.push(`<span class="sk${k <= (st.days || 0) ? ' on' : ''}${k === 7 ? ' big' : ''}" title="Dag ${k}: +${rw.ag} Ag${rw.au ? ' · +' + rw.au + ' Au' : ''}${rw.pl ? ' · +' + rw.pl + ' Pl' : ''}">${k}</span>`);
    }
    sb.innerHTML = `<h3>Inloggningsbonus</h3>
      <p class="note" style="margin:-2px 0 8px">${st.days || 0} ${st.days === 1 ? 'dag' : 'dagar'} i rad${st.best > 1 ? ` · bästa: ${st.best}` : ''}. Spela varje dag för större belöning — från dag 7 även Platina.</p>
      <div class="streak">${days.join('')}</div>`;
    body.appendChild(sb);
  }

  // Prestationer
  const got = ACHIEVEMENTS.filter(a => state.achievements[a.id]).length;
  const ach = el('section', 'spec-ach');
  ach.innerHTML = `<h3>Prestationer <span class="tag" style="margin-left:auto">${got} / ${ACHIEVEMENTS.length}</span></h3>`;
  const list = [...ACHIEVEMENTS].sort((a, b) => !!state.achievements[a.id] - !!state.achievements[b.id]);
  for (const a of list){
    const done = !!state.achievements[a.id];
    const pr = !done && a.prog ? a.prog() : null;
    const rw = a.reward || {};
    const r = el('div', 'ach' + (done ? ' done' : ''));
    r.innerHTML = `<span class="ach-icon">${done ? '🏆' : '·'}</span>
      <span class="ach-body"><b>${esc(a.name)}</b><span>${esc(a.text)}</span>
        ${pr ? `<span class="meter"><span class="fill" style="width:${Math.min(100, Math.round(pr[0] / pr[1] * 100))}%"></span></span>` : ''}</span>
      <span class="reward">${rw.pl ? '+' + rw.pl + ' Pl' : ''}${rw.paint ? '<br>' + esc(PAINTS[rw.paint].name) : ''}</span>`;
    ach.appendChild(r);
  }
  body.appendChild(ach);

  // Stående order (de gamla engångsordrarna)
  const q = state.quests;
  const items = [
    { k: 'noDamage5', t: 'Klara fem vågor utan att ta skada', r: '+1 Pl' },
    { k: 'wave10',    t: 'Nå våg 10 i en och samma utryckning', r: '+1 Pl' },
    { k: 'sector2',   t: 'Rensa sektor 2', r: '+30 Au' },
    { k: 'bossSolo',  t: 'Fäll en boss utan att ladda om', r: '+1 Pl' }
  ];
  const sec = el('section');
  sec.innerHTML = '<h3>Stående order</h3>';
  items.forEach(it => {
    const d = el('div', 'quest' + (q[it.k] ? ' done' : ''));
    d.innerHTML = `<span class="box">${q[it.k] ? '✓' : ''}</span><span>${esc(it.t)}</span><span class="reward">${esc(it.r)}</span>`;
    sec.appendChild(d);
  });
  body.appendChild(sec);
}

/* ---------- Krigsdagbok ---------- */
function specStats(body){
  const c = state.career;
  const sec = el('section');
  sec.innerHTML = `<h3>Krigsdagbok</h3>
    ${statRow('Utryckningar', fmt(c.runs))}
    ${statRow('Nedkämpade', fmt(c.kills))}
    ${statRow('Vågor hållna', fmt(c.waves))}
    ${statRow('Bossar fällda', fmt(c.bosses))}
    ${statRow('Skada gjord', fmt(c.damage))}
    ${statRow('Tid i fält', fmtTime(c.ms))}
    ${statRow('Bästa våg', fmt(state.bestWave))}
    ${statRow('Högsta poäng', fmt(state.bestScore))}`;
  body.appendChild(sec);

  // Rekord per spelläge
  const r = state.records || {};
  const rec = el('section');
  const line = (k, label) => r[k]
    ? statRow(label, `${fmt(r[k].score)} p · våg ${r[k].wave}${r[k].sector ? ' · sektor ' + r[k].sector : ''}`)
    : statRow(label, '—');
  rec.innerHTML = `<h3>Rekord</h3>
    ${line('sectors', 'Sektorer')}
    ${line('story', 'Story')}
    ${line('weekly', 'Utmaning')}
    ${statRow('Denna vecka', state.weekly.id === weeklyChallenge().id
      ? (state.weekly.done ? 'Klarad ✓' : `Bäst våg ${state.weekly.best} / ${WEEKLY_WAVES}`) : 'Inte spelad')}`;
  body.appendChild(rec);

}

/* ---------- Arsenal ---------- */
function specArsenal(body){
  const sec = el('section');
  sec.innerHTML = '<h3>Robotar</h3><p class="note" style="margin:-2px 0 10px">Tryck på en robot för att se den och köpa den till en ledig plats.</p>';
  const g1 = el('div', 'bars');
  ROBOT_ORDER.forEach(id => {
    const tpl = ROBOTS[id];
    const owned = state.bays.some(b => b && b.tpl === id);
    const row = el('button', 'mount');
    row.innerHTML = `<span class="slotno" style="color:${tpl.color}">◆</span>
      <span class="wname"><b>${esc(tpl.name)}</b><span>${esc(tpl.role.toUpperCase())}</span></span>
      <span class="plus" style="font-size:11px; font-family:var(--font-data); color:${owned ? 'var(--ok)' : 'var(--ink-3)'}">${owned ? 'I FLOTTAN' : levelAllows('robots', id) ? 'TILL SALU' : 'NIVÅ ' + unlockLevel('robots', id)}</span>`;
    click(row, () => openRobotShop(freeSlot(), id));
    g1.appendChild(row);
  });
  sec.appendChild(g1);
  body.appendChild(sec);

  const sec2 = el('section');
  sec2.innerHTML = '<h3>Vapen</h3><p class="note" style="margin:-2px 0 10px">Köpta vapen kan monteras på alla dina robotar.</p>';
  const g2 = el('div', 'bars');
  WEAPON_ORDER.forEach(id => {
    const def = WEAPONS[id];
    const owned = ownsWeapon(id);
    const row = el('button', 'mount');
    row.innerHTML = `<span class="slotno">${esc((KIND_LABEL[def.kind] || '?')[0])}</span>
      <span class="wname"><b>${esc(def.name)}</b><span>${fmt(def.dmg)} SKD · ${esc(RANGE_LABEL[def.range])}</span></span>
      <span class="plus" style="font-size:11px; font-family:var(--font-data); color:${owned ? 'var(--ok)' : 'var(--ink-3)'}">${owned ? 'ÄGS' : levelAllows('weapons', id) ? 'KÖP' : 'NIVÅ ' + unlockLevel('weapons', id)}</span>`;
    click(row, () => openWeaponShop(id));
    g2.appendChild(row);
  });
  sec2.appendChild(g2);
  body.appendChild(sec2);
}

/* =========================================================
   BUTIKER OCH UPPGRADERINGAR
   ========================================================= */
function openRobotShop(bayIndex, focusId = null){
  const target = bayIndex >= 0 && slotUnlocked(bayIndex) && !state.bays[bayIndex] ? bayIndex : freeSlot();
  openModal('Robotdepå', target >= 0 ? `KÖPER TILL PLATS ${target + 1}` : 'INGEN LEDIG PLATS', body => {
    if (target < 0)
      body.appendChild(el('p', 'note warn', state.slotsUnlocked < 3
        ? 'Alla dina platser är upptagna. Köp en ny robotplats i hangaren, eller skrota en robot för att göra plats.'
        : 'Alla tre platser är upptagna. Skrota en robot i hangaren för att göra plats.'));

    const grid = el('div', 'grid c3');
    const order = focusId ? [focusId, ...ROBOT_ORDER.filter(i => i !== focusId)] : ROBOT_ORDER;
    order.forEach(id => {
      const tpl = ROBOTS[id];
      const owned = state.bays.some(b => b && b.tpl === id);
      const lvlOk = levelAllows('robots', id);
      const afford = canAfford(tpl.price) && lvlOk;
      const card = el('div', 'card' + (owned ? ' locked' : '') + (afford || owned ? '' : ' blocked') + (lvlOk ? '' : ' lvl-locked'));
      card.dataset.robot = id;
      card.innerHTML = `
        <h4 style="color:${tpl.color}">${esc(tpl.name)}</h4>
        <div class="role">${esc(tpl.role)}</div>
        <p style="margin:10px 0 12px">${esc(tpl.desc)}</p>
        ${statRow('Skrov', fmt(tpl.baseHp))}
        ${statRow('Fart', tpl.speed.toFixed(2))}
        ${statRow('Montage', tpl.mounts.length)}
        ${statRow('Sköld', tpl.shield ? (tpl.shield.type === 'purple' ? 'Prisma' : tpl.shield.type === 'gold' ? 'Guld' : 'Blå') : '—')}
        <div style="margin-top:14px; display:flex; align-items:center; gap:8px; flex-wrap:wrap">
          ${owned ? '<span class="tag" style="color:var(--ok)">I FLOTTAN</span>'
            : !lvlOk ? `<span class="lvl-lock"><i class="lock"></i>NIVÅ ${unlockLevel('robots', id)}</span>` : priceHtml(tpl.price)}
          ${!owned && lvlOk && target >= 0 ? `<span class="buy-cta">${afford ? 'Köp' : 'För dyr'}</span>` : ''}
        </div>`;
      if (!owned && target >= 0){
        click(card, () => {
          if (!lvlOk){ toast({ text: `${tpl.name} låses upp på nivå ${unlockLevel('robots', id)}`, kind: 'bad' }); Audio.sfx('dry'); return; }
          if (!canAfford(tpl.price)){ toast({ text: 'Har inte råd', kind: 'bad' }); Audio.sfx('dry'); return; }
          if (!spend(tpl.price)) return;
          state.bays[target] = makeSlot(id);
          state.selected = target;
          addWeapon(tpl.defaultWeapon, true);
          save(); closeModal(); refreshHangar();
          toast({ text: `${tpl.name} dockad i plats ${target + 1}`, kind: 'good' });
          Audio.sfx('uiBig');
          Guide.signal('robot-bought');
        });
      }
      grid.appendChild(card);
    });
    body.appendChild(grid);
  }, { wide: true });
}

function openWeaponShop(focusId){
  const def = WEAPONS[focusId];
  if (ownsWeapon(focusId)){
    openModal(def.name, 'ÄGS REDAN', body => {
      body.appendChild(el('p', 'note', esc(def.desc)));
      body.insertAdjacentHTML('beforeend', weaponSpecHtml(def));
      body.insertAdjacentHTML('beforeend',
        '<p class="note" style="margin-top:14px">Montera vapnet i hangaren genom att klicka på ett montage.</p>');
    });
    return;
  }
  if (!levelAllows('weapons', focusId)){
    openModal(def.name, `LÅSES UPP PÅ NIVÅ ${unlockLevel('weapons', focusId)}`, body => {
      body.appendChild(el('p', 'note', esc(def.desc)));
      body.insertAdjacentHTML('beforeend', weaponSpecHtml(def));
      body.appendChild(el('p', 'note warn', `Nå nivå ${unlockLevel('weapons', focusId)} för att kunna köpa vapnet. Du får XP genom att spela.`));
    });
    return;
  }
  openModal(def.name, 'INKÖP', body => {
    body.appendChild(el('p', 'note', esc(def.desc)));
    body.insertAdjacentHTML('beforeend', weaponSpecHtml(def));
    const row = el('div');
    row.style.cssText = 'display:flex; align-items:center; gap:12px; margin-top:18px';
    row.innerHTML = priceHtml(def.price);
    const buy = el('button', 'btn primary', 'Köp');
    buy.style.marginLeft = 'auto';
    buy.disabled = !canAfford(def.price);
    click(buy, () => {
      if (!spend(def.price)){ toast({ text: 'Har inte råd', kind: 'bad' }); return; }
      addWeapon(focusId);
      closeModal(); refreshHangar();
      toast({ text: `${def.name} tillagd i arsenalen`, kind: 'good' });
    });
    row.appendChild(buy);
    body.appendChild(row);
  });
}

function weaponSpecHtml(def){
  return `<div style="margin-top:14px">
    ${statRow('Typ', esc(KIND_LABEL[def.kind] || def.kind))}
    ${statRow('Skada', fmt(def.dmg))}
    ${statRow('Skott per sekund', (1000 / def.fireRate).toFixed(2))}
    ${statRow('Magasin', def.mag)}
    ${statRow('Omladdning', (def.reload / 1000).toFixed(1) + ' s')}
    ${statRow('Räckviddsprofil', esc(RANGE_LABEL[def.range]))}
    ${statRow('Ammunition', def.ammo === 'special' ? 'Specialammo' : 'Standard')}
  </div>`;
}

/* ---------------------------------------------------------
   VAPENMENYN
   Ett montage i taget, och en sak i taget: den här menyn
   innehåller BARA uppgraderingar av det monterade vapnet.
   Vill man byta vapen öppnas en helt egen meny.
   --------------------------------------------------------- */
function mountTitle(idx){ return idx < 0 ? 'Extra montage' : `Montage ${idx + 1}`; }

function openWeaponMenu(slot, idx){
  const build = body => {
    const wid = idx < 0 ? slot.extraWeapon : slot.weapons[idx];
    const lvl = idx < 0 ? slot.extraLvl : slot.mountLvls[idx];
    const def = WEAPONS[wid];
    const st = weaponStats(def, lvl);

    // Vad som sitter i montaget just nu
    const head = el('div', 'mount-head');
    head.innerHTML = `
      <div class="mh-left">
        <span class="tag">MONTERAT VAPEN</span>
        <b>${esc(def.name)}</b>
        <span class="mh-kind">${esc(KIND_LABEL[def.kind])} · ${esc(RANGE_LABEL[def.range])}</span>
      </div>
      <div class="mh-stats">
        ${statRow('Skada', fmt(st.dmg), lvl.dmg ? 'up' : '')}
        ${statRow('Skott/sek', (1000 / st.fireRate).toFixed(2), lvl.rate ? 'up' : '')}
        ${statRow('Magasin', st.mag, lvl.mag ? 'up' : '')}
        ${statRow('Omladdning', (st.reload / 1000).toFixed(2) + ' s', lvl.reload ? 'up' : '')}
      </div>`;
    const swap = el('button', 'btn accent btn-swap', 'Byt vapen →');
    click(swap, () => openWeaponSwap(slot, idx));
    head.querySelector('.mh-left').appendChild(swap);
    body.appendChild(head);

    body.appendChild(el('h3', 'modal-sec', 'UPPGRADERINGAR AV DET HÄR VAPNET'));
    const list = el('div', 'up-list');
    [
      ['dmg',    'Skadeladdning', '+16 % skada per skott'],
      ['rate',   'Matarverk',     '+9 % eldhastighet'],
      ['mag',    'Magasin',       '+15 % fler skott i magasinet'],
      ['reload', 'Omladdare',     '−7 % omladdningstid']
    ].forEach(([key, name, eff]) => list.appendChild(
      upgradeRow(name, eff, lvl[key], COST[key], () => { lvl[key]++; save(); })));
    body.appendChild(list);
    body.appendChild(el('p', 'note', 'Uppgraderingarna sitter i montaget, inte i vapnet — byter du vapen följer nivåerna med.'));
  };
  openModal(mountTitle(idx), 'UPPGRADERA VAPNET', build);
}

/** Helt egen meny: bara att välja, köpa och montera vapen. */
function openWeaponSwap(slot, idx){
  const build = body => {
    const wid = idx < 0 ? slot.extraWeapon : slot.weapons[idx];
    body.appendChild(el('p', 'lead-note', 'Välj vilket vapen som ska sitta i montaget. Ett köpt vapen kan monteras på alla dina robotar, hur många gånger du vill.'));
    const list = el('div', 'wpn-list');
    WEAPON_ORDER.forEach(id => {
      const w = WEAPONS[id];
      const has = ownsWeapon(id);
      const on = id === wid;
      const lvlOk = has || levelAllows('weapons', id);
      const row = el('div', 'wpn-row' + (on ? ' on' : '') + (has || (lvlOk && canAfford(w.price)) ? '' : ' blocked'));
      row.dataset.weapon = id;
      row.innerHTML = `
        <span class="wr-kind">${esc((KIND_LABEL[w.kind] || '?')[0])}</span>
        <span class="wr-name">
          <b>${esc(w.name)}</b>
          <span>${esc(KIND_LABEL[w.kind])} · ${esc(RANGE_LABEL[w.range])}</span>
        </span>
        <span class="wr-stats">
          <i>${fmt(w.dmg)}</i><small>SKADA</small>
        </span>
        <span class="wr-stats">
          <i>${(1000 / w.fireRate).toFixed(1)}</i><small>SKOTT/S</small>
        </span>
        <span class="wr-stats">
          <i>${w.mag}</i><small>MAGASIN</small>
        </span>
        <span class="wr-buy">
          <span class="wr-price">${on ? '<span class="tag hot">MONTERAT</span>' : has ? '<span class="tag" style="color:var(--ok)">ÄGS</span>'
            : !lvlOk ? `<span class="lvl-lock"><i class="lock"></i>NIVÅ ${unlockLevel('weapons', id)}</span>` : priceHtml(w.price)}</span>
        </span>`;
      if (!on && lvlOk){
        const b = el('button', 'btn ' + (has ? 'primary' : 'accent') + ' sm', has ? 'Montera' : 'Köp och montera');
        click(b, () => {
          if (!has){
            if (!canAfford(w.price)){ toast({ text: 'Har inte råd', kind: 'bad' }); Audio.sfx('dry'); return; }
            if (!spend(w.price)) return;
            addWeapon(id);
            toast({ text: `${w.name} inköpt`, kind: 'good' });
          }
          if (idx < 0) slot.extraWeapon = id; else slot.weapons[idx] = id;
          save(); refreshHangar();
          toast({ text: `${w.name} monterad i ${mountTitle(idx).toLowerCase()}`, kind: 'good' });
          Audio.sfx('uiBig');
          openWeaponMenu(slot, idx);
        });
        row.querySelector('.wr-buy').appendChild(b);
      }
      list.appendChild(row);
    });
    body.appendChild(list);
    const row = el('div', 'modal-actions');
    const back = el('button', 'btn ghost', '← Tillbaka till uppgraderingar');
    click(back, () => openWeaponMenu(slot, idx));
    row.appendChild(back);
    body.appendChild(row);
  };
  openModal('Byt vapen', mountTitle(idx).toUpperCase(), build, { wide: true });
}

/** Skrovuppgraderingar för vald robot. */
function openUpgrades(){
  const slot = selectedSlot();
  if (!slot) return;
  const tpl = ROBOTS[slot.tpl];

  openModal(`Uppgradera ${tpl.name}`, `SAMLAD NIVÅ ${slotLevel(slot)}`, body => {
    body.appendChild(el('p', 'lead-note', 'Här uppgraderar du själva roboten — en uppgradering i taget. Allt du köper här sitter kvar för alltid. Vapnen sköts i vapenmenyn.'));
    const list = el('div', 'up-list');
    list.appendChild(upgradeRow('Pansarplåt', '+14 % mer liv', slot.lvl.hp, COST.hp, () => { slot.lvl.hp++; save(); }));
    list.appendChild(upgradeRow('Ställdon', '+5 % rörelsehastighet', slot.lvl.speed, COST.speed, () => { slot.lvl.speed++; save(); }));
    if (tpl.shield && tpl.shield.capacity)
      list.appendChild(upgradeRow('Sköldgenerator', '+22 % sköldkapacitet', slot.lvl.shield, COST.shield, () => { slot.lvl.shield++; save(); }));
    if (tpl.dash || tpl.overdrive || tpl.scan || tpl.special || tpl.shield?.type === 'purple')
      list.appendChild(upgradeRow('Förmågekärna', 'Kortare omladdning, längre effekt', slot.lvl.ability, COST.ability, () => { slot.lvl.ability++; save(); }));
    body.appendChild(list);
  });
}

/** En uppgradering per rad: vad den gör, vilken nivå den är på, vad nästa kostar. */
function upgradeRow(name, eff, lvl, base, apply){
  const maxed = lvl >= MAX_LVL;
  const price = upgradePrice(base, lvl);
  const afford = canAfford(price);
  const row = el('div', 'up-row' + (maxed ? ' maxed' : afford ? '' : ' blocked'));
  row.innerHTML = `
    <span class="ur-info">
      <b>${esc(name)}</b>
      <span>${esc(eff)}</span>
    </span>
    <span class="ur-lvl">
      <span class="tag">NIVÅ ${lvl} / ${MAX_LVL}</span>
      <span class="meter seg"><span class="fill" style="width:${lvl / MAX_LVL * 100}%"></span></span>
    </span>
    <span class="ur-buy"><span class="ur-price">${maxed ? '<span class="tag" style="color:var(--ok)">MAXAD</span>' : priceHtml(price)}</span></span>`;
  if (!maxed){
    const b = el('button', 'btn primary sm', 'Uppgradera');
    b.disabled = !afford;
    click(b, () => {
      if (!canAfford(price)){ toast({ text: 'Har inte råd', kind: 'bad' }); Audio.sfx('dry'); return; }
      if (!spend(price)) return;
      apply();
      refreshHangar(); refreshModal();
      Audio.sfx('uiBig', { vol: .5 });
    });
    row.querySelector('.ur-buy').appendChild(b);
  }
  return row;
}

function upgradeCard(name, eff, lvl, base, apply){
  const maxed = lvl >= MAX_LVL;
  const price = upgradePrice(base, lvl);
  const card = el('div', 'card' + (maxed ? ' locked' : canAfford(price) ? '' : ' blocked'));
  card.innerHTML = `
    <div style="display:flex; align-items:baseline; gap:8px">
      <h4>${esc(name)}</h4>
      <span class="tag" style="margin-left:auto">NIVÅ ${lvl}/${MAX_LVL}</span>
    </div>
    <div class="meter seg" style="margin:9px 0 10px"><div class="fill" style="width:${lvl / MAX_LVL * 100}%"></div></div>
    <p>${esc(eff)}</p>
    <div class="card-foot">${maxed ? '<span class="tag" style="color:var(--ok)">MAXAD</span>' : priceHtml(price) + `<span class="buy-cta">${canAfford(price) ? 'Uppgradera' : 'För dyr'}</span>`}</div>`;
  if (!maxed){
    click(card, () => {
      if (!canAfford(price)){ toast({ text: 'Har inte råd', kind: 'bad' }); Audio.sfx('dry'); return; }
      if (!spend(price)) return;
      apply();
      refreshHangar(); refreshModal();
      Audio.sfx('uiBig', { vol: .5 });
    });
  }
  return card;
}

function sellSelected(){
  const i = state.selected;
  const slot = state.bays[i];
  if (!slot) return;
  if (state.bays.filter(Boolean).length <= 1){
    toast({ text: 'Du kan inte skrota din sista robot', kind: 'bad' });
    return;
  }
  const tpl = ROBOTS[slot.tpl];
  const back = {
    ag: Math.round((tpl.price.ag || 0) * 0.5),
    au: Math.round((tpl.price.au || 0) * 0.5),
    pl: Math.round((tpl.price.pl || 0) * 0.5)
  };
  confirmBox('Skrota enhet',
    `${tpl.name} demonteras. Du får tillbaka hälften av inköpspriset. Uppgraderingarna försvinner.`,
    () => {
      state.bays[i] = null;
      state.selected = state.bays.findIndex(Boolean);
      state.currency.ag += back.ag; state.currency.au += back.au; state.currency.pl += back.pl;
      save(true); refreshHangar();
      toast({ text: `${tpl.name} skrotad`, kind: '' });
    }, 'Skrota');
}

/* =========================================================
   INSTÄLLNINGAR, STYRNING, OM SPELET
   ========================================================= */
function sliderRow(label, hint, key, min, max, step, fmtVal){
  const row = el('div', 'row');
  row.innerHTML = `<div class="label"><b>${esc(label)}</b><span>${esc(hint)}</span></div>`;
  const val = el('span', 'tag');
  val.style.width = '46px';
  val.style.textAlign = 'right';
  const input = el('input');
  input.type = 'range';
  input.min = min; input.max = max; input.step = step;
  input.value = state.settings[key];
  val.textContent = fmtVal(state.settings[key]);
  input.addEventListener('input', () => {
    state.settings[key] = parseFloat(input.value);
    val.textContent = fmtVal(state.settings[key]);
    Audio.applyVolumes();
    save();
  });
  row.append(input, val);
  return row;
}

function toggleRow(label, hint, key){
  const row = el('div', 'row');
  row.innerHTML = `<div class="label"><b>${esc(label)}</b><span>${esc(hint)}</span></div>`;
  const t = el('button', 'toggle' + (state.settings[key] ? ' on' : ''));
  click(t, () => {
    state.settings[key] = !state.settings[key];
    t.classList.toggle('on', !!state.settings[key]);
    save();
  });
  row.appendChild(t);
  return row;
}

function openSettings(){
  openModal('Inställningar', 'SYSTEM', body => {
    body.appendChild(sliderRow('Huvudvolym', 'Allt ljud', 'master', 0, 1, .05, v => Math.round(v * 100) + '%'));
    body.appendChild(sliderRow('Effekter', 'Vapen, träffar, explosioner', 'sfx', 0, 1, .05, v => Math.round(v * 100) + '%'));
    body.appendChild(sliderRow('Musik', 'Bakgrundsbädd', 'music', 0, 1, .05, v => Math.round(v * 100) + '%'));
    body.appendChild(sliderRow('Skakning', 'Kamerans reaktion på explosioner', 'shake', 0, 1.5, .1, v => Math.round(v * 100) + '%'));
    body.appendChild(sliderRow('Partiklar', 'Mängd gnistor och rök', 'particles', 0.2, 1.5, .1, v => Math.round(v * 100) + '%'));
    body.appendChild(toggleRow('Skadesiffror', 'Visa siffror över träffade mål', 'dmgNumbers'));
    body.appendChild(toggleRow('Sensor', 'Radarn nere till höger', 'minimap'));
    body.appendChild(toggleRow('Siktassistans', 'Mjuk dragning mot närmaste mål', 'aimAssist'));
    body.appendChild(toggleRow('Bildfrekvens', 'Visa FPS i hörnet', 'showFps'));


    const danger = el('div');
    danger.style.cssText = 'margin-top:22px; display:flex; gap:12px';
    const wipe = el('button', 'btn danger', 'Radera sparfil');
    click(wipe, () => confirmBox('Radera sparfil', 'Hela kampanjen försvinner. Det går inte att ångra.', () => {
      resetSave(true);
      closeModal();
      show('menu');
      toast({ text: 'Sparfilen raderad' });
    }, 'Radera'));
    danger.appendChild(wipe);
    body.appendChild(danger);
  });
}

function openControls(){
  openModal('Styrning', 'TANGENTBORD · MUS · HANDKONTROLL', body => {
    const rows = [
      ['Rörelse', 'W A S D / piltangenter', 'Vänster spak'],
      ['Sikte', 'Musen', 'Höger spak'],
      ['Eld', 'Vänsterklick / Mellanslag', 'RT eller RB'],
      ['Ladda om', 'R', 'X'],
      ['Förmåga', 'Shift eller Q', 'LT eller B'],
      ['Paus', 'Esc eller P', 'Start']
    ];
    const t = el('div');
    t.innerHTML = `<div class="row" style="border-bottom:1px solid var(--seam-hot)">
        <div class="label"><b>Funktion</b></div>
        <span class="tag" style="width:190px">TANGENTBORD</span>
        <span class="tag" style="width:120px">HANDKONTROLL</span>
      </div>` +
      rows.map(r => `<div class="row">
        <div class="label"><b>${esc(r[0])}</b></div>
        <span class="tag" style="width:190px; color:var(--ink)">${esc(r[1])}</span>
        <span class="tag" style="width:120px">${esc(r[2])}</span>
      </div>`).join('');
    body.appendChild(t);
    body.appendChild(el('p', 'note',
      'Handkontroll upptäcks automatiskt så fort du rör en spak. Pekskärm: håll fingret där du vill gå — roboten siktar och skjuter mot samma punkt.'));
  });
}

function openCredits(){
  openModal('Om spelet', 'IRONFRONT · BUILD 2.0', body => {
    body.innerHTML = `
      <p class="note">IRONFRONT är ett taktiskt mech-arenaspel. Du håller en front som sakta faller isär, sektor för sektor, med en flotta på tre robotar och den utrustning du hinner köpa mellan utryckningarna.</p>
      <div style="margin-top:18px">
        ${statRow('Robotar', Object.keys(ROBOTS).length)}
        ${statRow('Vapensystem', Object.keys(WEAPONS).length)}
        ${statRow('Fiendetyper', '7 + 4 bossarketyper')}
        ${statRow('Kartor', '4 biom med egen palett')}
        ${statRow('Fältuppgraderingar', '24 i tre sällsynthetsgrader')}
      </div>
      <p class="note" style="margin-top:18px">All grafik ritas i realtid på canvas och allt ljud syntetiseras i webbläsaren — spelet laddar inga externa filer utöver typsnitten.</p>`;
  });
}

/* =========================================================
   GUIDER
   Två genomgångar i hangaren:
     1. Första gången — köp din första robot, lär dig hangaren,
        skicka ut i träningen (sektor 1).
     2. Efter träningen — köp robotplats 2 och 3, se de nya
        spellägena som låstes upp.
   Guidesystemet självt bor i guide.js; här står bara stegen.
   ========================================================= */
function maybeStartGuide(){
  if (current !== 'hangar' || Guide.active) return;
  if (!state.flags.tutorialDone) startGuideOne();
  else if (modesUnlocked() && !state.flags.hangarTut2Done) startGuideTwo();
}

function startGuideOne(){
  closeModal();
  setTab('bay');
  const hasRobot = () => state.bays.some(Boolean);
  Guide.start([
    { target: null, title: 'Välkommen till hangaren',
      text: 'Här förbereder du dina robotar mellan striderna. Den här guiden visar steg för steg var allt finns och hur spelet fungerar. Det tar ungefär en minut.',
      nextLabel: 'Sätt igång' },
    { target: '#bays .bay-slot[data-idx="0"]', title: 'Din första robotplats', side: 'top',
      text: 'Det här är din robotplats. Den är tom just nu — tryck på den för att öppna robotdepån och köpa din första robot.',
      advance: 'click', doText: 'Tryck på den tomma platsen', skipIf: hasRobot },
    { target: '#modalBody .card[data-robot="recon"]', title: 'Köp RECON', side: 'right',
      text: 'I robotdepån finns alla robotar. RECON är gratis för nya befäl — en snabb och lättlärd spanare. Tryck på kortet för att köpa den.',
      advance: 'signal:robot-bought', doText: 'Tryck på RECON-kortet', skipIf: hasRobot },
    { target: '.bay-head', title: 'Här har du din robot', side: 'bottom',
      text: 'Roboten står nu i hangaren. Här uppe ser du namn, roll och samlad nivå — nivån stiger för varje uppgradering du köper.' },
    { target: '#specBody .spec-stats', title: 'Robotens värden', side: 'left',
      text: 'LIV är hur mycket skada roboten tål. SKADA är hur mycket den gör per sekund med alla vapen. FART är hur snabbt den rör sig.' },
    { target: '#specBody .spec-weapons .mount', title: 'Vapen', side: 'left',
      text: 'Vapnen sitter i montage på roboten. Tryck på vapnet för att öppna vapenmenyn.',
      advance: 'click', doText: 'Tryck på vapnet' },
    { target: '#modalBody .up-list', title: 'Uppgradera vapnet', side: 'bottom',
      text: 'Den här menyn innehåller bara uppgraderingar av vapnet som sitter i montaget: mer skada, snabbare eld, större magasin, kortare omladdning. En rad per uppgradering — varje nivå kostar lite mer än den förra.' },
    { target: '#modalBody .btn-swap', title: 'Byta vapen', side: 'bottom',
      text: 'Vill du byta vapen istället trycker du här. Det öppnar en helt egen meny.',
      advance: 'click', doText: 'Tryck på Byt vapen' },
    { target: '#modalBody .wpn-list', title: 'Välj och köp vapen', side: 'top',
      text: 'Ett vapen per rad, med skada, eldhastighet och magasin. Knappen till höger monterar vapnet — eller köper det först om du inte äger det.',
      leave: () => closeModal() },
    { target: '#btnUpgrade', title: 'Uppgradera roboten', side: 'top',
      text: 'Den här knappen uppgraderar själva roboten: tjockare pansar (mer liv), snabbare ben och starkare sköld. Uppgraderingarna sitter kvar för alltid.' },
    { target: '#purse', title: 'Dina pengar', side: 'bottom',
      html: '<b style="color:var(--ag)">Argentum</b> är vanliga pengar — du får dem för varje våg och varje fiende. <b style="color:var(--au)">Aurum</b> får du från bossar. <b style="color:var(--pl)">Platina</b> är sällsynt och kommer från uppdrag och sektorsvakter.' },
    { target: '#tabRail [data-tab="arsenal"]', title: 'Butiken', side: 'right',
      text: 'Här i menyn till vänster byter du vy. Tryck på Butik för att se alla robotar och vapen du kan köpa.',
      advance: 'click', doText: 'Tryck på Butik' },
    { target: '#spec', title: 'Köp nya robotar och vapen', side: 'left', pad: 0,
      text: 'Alla robotar och vapen i spelet. Tryck på en rad för att se detaljer och köpa. Nya robotar hamnar i en ledig robotplats.',
      leave: () => setTab('bay') },
    { target: '#bays .bay-slot[data-idx="1"]', title: 'Fler robotplatser', side: 'top',
      text: 'Plats 2 och 3 är låsta. Plats 2 kan köpas när du klarat träningen, plats 3 låses upp på nivå 15.' },
    { target: '#lvlBadge', title: 'Din nivå', side: 'bottom',
      text: 'Du är på nivå 1. Klarar du träningen hoppar du direkt till nivå 2 — sedan får du XP i alla spellägen. Nya nivåer låser upp robotar, vapen och robotplatser. Tryck på märket när som helst för att se vad som väntar.' },
    { target: '#modeTabs', title: 'Spellägen', side: 'top',
      text: 'Här väljer du vad du ska spela. Just nu finns bara träningen. När den är klar låses Story, Utmaning, Multiplayer och Sektorer upp.' },
    { target: '#btnDeploy', title: 'Dags för träningen', side: 'top',
      text: 'Tryck på knappen för att starta Sektor 1 — träningen. I striden visar en instruktör hur du går, siktar, skjuter och laddar om.',
      advance: 'click', doText: 'Tryck på Starta träningen' }
  ], {
    label: 'GUIDE',
    onDone: () => {
      state.flags.tutorialDone = true;
      // Den som hoppar över innan första köpet får ändå en robot
      if (!state.bays.some(Boolean)){
        state.bays[0] = makeSlot('recon');
        state.selected = 0;
      }
      save(true);
      if (current === 'hangar') refreshHangar();
    }
  });
}

function startGuideTwo(){
  closeModal();
  setTab('bay');
  const p2 = slotPrice(1), p3 = slotPrice(2);
  Guide.start([
    { target: null, title: 'Träningen är klar!',
      text: 'Snyggt jobbat. Du har tjänat pengar i striden och nu öppnas resten av spelet: fler robotplatser och tre nya spellägen.',
      nextLabel: 'Visa mig' },
    { target: '#lvlBadge', title: 'Nivå 2!', side: 'bottom',
      text: 'Träningen gav dig nivå 2 direkt. Nu låstes VULCAN, RAPTOR och Snabbeldskanonen upp, plus robotplats 2 och nya spellägen. Härifrån får du XP i allt du spelar — mer när du vinner.' },
    { target: '#purse', title: 'Din belöning', side: 'bottom',
      text: 'Pengarna från träningen ligger här. Bossen du fällde gav dig Aurum — det behövs till den tredje robotplatsen.' },
    { target: '#bays .bay-slot[data-idx="1"]', title: 'Köp robotplats 2', side: 'top',
      text: `Med fler platser kan du ha flera robotar redo och välja den som passar uppdraget. Plats 2 kostar ${priceText(p2).toLowerCase()}. Tryck på den för att köpa.`,
      advance: 'click', doText: 'Tryck på plats 2',
      skipIf: () => state.slotsUnlocked >= 2 || !canAfford(p2) },
    { target: '#modalBody .modal-actions .btn.primary', title: 'Bekräfta köpet', side: 'bottom',
      text: 'Tryck på Köp plats för att låsa upp den.',
      advance: 'signal:slot-unlocked', doText: 'Tryck på Köp plats',
      skipIf: () => state.slotsUnlocked >= 2 || !canAfford(p2) },
    { target: '#bays .bay-slot[data-idx="1"]', title: 'Robotplats 2', side: 'top',
      text: `Plats 2 kostar ${priceText(p2).toLowerCase()}. Du har inte riktigt råd än — spela en sektor till och kom tillbaka hit.`,
      skipIf: () => state.slotsUnlocked >= 2 || canAfford(p2) },
    { target: '#bays .bay-slot[data-idx="2"]', title: 'Robotplats 3', side: 'top',
      text: 'Den tredje platsen låses upp på nivå 15. Spela, samla XP och kom tillbaka hit.',
      skipIf: () => state.slotsUnlocked >= 3 },
    { target: '#bays .bay-slot[data-idx="1"]', title: 'Fyll platsen', side: 'top',
      text: 'En tom plats fyller du genom att trycka på den — då öppnas robotdepån där du köper en ny robot. Välj robot genom att trycka på dess plats innan du skickar ut.',
      skipIf: () => state.slotsUnlocked < 2 },
    { target: '#modeTabs', title: 'Nya spellägen', side: 'top',
      text: 'Nya spellägen är nu upplåsta. Tryck på ett läge för att välja det — knappen till höger startar sedan det valda läget.' },
    { target: '#modeTabs [data-mode="story"]', title: 'Story', side: 'top',
      text: 'Berättelsen i kapitel. Varje kapitel är en kort utryckning med en egen händelse, en slutboss och en stor belöning första gången du klarar det.' },
    { target: '#modeTabs [data-mode="weekly"]', title: 'Veckans utmaning', side: 'top',
      text: 'Varje vecka en ny utmaning med två specialregler — till exempel dubbelt så många fiender, eller ingen radar. Klara den för Platina och Aurum.' },
    { target: '#modeTabs [data-mode="survival"]', title: 'Överlevnad', side: 'top',
      text: 'Vågorna tar aldrig slut. Håll ut så länge du kan och slå ditt rekord — det finns en egen topplista för hur långt folk kommer.' },
    { target: '#modeTabs [data-mode="trial"]', title: 'Arena', side: 'top',
      text: 'Tre korta utmaningar med egna topplistor: Bossrush (fem bossar i rad), Tidsattack (tio vågor mot klockan) och Dagens sektor (nya regler varje dag).' },
    { target: '#modeTabs [data-mode="multi"]', title: 'Multiplayer', side: 'top',
      text: 'Spela tillsammans, upp till 4 spelare. Skapa en lobby och dela koden, eller gå med i en väns lobby med deras kod. Servrarna kopplas in snart.' },
    { target: '#modeTabs [data-mode="sectors"]', title: 'Sektorer', side: 'top',
      text: 'Din egen kampanj — sektor för sektor, längre och svårare för varje sektor, med bossar var femte våg. Det här är läget du har spelat hittills.',
      nextLabel: 'Klar' }
  ], {
    label: 'NYTT',
    onDone: () => {
      state.flags.hangarTut2Done = true;
      save(true);
      if (current === 'hangar') refreshHangar();
    }
  });
}

/* =========================================================
   HANGARSCENEN — roboten renderas live
   ========================================================= */
function startBayLoop(){
  const step = () => {
    bayRaf = requestAnimationFrame(step);
    bayT += 1 / 60;
    drawBay();
  };
  cancelAnimationFrame(bayRaf);
  bayRaf = requestAnimationFrame(step);
}
function stopBayLoop(){ cancelAnimationFrame(bayRaf); bayRaf = 0; }

function drawBay(){
  const g = bayCtx;
  const { w, h } = fitCanvas(bayCanvas, g);
  g.clearRect(0, 0, w, h);

  // Hangargolv: kall botten, varm kant mot höger
  const bg = g.createLinearGradient(0, 0, w, h);
  bg.addColorStop(0, '#0a121a');
  bg.addColorStop(0.55, '#080d14');
  bg.addColorStop(1, '#120c0a');
  g.fillStyle = bg;
  g.fillRect(0, 0, w, h);

  // Golvraster
  g.strokeStyle = 'rgba(74,108,140,0.10)';
  g.lineWidth = 1;
  const cell = 46;
  for (let x = (bayT * 4) % cell; x < w; x += cell){ g.beginPath(); g.moveTo(x, 0); g.lineTo(x, h); g.stroke(); }
  for (let y = 0; y < h; y += cell){ g.beginPath(); g.moveTo(0, y); g.lineTo(w, y); g.stroke(); }

  // Varningsränder längs golvkanten
  g.save();
  g.globalAlpha = 0.16;
  g.strokeStyle = '#ff5a1e';
  g.lineWidth = 8;
  for (let i = -3; i < w / 26 + 3; i++){
    g.beginPath();
    g.moveTo(i * 26, h - 26);
    g.lineTo(i * 26 + 20, h - 6);
    g.stroke();
  }
  g.restore();

  const slot = selectedSlot();
  if (!slot){
    // Tom plats: en dockningsring och en tydlig uppmaning istället för en robot
    const cx = w / 2, cy = h * 0.5;
    g.save();
    g.translate(cx, cy + 40); g.scale(1, 0.34);
    g.strokeStyle = 'rgba(95,179,212,0.35)'; g.lineWidth = 2;
    g.setLineDash([10, 10]);
    g.beginPath(); g.arc(0, 0, Math.min(w, h) * 0.3, bayT * 0.3, bayT * 0.3 + Math.PI * 2); g.stroke();
    g.restore();
    g.textAlign = 'center';
    g.fillStyle = 'rgba(211,223,233,0.85)';
    g.font = '700 22px Oxanium, sans-serif';
    g.fillText('TOM PLATS', cx, cy - 6);
    g.fillStyle = 'rgba(160,185,205,0.7)';
    g.font = '500 15px "Barlow Semi Condensed", sans-serif';
    g.fillText('Köp en robot för att fylla platsen', cx, cy + 18);
    g.textAlign = 'left';
    return;
  }
  const tpl = { ...ROBOTS[slot.tpl], color: slotColor(slot) };
  drawHangarMech(createBayLayer(w, h), { w, h, tpl, t: bayT, scale: 1 });
  g.drawImage(bayLayer, 0, 0, w, h);
  // Ditt namn och din titel över roboten
  if (state.profile.name)
    drawNameTag(g, { x: w / 2, tag: state.profile.name, rank: myTitle() }, h * 0.24, 1.35);
}

/* drawHangarMech rensar hela ytan, så den får ett eget lager att rita på. */
let bayLayer = null;
function createBayLayer(w, h){
  if (!bayLayer) bayLayer = document.createElement('canvas');
  const dpr = Math.min(devicePixelRatio || 1, 2);
  if (bayLayer.width !== Math.round(w * dpr) || bayLayer.height !== Math.round(h * dpr)){
    bayLayer.width = Math.round(w * dpr);
    bayLayer.height = Math.round(h * dpr);
  }
  const lg = bayLayer.getContext('2d');
  lg.setTransform(dpr, 0, 0, dpr, 0, 0);
  return lg;
}

/* =========================================================
   UTRYCKNING
   ========================================================= */
function deploy(){
  const slot = selectedSlot();
  if (!slot){ toast({ text: 'Köp en robot först — tryck på den tomma platsen', kind: 'bad' }); return; }
  const mode = currentMode();
  if (mode === 'story') return openStorySelect();
  if (mode === 'weekly') return openWeekly();
  if (mode === 'trial') return openTrials();
  if (mode === 'survival') return launch({ mode: 'survival', sector: Math.max(2, state.sector), chapter: null });
  if (mode === 'multi') return openLobby();
  launch({ mode: 'sectors', sector: state.sector, chapter: null });
}

/** Startar en utryckning och kommer ihåg den för "Försök igen". */
function launch(run){
  const slot = selectedSlot();
  if (!slot) return;
  lastRun = run;
  Audio.unlock();
  closeModal();
  show('battle');
  requestAnimationFrame(() => {
    if (run.mode === 'story'){
      const ch = STORY_CHAPTERS.find(c => c.id === run.chapter);
      Battle.start(slot, ch.sector, { mode: 'story', chapter: ch });
    } else if (run.mode === 'trial'){
      Battle.start(slot, 3, { mode: 'trial', trial: run.trial });
    } else if (run.mode === 'survival'){
      Battle.start(slot, run.sector, { mode: 'survival' });
    } else if (run.mode === 'coop'){
      Battle.start(slot, run.sector, { mode: 'coop', coop: run.coop });
    } else if (run.mode === 'weekly'){
      const wk = weeklyChallenge();
      Battle.start(slot, Math.max(2, state.sector), { mode: 'weekly', weekly: wk });
    } else Battle.start(slot, run.sector);
  });
}

/* ---------- Arena ---------- */
function openTrials(){
  const today = dailyTrial();
  openModal('Arena', 'TRE UTMANINGAR · EGNA TOPPLISTOR', body => {
    body.appendChild(el('p', 'lead-note', 'Samma svårighet för alla, så topplistorna är rättvisa. Det som avgör är dina robotar, dina uppgraderingar och hur bra du spelar.'));
    const grid = el('div', 'trial-grid');
    for (const t of Object.values(TRIALS)){
      const rec = state.records?.['trial_' + t.id] || {};
      const best = t.rank === 'time' ? (rec.time ? 'Ditt rekord: ' + fmtRace(rec.time) : 'Inget rekord än')
        : (rec.day === today.id && rec.score ? `I dag: ${fmt(rec.score)} poäng` : 'Inte spelad i dag');
      const c = el('div', 'trial-card');
      c.dataset.trial = t.id;
      c.innerHTML = `<h4>${esc(t.name)}</h4><p>${esc(t.text)}</p>
        ${t.id === 'daily' ? `<p class="trial-mods">${today.mods.map(id => `<b>${esc(WEEKLY_MODS[id].name)}</b> ${esc(WEEKLY_MODS[id].text)}`).join('<br>')}</p>` : ''}
        <span class="tag">${t.waves} ${t.id === 'bossrush' ? 'BOSSAR' : 'VÅGOR'} · SEKTOR ${t.sector}</span>
        <span class="trial-best">${esc(best)}</span>
        <div class="trial-top" data-top="${t.id}"><p class="note">Hämtar topplista…</p></div>`;
      const go = el('button', 'btn primary wide', 'Starta');
      click(go, () => launch({ mode: 'trial', trial: t.id, sector: t.sector, chapter: null }));
      c.appendChild(go);
      grid.appendChild(c);
      getTop(t.id, state.profile.name).then(res => {
        const box = $(`#modalBody [data-top="${t.id}"]`);
        if (!box) return;
        if (!res.ok){ box.innerHTML = '<p class="note">Topplistan kräver servern.</p>'; return; }
        box.innerHTML = res.rows.slice(0, 5).map((r, i) => `<div class="tt-row${r.name.toLowerCase() === (state.profile.name || '').toLowerCase() ? ' me' : ''}"><span>${i + 1}. ${esc(r.name)}</span><b>${t.rank === 'time' ? fmtRace(r.value) : fmt(r.value)}</b></div>`).join('')
          || '<p class="note">Ingen på listan än — bli först!</p>';
      });
    }
    body.appendChild(grid);
  }, { wide: true });
}

/* ---------- Veckans utmaning ---------- */
function openWeekly(){
  const wk = weeklyChallenge();
  const mine = state.weekly.id === wk.id ? state.weekly : { done: false, best: 0 };
  const left = Math.max(0, wk.reset - Date.now());
  const days = Math.floor(left / 86400000), hours = Math.floor(left / 3600000) % 24;
  openModal('Veckans utmaning', `VECKA ${wk.week} · BYTS OM ${days} D ${hours} H`, body => {
    body.appendChild(el('p', 'lead-note', `${WEEKLY_WAVES} vågor med två specialregler. Alla spelare får samma utmaning samma vecka. Första gången du klarar den i veckan får du en extra belöning.`));
    const list = el('div', 'weekly-mods');
    wk.mods.forEach(id => {
      const m = WEEKLY_MODS[id];
      list.appendChild(el('div', 'weekly-mod', `<b>${esc(m.name)}</b><span>${esc(m.text)}</span>`));
    });
    body.appendChild(list);
    const info = el('div', 'price-line');
    info.innerHTML = mine.done
      ? `<span>Belöning</span><span class="tag" style="color:var(--ok)">HÄMTAD DENNA VECKA ✓</span>`
      : `<span>Belöning första vinsten</span>${priceHtml(WEEKLY_REWARD)}`;
    body.appendChild(info);
    if (mine.best) body.appendChild(el('p', 'note', `Ditt bästa den här veckan: våg ${mine.best} av ${WEEKLY_WAVES}.`));
    const row = el('div', 'modal-actions');
    const no = el('button', 'btn ghost', 'Stäng');
    const go = el('button', 'btn primary', 'Starta utmaningen');
    click(no, closeModal);
    click(go, () => launch({ mode: 'weekly', sector: Math.max(2, state.sector), chapter: null }));
    row.append(no, go);
    body.appendChild(row);
  });
}

/* ---------- Story: kapitelval ---------- */
function openStorySelect(){
  openModal('Story', `${state.story.done.length} / ${STORY_CHAPTERS.length} KAPITEL KLARA`, body => {
    body.appendChild(el('p', 'lead-note', 'Berättelsen om Arkitekten, kapitel för kapitel. Varje kapitel är en kort utryckning med en egen händelse och en slutboss. Första gången du klarar ett kapitel får du hela belöningen.'));
    const list = el('div', 'chapters');
    STORY_CHAPTERS.forEach(ch => {
      const done = state.story.done.includes(ch.id);
      const open = chapterOpen(ch.id);
      const c = el('button', 'chapter' + (done ? ' done' : '') + (open ? '' : ' locked'));
      c.dataset.chapter = String(ch.id);
      c.innerHTML = `
        <span class="ch-no">${open ? String(ch.id).padStart(2, '0') : '<i class="lock"></i>'}</span>
        <span class="ch-body">
          <b>${esc(ch.title)}</b>
          <span>${open ? esc(ch.brief) : 'Klara föregående kapitel för att låsa upp.'}</span>
        </span>
        <span class="ch-meta">
          <span class="tag">${ch.waves} VÅGOR</span>
          ${done ? '<span class="tag" style="color:var(--ok)">KLART ✓</span>' : open ? priceHtml(ch.reward) : ''}
        </span>`;
      if (open) click(c, () => launch({ mode: 'story', sector: ch.sector, chapter: ch.id }));
      list.appendChild(c);
    });
    body.appendChild(list);
  }, { wide: true });
}

/* ---------- Multiplayer: co-op-lobby ----------
   Allt nätverk går via net.js mot lobbyservern i server/.
   Värden skapar en lobby och delar koden; gästerna går med,
   trycker Redo, och värden startar. Striden räknas ut hos
   värden (se CO-OP i battle.js). */
let lobbyHooked = false;
function hookLobbyEvents(){
  if (lobbyHooked) return;
  lobbyHooked = true;
  onNet('lobby', () => { if (lobbyModalOpen()) refreshModal(); });
  onNet('left', m => { if (lobbyModalOpen()) toast({ text: `${m.name} lämnade lobbyn`, kind: 'bad' }); });
  onNet('closed', m => {
    if (lobbyModalOpen()){ toast({ text: m.reason || 'Lobbyn stängdes', kind: 'bad' }); refreshModal(); }
  });
  onNet('down', () => { if (lobbyModalOpen()){ toast({ text: 'Anslutningen till servern bröts', kind: 'bad' }); refreshModal(); } });
  onNet('error', m => toast({ text: m.reason, kind: 'bad' }));
  onNet('start', m => {
    const me = myNetId();
    const slot = selectedSlot();
    if (!slot){ leaveLobby(); return; }
    toast({ text: 'Matchen startar!', kind: 'good' });
    launch({ mode: 'coop', sector: m.params?.sector || 2, chapter: null,
             coop: { role: m.host === me ? 'host' : 'guest', me, host: m.host, players: m.players } });
  });
}
const lobbyModalOpen = () => $('#modal').classList.contains('on') && $('#modal').dataset.kind === 'lobby';

function lobbyPlayer(){
  const slot = selectedSlot();
  return { name: state.profile.name || 'Befäl', token: state.profile.token, robot: slot ? ROBOTS[slot.tpl].name : '—', slot,
           title: myTitle().name, level: state.level };
}

function openLobby(){
  hookLobbyEvents();
  const build = body => {
    const lobby = currentLobby();

    if (!lobby){
      // Namn och server — det enda man behöver ställa in
      const setup = el('div', 'lobby-setup');
      const t = myTitle();
      setup.innerHTML = `
        <div class="lobby-me"><span>Du spelar som</span><b>${esc(state.profile.name || 'Befäl')}</b><i style="color:${t.color}">${esc(t.name)} · nivå ${state.level}</i></div>`;
      body.appendChild(setup);
      // Serveradressen är inbyggd i spelfilen — ingen ska behöva (eller kunna) ändra den här
      const saveSetup = () => {};

      const grid = el('div', 'lobby-choice');
      const create = el('div', 'lobby-card');
      create.innerHTML = `<h4>Skapa lobby</h4><p>Du blir värd och får en kod som dina vänner skriver in. Upp till ${MULTI_MAX_PLAYERS} spelare. Striden körs på din dator.</p>`;
      const cb = el('button', 'btn primary wide', 'Skapa lobby');
      click(cb, async () => {
        saveSetup();
        cb.disabled = true; cb.textContent = 'Ansluter…';
        const res = await createLobby(lobbyPlayer());
        if (!res.ok){ toast({ text: res.reason, kind: 'bad' }); cb.disabled = false; cb.textContent = 'Skapa lobby'; return; }
        refreshModal();
      });
      create.appendChild(cb);

      const join = el('div', 'lobby-card');
      join.innerHTML = `<h4>Gå med via kod</h4><p>Skriv in den sexställiga koden du fått av värden.</p>`;
      const input = el('input', 'code-input');
      input.type = 'text'; input.maxLength = 6; input.placeholder = 'ABC123';
      input.setAttribute('autocomplete', 'off');
      input.addEventListener('input', () => { input.value = input.value.toUpperCase().replace(/[^A-Z0-9]/g, ''); });
      const jb = el('button', 'btn wide', 'Gå med');
      click(jb, async () => {
        saveSetup();
        jb.disabled = true; jb.textContent = 'Ansluter…';
        const res = await joinLobby(input.value, lobbyPlayer());
        if (!res.ok){ toast({ text: res.reason, kind: 'bad' }); jb.disabled = false; jb.textContent = 'Gå med'; return; }
        refreshModal();
      });
      join.append(input, jb);
      grid.append(create, join);
      body.appendChild(grid);
      body.appendChild(el('p', 'note', 'Alla lobbyer körs på IRONFRONT-servern. Flera lobbyer kan vara igång samtidigt — varje har sin egen kod.'));
      return;
    }

    // I lobbyn: koden stort, fyra platser, redo/start
    const me = myNetId();
    const host = lobby.host === me;
    const head = el('div', 'lobby-code');
    head.innerHTML = `<span class="tag">LOBBYKOD — DELA MED DINA VÄNNER</span><b>${esc(lobby.code)}</b>`;
    body.appendChild(head);
    const seats = el('div', 'lobby-seats');
    for (let i = 0; i < MULTI_MAX_PLAYERS; i++){
      const p = lobby.players[i];
      const s = el('div', 'seat' + (p ? ' filled' : '') + (p && !p.ready ? ' waiting' : ''));
      s.innerHTML = p
        ? `<span class="seat-no">${i + 1}${p.id === me ? ' · DU' : ''}</span><b>${esc(p.name)}${p.host ? ' <span class="tag hot">VÄRD</span>' : ''}</b>${p.title ? `<i class="seat-title" style="color:${titleFor(p.level || 1).color}">${esc(p.title)} · nivå ${p.level || 1}</i>` : ''}<span>${esc(p.robot)} · ${p.ready ? 'REDO ✓' : 'INTE REDO'}</span>`
        : `<span class="seat-no">${i + 1}</span><b>Väntar på spelare…</b><span>Ledig plats</span>`;
      seats.appendChild(s);
    }
    body.appendChild(seats);

    const row = el('div', 'modal-actions');
    const leave = el('button', 'btn ghost', 'Lämna lobbyn');
    click(leave, () => { leaveLobby(); refreshModal(); });
    row.appendChild(leave);
    if (host){
      const everyone = lobby.players.length >= 2 && lobby.players.every(p => p.ready);
      const start = el('button', 'btn primary', lobby.players.length < 2 ? 'Väntar på spelare' : everyone ? 'Starta match' : 'Väntar på att alla är redo');
      start.disabled = !everyone;
      click(start, () => startMatch({ sector: Math.max(2, state.sector) }));
      row.appendChild(start);
    } else {
      const mine = lobby.players.find(p => p.id === me);
      const ready = el('button', 'btn primary', mine?.ready ? 'Inte redo' : 'Jag är redo');
      click(ready, () => setReady(!mine?.ready));
      row.appendChild(ready);
    }
    body.appendChild(row);
    body.appendChild(el('p', 'note', host
      ? `Matchen spelas på sektor ${Math.max(2, state.sector)} med ${COOP_WAVES} vågor. Fler spelare = fler fiender och tåligare bossar.`
      : 'Värden startar matchen när alla är redo.'));
  };
  openModal('Multiplayer', `CO-OP · UPP TILL ${MULTI_MAX_PLAYERS} SPELARE`, build, { wide: true, kind: 'lobby' });
}

/* =========================================================
   PAUS
   ========================================================= */
function bootPause(){
  $$('#pauseNav button').forEach(b => {
    b.addEventListener('mouseenter', () => Audio.sfx('uiHover', { vol: .22 }));
    click(b, () => {
      switch (b.dataset.act){
        case 'resume':   hidePause(); Battle.resume(); break;
        case 'settings': openSettings(); break;
        case 'controls': openControls(); break;
        case 'abandon':
          confirmBox('Avbryt uppdraget', 'Du lämnar sektorn utan belöning. Framsteg i den här utryckningen går förlorade.', () => {
            hidePause();
            Battle.abandon();
          }, 'Avbryt uppdrag');
          break;
      }
    });
  });

  bus.on('battle:paused', () => {
    // Draften pausar också striden — då ska pausmenyn inte synas
    queueMicrotask(() => { if (!draftOpen) showPause(); });
  });
  bus.on('battle:resumed', hidePause);

  addEventListener('keydown', e => {
    if (e.code !== 'Escape') return;
    if ($('#modal').classList.contains('on')){ closeModal(); return; }
    if ($('#pause').classList.contains('on')){ hidePause(); Battle.resume(); }
  });
}

function showPause(){
  const g = Battle.game;
  if (g) $('#pauseSub').textContent = g.chapter
    ? `KAPITEL ${g.chapter.id} · VÅG ${g.waveInSector}/${g.waveTotal}`
    : `SEKTOR ${g.sector} · VÅG ${g.waveInSector}/${g.waveTotal}`;
  $('#pause').classList.add('on');
  showCrosshair(false);
}
function hidePause(){
  $('#pause').classList.remove('on');
  if (Battle.running) showCrosshair(true);
}

/* =========================================================
   FÄLTUPPGRADERING
   ========================================================= */
function bootDraft(){
  bus.on('draft:open', ({ choices, pick }) => {
    draftOpen = true;
    $('#pause').classList.remove('on');
    showCrosshair(false);
    const wrap = $('#draftCards');
    wrap.innerHTML = '';
    choices.forEach((p, i) => {
      const card = el('button', `perk r-${p.rank}`);
      card.innerHTML = `
        <span class="rank">${esc(RANK_LABEL[p.rank])}</span>
        <h4>${esc(p.name)}</h4>
        <p>${esc(p.text)}</p>
        <span class="eff">${esc(p.eff)}</span>
        ${perkGlyph(p.rank)}`;
      card.style.animationDelay = (i * 60) + 'ms';
      click(card, () => {
        $('#draft').classList.remove('on');
        draftOpen = false;
        showCrosshair(true);
        pick(p.id);
      });
      wrap.appendChild(card);
    });
    $('#draft').classList.add('on');
    Audio.sfx('uiBig');
  });
}

function perkGlyph(rank){
  const c = rank === 'epic' ? '#ff5a1e' : rank === 'rare' ? '#5fb3d4' : '#7b8da0';
  return `<svg class="glyph" viewBox="0 0 30 30" fill="none" stroke="${c}" stroke-width="1.4">
    <path d="M15 2.5l11 6v13l-11 6-11-6v-13z"/><circle cx="15" cy="15" r="4.2"/></svg>`;
}

/* =========================================================
   RESULTAT
   ========================================================= */
function bootResult(){
  bus.on('battle:finished', onFinished);
  // Serverloggen: vad startades och hur gick det
  bus.on('battle:started', g => activity('start', {
    mode: g.mode, sector: g.sector, chapter: g.chapter?.id || null, weekly: g.weekly?.week || null,
    robot: g.player.name, training: g.mode === 'sectors' && g.sector === 1, trial: g.trial?.id || null }));
  bus.on('battle:finished', ({ reason, won, stats }) => activity('end', {
    mode: stats.mode, sector: stats.sector, chapter: stats.chapter, reason, won,
    wave: stats.wave, waveTotal: stats.waveTotal, kills: stats.kills, score: stats.score,
    xp: stats.xp, level: stats.lvlAfter?.level, levelUp: stats.levelUp ? stats.levelUp.to : null, time: Math.round(stats.time / 1000),
    trial: stats.trial, trialDay: stats.trialDay, elapsed: stats.elapsed }));
  click($('#resRetry'), () => {
    if (!selectedSlot()){ show('hangar'); return; }
    launch(lastRun);
  });
  click($('#resBack'),  () => {
    show('hangar');
    // Efter en co-op-match står man kvar i lobbyn — visa den direkt
    if (lastRun.mode === 'coop' && currentLobby()) openLobby();
  });
}

function onFinished({ reason, won, payout, stats }){
  draftOpen = false;
  $('#draft').classList.remove('on');
  $('#pause').classList.remove('on');
  closeModal();
  lastSector = stats.sector;

  const v = $('#resVerdict');
  v.className = 'verdict ' + (won ? 'won' : 'lost');
  const ch = stats.chapter ? STORY_CHAPTERS.find(c => c.id === stats.chapter) : null;
  const training = stats.mode === 'sectors' && stats.sector === 1;
  if (stats.trial){
    const T = TRIALS[stats.trial];
    v.textContent = won ? `${T.name.toUpperCase()} KLARAD` : reason === 'abandon' ? 'UTMANING AVBRUTEN' : `${T.name.toUpperCase()} MISSLYCKAD`;
    v.className = 'verdict ' + (won ? 'won' : 'lost');
  } else if (stats.mode === 'survival'){
    v.textContent = reason === 'abandon' ? 'ÖVERLEVNAD AVBRUTEN' : `ÖVERLEVNAD · VÅG ${stats.wave}`;
    v.className = 'verdict ' + (reason === 'abandon' ? 'lost' : 'won');
  } else v.textContent = won
    ? (stats.mode === 'coop' ? 'CO-OP: SEKTOR RENSAD' : stats.weekly ? 'UTMANING KLARAD' : ch ? 'KAPITEL KLART' : training ? 'TRÄNINGEN KLAR' : 'SEKTOR RENSAD')
    : reason === 'abandon' ? 'UPPDRAG AVBRUTET' : 'ROBOT FÖRSTÖRD';

  $('#resSub').textContent = stats.trial && won
    ? (TRIALS[stats.trial].rank === 'time' ? `Tid: ${fmtRace(stats.elapsed)}. ${state.records['trial_' + stats.trial]?.time === stats.elapsed ? 'Nytt rekord!' : 'Rekord: ' + fmtRace(state.records['trial_' + stats.trial]?.time || stats.elapsed)}` : `${fmt(stats.score)} poäng på dagens sektor.`)
    : won
    ? (stats.mode === 'coop' ? `Laget höll alla ${stats.waveTotal} vågor. Belöningen delas lika.`
       : stats.weekly ? (stats.weeklyFirst ? `Vecka ${stats.weekly} klarad — veckans belöning är din.` : `Vecka ${stats.weekly} klarad igen. Belöningen är redan hämtad den här veckan.`)
       : ch ? ch.debrief
       : training ? 'Bra jobbat! Du är nu nivå 2 — i hangaren väntar nya robotar, en ny robotplats och nya spellägen.'
       : `Sektor ${stats.sector} är säkrad. Nästa front väntar.`)
    : reason === 'abandon'
      ? 'Du drog dig tillbaka. Ingen belöning betalas ut.'
      : stats.mode === 'survival'
        ? (stats.wave > (stats.prevSurvival || 0) ? `Nytt rekord! Du höll ut till våg ${stats.wave}.` : `Du höll ut till våg ${stats.wave}. Ditt rekord är våg ${stats.prevSurvival}.`)
        : `Roboten föll på våg ${stats.wave} av ${stats.waveTotal}. Uppgradera i hangaren och försök igen.`;

  $('#resStats').innerHTML = [
    ['VÅGOR', stats.wave],
    ['NEDKÄMPADE', fmt(stats.kills)],
    ['TRÄFFSÄKERHET', stats.accuracy + '%'],
    ['POÄNG', fmt(stats.score)],
    ['SKADA GJORD', fmt(stats.damage)],
    ['SKADA TAGEN', fmt(stats.taken)],
    ['TID', fmtTime(stats.time)],
    ['FÄLTUPPGR.', stats.perks.length]
  ].map(([k, n]) => `<div><div class="n">${n}</div><div class="k">${k}</div></div>`).join('');

  $('#resPayout').innerHTML = reason === 'abandon'
    ? '<span class="tag">INGEN UTBETALNING</span>'
    : [
        payout.ag ? `<div class="p"><b style="color:var(--ag)">+${fmt(payout.ag)}</b><span class="tag">ARGENTUM</span></div>` : '',
        payout.au ? `<div class="p"><b style="color:var(--au)">+${fmt(payout.au)}</b><span class="tag">AURUM</span></div>` : '',
        payout.pl ? `<div class="p"><b style="color:var(--pl)">+${fmt(payout.pl)}</b><span class="tag">PLATINA</span></div>` : ''
      ].join('');

  // XP och nivå
  const lb = stats.lvlBefore, la = stats.lvlAfter, up = stats.levelUp;
  let xpHtml = '';
  if (up){
    xpHtml += `<div class="res-lvlup"><span class="tag">NIVÅ UPP</span><b>${up.from} → ${up.to}</b>
      ${up.unlocks.length ? `<span class="res-unlocks">Upplåst: ${up.unlocks.map(u => esc(u.name)).join(', ')}</span>` : ''}
      ${up.reward.ag ? `<span class="res-unlocks">Nivåbelöning: +${fmt(up.reward.ag)} Ag${up.reward.au ? ' · +' + up.reward.au + ' Au' : ''}${up.reward.pl ? ' · +' + up.reward.pl + ' Pl' : ''}</span>` : ''}</div>`;
  }
  if (la && la.level >= 2){
    const xpLine = training && up ? 'Träningen klar — nivå 2 direkt'
      : reason === 'abandon' ? 'Ingen XP när man lämnar'
      : `+${fmt(stats.xp)} XP${won || stats.mode === 'survival' ? '' : ' (halv XP vid förlust)'}`;
    xpHtml += `<div class="res-xpbar">
      <span class="res-xpline"><b>NIVÅ ${la.level}</b><span>${xpLine}</span><span>${la.max ? 'MAX' : fmt(la.into) + ' / ' + fmt(la.need)}</span></span>
      <span class="lvl-bar big"><i style="width:${Math.round((la.max ? 1 : la.pct) * 100)}%"></i></span></div>`;
  } else if (training){
    xpHtml = `<div class="res-xpbar"><span class="res-xpline"><b>NIVÅ 1</b><span>Klara träningen för att nå nivå 2</span><span></span></span></div>`;
  }
  $('#resXp').innerHTML = xpHtml;

  $('#resRetry').textContent = won ? (ch ? 'Spela kapitlet igen' : 'Spela igen') : 'Försök igen';
  // Co-op startas om från lobbyn, inte härifrån
  $('#resRetry').hidden = stats.mode === 'coop';
  $('#resBack').textContent = stats.mode === 'coop' ? 'Tillbaka till lobbyn' : 'Till hangaren';
  show('result');
  Audio.sfx(won ? 'uiBig' : 'alarm', { vol: .6 });
}

/* =========================================================
   START
   ========================================================= */
export function bootUI(){
  bootMenu();
  bootProfile();
  bootHangar();
  bootPause();
  bootDraft();
  bootResult();

  // Stäng modaler via krysset eller genom att klicka bredvid panelen
  $$('[data-dismiss]').forEach(b => click(b, closeModal));
  $('#modal').addEventListener('mousedown', e => { if (e.target.id === 'modal') closeModal(); });

  // Ljudet får startas först efter en användarhandling
  const wake = () => { Audio.unlock(); Audio.applyVolumes(); removeEventListener('pointerdown', wake); };
  addEventListener('pointerdown', wake);

  addEventListener('resize', () => {
    if (current === 'hangar') drawBay();
    if (current === 'menu') drawMenuStage();
  });

  show('menu');
}

/* =========================================================
   ANVÄNDARNAMN
   Väljs innan man kommer in i spelet. Servern kontrollerar
   att namnet är ledigt och ger en nyckel som bevisar att det
   är ditt. Når man inte servern kan man fortsätta ändå — då
   kontrolleras namnet nästa gång man spelar online.
   ========================================================= */
const NAME_RE = /^[A-Za-z0-9ÅÄÖåäöÉéÜü_\-]{3,16}$/;
let profileTimer = null, profileSeq = 0, profileRename = false, profileMode = 'new';

/**
 * Konto-skärmen har tre lägen:
 *   new     — nytt konto: välj ledigt namn + lösenord
 *   login   — logga in med namn + lösenord (hämtar molnsparfilen)
 *   account — ditt konto: byt namn och/eller sätt nytt lösenord
 */
function openProfile(rename = false){
  profileRename = rename;
  show('profile');
  setProfileMode(rename && state.profile.name ? 'account' : 'new');
  $('#profileName').value = state.profile.name || '';
  $('#profilePass').value = '';
  $('#profileOffline').hidden = true;
  $('#profileBack').hidden = !rename;
  const t = myTitle();
  $('#profilePreviewTitle').textContent = t.name;
  $('#profilePreviewTitle').style.color = t.color;
  $('#profilePreviewTitle').classList.toggle('aura', !!t.aura);
  profileValidate();
  setTimeout(() => $('#profileName').focus?.(), 50);
}

function setProfileMode(mode){
  profileMode = mode;
  $$('#profileTabs button').forEach(b => b.classList.toggle('on', b.dataset.pmode === mode || (mode === 'account' && b.dataset.pmode === 'new')));
  $('#profileTabs button[data-pmode="new"]').textContent = mode === 'account' ? 'Mitt konto' : 'Nytt konto';
  const txt = {
    new:     ['Välj ditt namn', 'Namnet syns över din robot, i lobbyn och på topplistorna. Varje namn finns bara en gång. Lösenordet behövs för att logga in på en annan dator.', 'Lösenord', 'Skapa konto'],
    login:   ['Logga in', 'Har du redan ett konto? Logga in med namn och lösenord så hämtas dina framsteg från servern.', 'Lösenord', 'Logga in'],
    account: ['Ditt konto', 'Här kan du byta namn eller sätta ett nytt lösenord. Dina framsteg följer med.', 'Nytt lösenord (lämna tomt för att behålla)', 'Spara']
  }[mode];
  $('#profileHead').textContent = txt[0];
  $('#profileLead').textContent = txt[1];
  $('#profilePassLabel').textContent = txt[2];
  $('#profileGo').textContent = txt[3];
  $('#profilePreview').hidden = mode === 'login';
  $('#profileOffline').hidden = true;
  profileValidate();
}

function profileSetStatus(text, kind){
  const st = $('#profileStatus');
  st.textContent = text;
  st.className = 'profile-status' + (kind ? ' ' + kind : '');
}

function profileValidate(){
  const name = ($('#profileName').value || '').trim();
  const pass = $('#profilePass').value || '';
  $('#profilePreviewName').textContent = name || '—';
  const go = $('#profileGo');
  go.disabled = true;
  clearTimeout(profileTimer);
  if (!name){ profileSetStatus('3–16 tecken: bokstäver, siffror, _ eller -'); return; }
  if (!NAME_RE.test(name)){ profileSetStatus('Bara 3–16 tecken: bokstäver, siffror, _ eller -', 'bad'); return; }
  const passOk = pass.length >= 4;
  if (profileMode === 'login'){
    profileSetStatus(passOk ? '' : 'Skriv ditt lösenord.');
    go.disabled = !passOk;
    return;
  }
  if (profileMode === 'new' && !passOk){
    // Kolla ändå om namnet är ledigt medan man skriver
    profileSetStatus('Välj ett lösenord (minst 4 tecken).');
  }
  if (pass && !passOk){ profileSetStatus('Lösenordet måste vara minst 4 tecken.', 'bad'); return; }
  if (name === state.profile.name && state.profile.verified){
    profileSetStatus(profileMode === 'account' ? (pass ? 'Nytt lösenord sparas.' : 'Det här är ditt namn ✓') : 'Det här är ditt namn ✓', 'good');
    go.disabled = false;             // ditt eget namn: lösenord är valfritt
    return;
  }
  profileSetStatus('Kontrollerar namnet…');
  const seq = ++profileSeq;
  profileTimer = setTimeout(async () => {
    const res = await checkName(name, state.profile.token);
    if (seq !== profileSeq) return;
    if (res.offline || res.timeout){
      profileSetStatus('Kan inte nå servern just nu.', 'warn');
      $('#profileOffline').hidden = profileMode === 'login';
      return;
    }
    $('#profileOffline').hidden = true;
    const p2 = ($('#profilePass').value || '').length >= 4;
    if (res.ok){
      profileSetStatus(`${name} är ledigt ✓` + (profileMode === 'new' && !p2 ? ' — välj ett lösenord' : ''), 'good');
      go.disabled = profileMode === 'new' && !p2;
    } else profileSetStatus(res.reason || 'Namnet är redan taget.', 'bad');
  }, 350);
}

function profileDone(){
  save(true);
  refreshMenu();
  cloudNow();
  if (profileRename) show('menu'); else show('hangar');
}

async function profileSubmit(){
  const name = ($('#profileName').value || '').trim();
  const pass = $('#profilePass').value || '';
  const go = $('#profileGo');
  const label = go.textContent;
  go.disabled = true; go.textContent = 'Vänta…';

  if (profileMode === 'login'){
    const res = await loginAccount(name, pass);
    go.textContent = label; go.disabled = false;
    if (!res.ok){ profileSetStatus(res.offline ? 'Kan inte nå servern — inloggning kräver servern.' : res.reason, 'bad'); return; }
    const apply = () => {
      if (res.save) loadFrom(res.save);
      else resetSave(true);
      state.profile = { name: res.name, token: res.token, verified: true, hasPass: true };
      save(true);
      toast({ text: res.save ? `Välkommen tillbaka, ${res.name}! Dina framsteg är hämtade.` : `Inloggad som ${res.name}.`, kind: 'good' });
      profileRename = false;
      refreshMenu();
      show('hangar');
    };
    // Finns det framsteg på den här datorn under ett annat namn — fråga först
    if (hasSave() && state.profile.name && state.profile.name.toLowerCase() !== res.name.toLowerCase() && state.level > 1)
      confirmBox('Byta konto?', `Sparfilen på den här datorn (${state.profile.name}, nivå ${state.level}) ersätts med ${res.name}s framsteg från servern. ${state.profile.verified ? `${state.profile.name}s framsteg finns kvar på servern.` : 'Den lokala sparfilen är inte molnsparad och försvinner.'}`, apply, 'Byt konto');
    else apply();
    return;
  }

  const res = await claimName(name, state.profile.token, pass || undefined);
  go.textContent = label;
  if (res.ok){
    state.profile = { name: res.name, token: res.token, verified: true, hasPass: !!res.hasPass };
    toast({ text: profileMode === 'account' ? 'Kontot sparat.' : `Välkommen, ${res.name}!`, kind: 'good' });
    profileDone();
  } else if (res.offline || res.timeout){
    profileSetStatus('Kan inte nå servern just nu.', 'warn');
    $('#profileOffline').hidden = false;
    go.disabled = false;
  } else {
    profileSetStatus(res.reason || 'Namnet är redan taget.', 'bad');
    go.disabled = false;
  }
}

function bootProfile(){
  const input = $('#profileName');
  input.addEventListener('input', () => { input.value = input.value.replace(/\s/g, ''); profileValidate(); });
  $('#profilePass').addEventListener('input', () => profileValidate());
  const enter = e => { if (e.key === 'Enter' && !$('#profileGo').disabled) $('#profileGo').click(); };
  input.addEventListener('keydown', enter);
  $('#profilePass').addEventListener('keydown', enter);
  $$('#profileTabs button').forEach(b => click(b, () => {
    const m = b.dataset.pmode;
    setProfileMode(m === 'new' && profileRename && state.profile.name ? 'account' : m);
  }));
  click($('#profileBack'), () => show('menu'));
  click($('#profileGo'), profileSubmit);
  click($('#profileOffline'), () => {
    const name = ($('#profileName').value || '').trim();
    if (!NAME_RE.test(name)){ profileSetStatus('Skriv ett giltigt namn först.', 'bad'); return; }
    state.profile = { name, token: state.profile.token || '', verified: false };
    profileDone();
  });
}
