/* =========================================================
   IRONFRONT — ljud
   Allt syntetiseras i webbläsaren. Inga ljudfiler att ladda,
   inga licenser att hålla reda på, och varje skott får en
   liten slumpvariation så att eldgivning inte blir en loop.
   ========================================================= */
import { state } from './state.js';
import { clamp, rand } from './util.js';

let ctx = null, master = null, sfxBus = null, musicBus = null, noise = null;
let musicNodes = null, started = false;
const lastPlay = new Map();

/** Startas vid första klick/tangent — webbläsare tillåter inte ljud innan dess. */
export function unlock(){
  if (ctx) { if (ctx.state === 'suspended') ctx.resume(); return; }
  const AC = window.AudioContext || window.webkitAudioContext;
  if (!AC) return;
  ctx = new AC();

  master = ctx.createGain();
  const comp = ctx.createDynamicsCompressor();
  comp.threshold.value = -16; comp.knee.value = 22; comp.ratio.value = 7;
  comp.attack.value = 0.003; comp.release.value = 0.22;
  master.connect(comp); comp.connect(ctx.destination);

  sfxBus = ctx.createGain(); sfxBus.connect(master);
  musicBus = ctx.createGain(); musicBus.connect(master);

  // Ett vitt brus återanvänds för allt perkussivt.
  noise = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
  const d = noise.getChannelData(0);
  for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;

  applyVolumes();
  started = true;
}

export function applyVolumes(){
  if (!ctx) return;
  const s = state.settings;
  master.gain.value   = clamp(s.master, 0, 1);
  sfxBus.gain.value   = clamp(s.sfx, 0, 1) * 0.9;
  musicBus.gain.value = clamp(s.music, 0, 1) * 0.5;
}

/* ---------- byggstenar ---------- */
function env(node, t0, peak, attack, decay){
  const g = ctx.createGain();
  g.gain.setValueAtTime(0.0001, t0);
  g.gain.exponentialRampToValueAtTime(Math.max(0.0002, peak), t0 + attack);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + attack + decay);
  node.connect(g);
  return g;
}
function osc(type, freq, t0, dur){
  const o = ctx.createOscillator();
  o.type = type; o.frequency.setValueAtTime(freq, t0);
  o.start(t0); o.stop(t0 + dur + 0.02);
  return o;
}
function noiseSrc(t0, dur, rate = 1){
  const n = ctx.createBufferSource();
  n.buffer = noise; n.loop = true; n.playbackRate.value = rate;
  n.start(t0, Math.random() * 1.5); n.stop(t0 + dur + 0.02);
  return n;
}
function filt(type, freq, q = 1){
  const f = ctx.createBiquadFilter();
  f.type = type; f.frequency.value = freq; f.Q.value = q;
  return f;
}
/** Enkel panorering utifrån var på skärmen ljudet hörs. */
function out(node, pan = 0, bus = sfxBus){
  if (ctx.createStereoPanner){
    const p = ctx.createStereoPanner();
    p.pan.value = clamp(pan, -1, 1);
    node.connect(p); p.connect(bus);
  } else node.connect(bus);
}

/**
 * Spelar ett ljud.
 * @param {string} name  ljudets id
 * @param {object} o     {vol, pan, pitch} — pan −1..1, pitch multiplicerar frekvenser
 */
export function sfx(name, o = {}){
  if (!started || !ctx || ctx.state !== 'running') return;
  if (state.settings.sfx <= 0) return;

  // Skyddar öronen (och processorn) vid tre montage som skjuter samtidigt.
  const now = ctx.currentTime;
  const gap = THROTTLE[name] || 0;
  if (gap){
    const prev = lastPlay.get(name) || 0;
    if (now - prev < gap) return;
    lastPlay.set(name, now);
  }

  const v = (o.vol ?? 1), pan = o.pan ?? 0, p = o.pitch ?? 1;
  const t = now + 0.001;
  const R = (a, b) => rand(a, b); // kort alias för variation

  switch (name){
    case 'slug': {
      const n = noiseSrc(t, .12, 1.4);
      const f = filt('bandpass', 1500 * p * R(1.1, .92), 1.1);
      n.connect(f); out(env(f, t, .5 * v, .002, .1), pan);
      const b = osc('triangle', 140 * p, t, .12);
      b.frequency.exponentialRampToValueAtTime(48, t + .1);
      out(env(b, t, .45 * v, .003, .1), pan);
      break;
    }
    case 'rapid': {
      const n = noiseSrc(t, .07, 1.9);
      const f = filt('bandpass', 2600 * p * R(1.14, .88), 1.6);
      n.connect(f); out(env(f, t, .3 * v, .001, .055), pan);
      const b = osc('square', 220 * p * R(1.1, .9), t, .06);
      b.frequency.exponentialRampToValueAtTime(90, t + .05);
      out(env(b, t, .2 * v, .001, .05), pan);
      break;
    }
    case 'shell': {
      const n = noiseSrc(t, .34, .8);
      const f = filt('lowpass', 900, .8);
      f.frequency.exponentialRampToValueAtTime(140, t + .3);
      n.connect(f); out(env(f, t, .75 * v, .004, .3), pan);
      const b = osc('sine', 92 * p, t, .34);
      b.frequency.exponentialRampToValueAtTime(34, t + .3);
      out(env(b, t, .85 * v, .004, .3), pan);
      break;
    }
    case 'burst': {
      const n = noiseSrc(t, .2, 1.2);
      const f = filt('highpass', 700, .7);
      n.connect(f); out(env(f, t, .5 * v, .002, .17), pan);
      break;
    }
    case 'laser': {
      const o1 = osc('sawtooth', 1750 * p * R(1.06, .95), t, .16);
      o1.frequency.exponentialRampToValueAtTime(320 * p, t + .14);
      const f = filt('bandpass', 1900, 5);
      o1.connect(f); out(env(f, t, .34 * v, .001, .14), pan);
      break;
    }
    case 'plasma': {
      const o1 = osc('sawtooth', 320 * p, t, .3);
      const o2 = osc('sine', 163 * p, t, .3);
      const f = filt('lowpass', 480, 7);
      f.frequency.exponentialRampToValueAtTime(2800, t + .1);
      f.frequency.exponentialRampToValueAtTime(240, t + .28);
      o1.connect(f); o2.connect(f);
      out(env(f, t, .5 * v, .006, .26), pan);
      break;
    }
    case 'missile': {
      const n = noiseSrc(t, .5, .9);
      const f = filt('bandpass', 700, 1.4);
      f.frequency.exponentialRampToValueAtTime(2200, t + .45);
      n.connect(f); out(env(f, t, .35 * v, .03, .42), pan);
      break;
    }
    case 'hit': {
      const n = noiseSrc(t, .07, 2.2);
      const f = filt('bandpass', 3200 * R(1.2, .8), 2);
      n.connect(f); out(env(f, t, .34 * v, .001, .055), pan);
      break;
    }
    case 'hitShield': {
      const o1 = osc('sine', 880 * R(1.1, .9), t, .18);
      o1.frequency.exponentialRampToValueAtTime(1600, t + .14);
      out(env(o1, t, .3 * v, .002, .15), pan);
      break;
    }
    case 'hurt': {
      const n = noiseSrc(t, .3, .6);
      const f = filt('lowpass', 520, 1);
      n.connect(f); out(env(f, t, .6 * v, .003, .26), pan);
      const b = osc('sine', 70, t, .3);
      out(env(b, t, .6 * v, .004, .25), pan);
      break;
    }
    case 'explosion': {
      const n = noiseSrc(t, .9, .55);
      const f = filt('lowpass', 1800, .6);
      f.frequency.exponentialRampToValueAtTime(90, t + .8);
      n.connect(f); out(env(f, t, 1.0 * v, .006, .8), pan);
      const b = osc('sine', 110, t, .8);
      b.frequency.exponentialRampToValueAtTime(26, t + .7);
      out(env(b, t, .9 * v, .006, .7), pan);
      break;
    }
    case 'kill': {
      const o1 = osc('triangle', 520 * R(1.15, .85), t, .25);
      o1.frequency.exponentialRampToValueAtTime(120, t + .22);
      out(env(o1, t, .3 * v, .002, .2), pan);
      const n = noiseSrc(t, .25, 1.1);
      const f = filt('bandpass', 1800, 1.2);
      n.connect(f); out(env(f, t, .25 * v, .002, .2), pan);
      break;
    }
    case 'reload': {
      [0, .12].forEach((d, i) => {
        const n = noiseSrc(t + d, .06, 1.6);
        const f = filt('bandpass', i ? 1100 : 2400, 3);
        n.connect(f); out(env(f, t + d, .3 * v, .001, .05), pan);
      });
      break;
    }
    case 'dry': {
      const n = noiseSrc(t, .04, 2.6);
      const f = filt('highpass', 2600, 1);
      n.connect(f); out(env(f, t, .22 * v, .001, .03), pan);
      break;
    }
    case 'ui': {
      const o1 = osc('square', 880, t, .05);
      out(env(o1, t, .12 * v, .001, .04), 0);
      break;
    }
    case 'uiHover': {
      const o1 = osc('sine', 1320, t, .04);
      out(env(o1, t, .05 * v, .001, .03), 0);
      break;
    }
    case 'uiBig': {
      [523, 784, 1046].forEach((f0, i) => {
        const o1 = osc('triangle', f0, t + i * .05, .3);
        out(env(o1, t + i * .05, .16 * v, .01, .28), 0);
      });
      break;
    }
    case 'alarm': {
      [0, .26].forEach(d => {
        const o1 = osc('square', d ? 440 : 660, t + d, .2);
        const f = filt('lowpass', 1400, 1);
        o1.connect(f); out(env(f, t + d, .22 * v, .01, .18), 0);
      });
      break;
    }
    case 'pickup': {
      const o1 = osc('sine', 660, t, .18);
      o1.frequency.exponentialRampToValueAtTime(1320, t + .14);
      out(env(o1, t, .22 * v, .003, .15), pan);
      break;
    }
    case 'ability': {
      const o1 = osc('sawtooth', 180, t, .4);
      o1.frequency.exponentialRampToValueAtTime(900, t + .3);
      const f = filt('lowpass', 900, 6);
      f.frequency.exponentialRampToValueAtTime(3000, t + .3);
      o1.connect(f); out(env(f, t, .3 * v, .01, .35), pan);
      break;
    }
  }
}

/** Ljud som annars skulle spelas 30 gånger per sekund. Sekunder mellan spelningar. */
const THROTTLE = { rapid: .045, slug: .05, hit: .035, burst: .06, laser: .05 };

/* ---------- Musikbädd ----------
   En långsam drone som ligger under hela striden. Intensiteten
   öppnar filtret och lägger på en puls när det hettar till. */
export function startMusic(){
  if (!started || musicNodes || state.settings.music <= 0) return;
  const t = ctx.currentTime;
  const g = ctx.createGain(); g.gain.value = 0;
  const lp = filt('lowpass', 320, 1.6);
  lp.connect(g); g.connect(musicBus);
  g.gain.linearRampToValueAtTime(.9, t + 3);

  const freqs = [55, 82.4, 110.5, 164.8];
  const oscs = freqs.map((f, i) => {
    const o = ctx.createOscillator();
    o.type = i % 2 ? 'sawtooth' : 'triangle';
    o.frequency.value = f * (1 + (i - 1.5) * 0.0018);
    const og = ctx.createGain(); og.gain.value = i === 3 ? .10 : .26;
    o.connect(og); og.connect(lp); o.start(t);
    return o;
  });

  // Långsam svävning i filtret så att bädden aldrig står helt still.
  const lfo = ctx.createOscillator(); lfo.frequency.value = 0.045;
  const lfoGain = ctx.createGain(); lfoGain.gain.value = 90;
  lfo.connect(lfoGain); lfoGain.connect(lp.frequency); lfo.start(t);

  // Puls som bara hörs när intensiteten är hög (boss, sista vågen).
  const pulseGain = ctx.createGain(); pulseGain.gain.value = 0;
  const pulseOsc = ctx.createOscillator(); pulseOsc.type = 'sine'; pulseOsc.frequency.value = 41.2;
  pulseOsc.connect(pulseGain); pulseGain.connect(musicBus); pulseOsc.start(t);

  musicNodes = { g, lp, oscs, lfo, lfoGain, pulseGain, pulseOsc, pulseTimer: 0, intensity: 0 };
}

export function stopMusic(){
  if (!musicNodes) return;
  const t = ctx.currentTime;
  musicNodes.g.gain.cancelScheduledValues(t);
  musicNodes.g.gain.setValueAtTime(musicNodes.g.gain.value, t);
  musicNodes.g.gain.linearRampToValueAtTime(0.0001, t + 1.2);
  const n = musicNodes;
  setTimeout(() => {
    try{
      n.oscs.forEach(o => o.stop());
      n.lfo.stop(); n.pulseOsc.stop();
    }catch{ /* redan stoppade */ }
  }, 1400);
  musicNodes = null;
}

/** 0 = lugnt, 1 = boss. Ändrar klangfärg, inte bara volym. */
export function setIntensity(x){
  if (!musicNodes) return;
  const v = clamp(x, 0, 1);
  musicNodes.intensity = v;
  const t = ctx.currentTime;
  musicNodes.lp.frequency.setTargetAtTime(280 + v * 1100, t, 1.2);
  musicNodes.pulseGain.gain.setTargetAtTime(v > .55 ? .12 : 0, t, .8);
}

/** Anropas varje bildruta — ger pulsen sitt hjärtslag. */
export function tickMusic(dt){
  if (!musicNodes || musicNodes.intensity <= .55) return;
  musicNodes.pulseTimer -= dt;
  if (musicNodes.pulseTimer <= 0){
    musicNodes.pulseTimer = 640;
    const t = ctx.currentTime;
    musicNodes.pulseGain.gain.setValueAtTime(.2, t);
    musicNodes.pulseGain.gain.exponentialRampToValueAtTime(.005, t + .5);
  }
}

export const audioReady = () => started;
