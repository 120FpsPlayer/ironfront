/* =========================================================
   IRONFRONT — nätverk (co-op)
   Pratar med lobbyservern i server/server.js via WebSocket.
   Serveradressen sparas i inställningarna; standard är den
   lokala servern (ws://localhost:8787), så att man kan spela
   på samma dator eller i samma nätverk direkt.

   Allt annat i spelet pratar bara med funktionerna här — byts
   servern ut mot en riktig på internet är det bara adressen
   som ändras.
   ========================================================= */
import { MULTI_MAX_PLAYERS } from './data.js';
import { state, save } from './state.js';
import { log } from './util.js';

/* Serveradressen som är inbyggd i spelfilen — sätts överst i index.html
   (IRONFRONT_SERVER). Då kopplar spelet upp sig mot din server direkt,
   utan att någon behöver skriva in en adress. */
export const DEFAULT_SERVER = (typeof window !== 'undefined' && window.IRONFRONT_SERVER) || 'ws://localhost:8787';
export const serverUrl = () => state.settings.server || DEFAULT_SERVER;
export function setServerUrl(url){
  // Samma som den inbyggda adressen → spara inget, så att en ny adress i
  // spelfilen alltid slår igenom. Bara en egen, annan adress sparas.
  const u = String(url || '').trim();
  state.settings.server = u && u !== DEFAULT_SERVER ? u : '';
  save();
}

const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
export const validCode = code => new RegExp(`^[${CODE_CHARS}]{6}$`).test(String(code || '').toUpperCase());

let ws = null;
let myId = null;
let lobby = null;
const listeners = new Map();   // typ → Set<fn>

/** Lyssna på meddelanden från servern: 'lobby', 'start', 'relay', 'left', 'closed', 'error', 'down'. */
export function onNet(type, fn){
  if (!listeners.has(type)) listeners.set(type, new Set());
  listeners.get(type).add(fn);
  return () => listeners.get(type)?.delete(fn);
}
function emit(type, msg){
  for (const fn of [...(listeners.get(type) || [])]) { try { fn(msg); } catch (e) { log.error('[net]', e); } }
}

export const netConnected = () => !!ws && ws.readyState === 1;
export const netOnline = netConnected;
export const myNetId = () => myId;
export const currentLobby = () => lobby;
export const isHost = () => !!lobby && lobby.host === myId;

function connect(){
  if (netConnected()) return Promise.resolve();
  if (typeof WebSocket === 'undefined') return Promise.reject(new Error('Webbläsaren saknar WebSocket.'));
  return new Promise((resolve, reject) => {
    let settled = false;
    let sock;
    try { sock = new WebSocket(serverUrl()); }
    catch { reject(new Error(`Ogiltig serveradress: ${serverUrl()}`)); return; }
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      try { sock.close(); } catch {}
      reject(new Error(`Servern svarar inte (${serverUrl()}).`));
    }, 4000);
    sock.onmessage = ev => {
      let m; try { m = JSON.parse(ev.data); } catch { return; }
      if (m.t === 'welcome'){
        myId = m.id;
        if (!settled){ settled = true; clearTimeout(timer); ws = sock; resolve(); }
        return;
      }
      if (m.t === 'lobby') lobby = m;
      if (m.t === 'closed') lobby = null;
      emit(m.t, m);
    };
    sock.onerror = () => {
      if (!settled){ settled = true; clearTimeout(timer); reject(new Error(`Kunde inte nå servern (${serverUrl()}). Är den igång?`)); }
    };
    sock.onclose = () => {
      const wasLive = ws === sock;
      if (wasLive){ ws = null; lobby = null; emit('down', {}); }
      if (!settled){ settled = true; clearTimeout(timer); reject(new Error('Anslutningen stängdes.')); }
    };
  });
}

function send(msg){ if (netConnected()) ws.send(JSON.stringify(msg)); }

/** Väntar på nästa lobby- eller felmeddelande efter en förfrågan. */
function awaitLobby(){
  return new Promise(resolve => {
    let done = false;
    const finish = r => { if (done) return; done = true; offL(); offE(); resolve(r); };
    const offL = onNet('lobby', m => finish({ ok: true, ...m }));
    const offE = onNet('error', m => finish({ ok: false, reason: m.reason }));
    setTimeout(() => finish({ ok: false, reason: 'Servern svarade inte.' }), 5000);
  });
}

/** Väntar på ett svar av en viss typ. */
function awaitType(type, match = () => true){
  return new Promise(resolve => {
    let done = false;
    const off = onNet(type, m => { if (done || !match(m)) return; done = true; off(); resolve(m); });
    setTimeout(() => { if (done) return; done = true; off(); resolve({ ok: false, reason: 'Servern svarade inte.', timeout: true }); }, 5000);
  });
}

/** Är namnet ledigt? { ok, reason } — eller { ok:false, offline:true } om servern inte nås. */
export async function checkName(name, token){
  try { await connect(); } catch (e) { return { ok: false, offline: true, reason: e.message }; }
  const wait = awaitType('check');
  send({ t: 'check', name, token });
  return wait;
}

/** Tar namnet. Svarar med { ok, name, token } — token sparas i sparfilen. */
export async function claimName(name, token, password){
  try { await connect(); } catch (e) { return { ok: false, offline: true, reason: e.message }; }
  const wait = awaitType('claim');
  send({ t: 'claim', name, token, password });
  return wait;
}

/** Logga in med namn + lösenord (t.ex. på en ny dator). Svarar med nyckel och molnsparfil. */
export async function loginAccount(name, password){
  try { await connect(); } catch (e) { return { ok: false, offline: true, reason: e.message }; }
  const wait = awaitType('login');
  send({ t: 'login', name, password });
  return wait;
}

/** Molnsparning: laddar upp hela sparfilen. */
export async function cloudSave(name, token, data){
  try { await connect(); } catch (e) { return { ok: false, offline: true }; }
  const wait = awaitType('saved');
  send({ t: 'save', name, token, data });
  return wait;
}

/** Topplista: kind = 'level' | 'sector' | 'score' | 'weekly'. */
export async function getTop(kind, name){
  try { await connect(); } catch (e) { return { ok: false, offline: true, reason: e.message }; }
  const wait = awaitType('top', m => m.kind === kind);   // flera listor kan hämtas samtidigt
  send({ t: 'top', kind, name });
  const r = await wait;
  return r.timeout ? r : { ok: true, ...r };
}

/** Skapar en lobby. player = { name, robot, slot }. */
export async function createLobby(player){
  try { await connect(); } catch (e) { return { ok: false, reason: e.message }; }
  send({ t: 'hello', ...player });
  const wait = awaitLobby();
  send({ t: 'create' });
  return wait;
}

/** Går med i en lobby via kod. */
export async function joinLobby(code, player){
  if (!validCode(code)) return { ok: false, reason: 'Ogiltig kod — sex tecken, bokstäver och siffror.' };
  try { await connect(); } catch (e) { return { ok: false, reason: e.message }; }
  send({ t: 'hello', ...player });
  const wait = awaitLobby();
  send({ t: 'join', code: String(code).toUpperCase() });
  return wait;
}

/* Närvaro och aktivitet: spelet säger till servern när man kommer in i
   hangaren, startar en utryckning och hur den slutade — så att servern
   kan logga vem som spelar vad. Tyst: går servern inte att nå händer inget. */
export async function presence(player){
  if (!player?.name) return;
  try { await connect(); } catch { return; }
  send({ t: 'hello', ...player });
}
export function activity(kind, data){ if (netConnected()) send({ t: 'activity', kind, data }); }

export function setReady(ready){ send({ t: 'ready', ready }); }
export function startMatch(params){ send({ t: 'start', params }); }
/** Värden avslutar matchen. result = { reason, wave, kills, score } — hamnar i serverloggen. */
export function endMatch(result){ send({ t: 'end', result }); }
export function relay(data){ send({ t: 'relay', data }); }
export function leaveLobby(){
  send({ t: 'leave' });
  lobby = null;
}
export const maxPlayers = MULTI_MAX_PLAYERS;
