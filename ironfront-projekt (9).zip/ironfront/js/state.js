/* =========================================================
   IRONFRONT — beständigt tillstånd
   Sparas i localStorage. Schemat är versionsmärkt så att
   gamla sparfiler kan migreras istället för att slängas.
   ========================================================= */
import { ROBOTS, ROBOT_ORDER, WEAPONS, ECONOMY, SLOT_PRICES, STORY_CHAPTERS, GAME_MODES, PAINTS,
         MAX_LEVEL, xpForLevel, levelForXp, LEVEL_UNLOCKS, SLOT_LEVELS, levelReward, unlockLevel, TITLES, titleFor } from './data.js';
import { bus, clamp, log } from './util.js';

const KEY = 'ironfront.save';
const SCHEMA = 4;

export function emptySave(){
  return {
    v: SCHEMA,
    currency: { ag: 1800, au: 0, pl: 0 },
    // Nivå 1 tills träningen är klar, sedan nivå 2 och XP därifrån
    level: 1,
    xp: 0,
    // Användarnamn. token = hemlig nyckel från servern som bevisar att
    // namnet är ditt; verified = servern har godkänt det.
    profile: { name: '', token: '', verified: false },
    // Dagliga uppdrag, prestationer och inloggningsbonus (se progress.js)
    daily: { date: '', list: [] },
    achievements: {},
    streak: { last: '', days: 0, best: 0 },
    counters: { eventsDone: 0, dailyDone: 0, coopWins: 0, bossNoDamage: 0, pickups: 0, abilities: 0, eliteKills: 0 },
    // Nytt befäl börjar med en tom hangar — guiden visar hur man
    // köper sin första robot. Plats 2 och 3 köps efter träningen.
    bays: [null, null, null],
    slotsUnlocked: 1,
    selected: 0,
    mode: 'sectors',
    story: { done: [] },
    weekly: { id: null, done: false, best: 0 },
    ownedWeapons: ['slug_light', 'slug_std'],
    ownedPaints: ['standard'],
    sector: 1,
    bestWave: 0,
    bestScore: 0,
    career: { kills: 0, waves: 0, runs: 0, bosses: 0, damage: 0, ms: 0 },
    quests: { noDamage5: false, wave10: false, bossSolo: false, sector2: false },
    flags: { tutorialDone: false, battleTutDone: false, hangarTut2Done: false, seenIntro: false },
    settings: {
      master: 0.8, sfx: 0.9, music: 0.45,
      shake: 1, dmgNumbers: true, particles: 1, minimap: true,
      difficulty: 'soldat', showFps: false, aimAssist: true,   // svårigheten är låst — alla spelar på samma
      playerName: 'Befäl', server: ''
    }
  };
}

export function makeSlot(tplId){
  const tpl = ROBOTS[tplId];
  return {
    tpl: tplId,
    lvl: { hp: 0, shield: 0, ability: 0, speed: 0 },
    weapons: tpl.mounts.map(() => tpl.defaultWeapon),
    mountLvls: tpl.mounts.map(() => ({ dmg: 0, rate: 0, reload: 0, mag: 0 })),
    extraUnlocked: false,
    extraWeapon: 'slug_light',
    extraLvl: { dmg: 0, rate: 0, reload: 0, mag: 0 },
    paint: 'standard'
  };
}

/* Objektet byts aldrig ut, bara innehållet. Det gör att varje modul
   som importerar `state` alltid ser samma aktuella data — hade vi
   tilldelat om variabeln skulle den som destrukturerat den sitta kvar
   med en gammal kopia. */
export const state = emptySave();

function replaceState(next){
  for (const k of Object.keys(state)) delete state[k];
  Object.assign(state, next);
  return state;
}

/* ---------- Läsa / skriva ---------- */
export function load(){
  try{
    const raw = localStorage.getItem(KEY);
    if (!raw){ replaceState(emptySave()); return false; }
    replaceState(migrate(JSON.parse(raw)));
    repair();
    return true;
  }catch(err){
    log.warn('Sparfilen gick inte att läsa, startar om:', err);
    replaceState(emptySave());
    return false;
  }
}

let saveTimer = null;
export function save(immediate = false){
  const write = () => {
    try{ localStorage.setItem(KEY, JSON.stringify(state)); }
    catch(err){ log.warn('Kunde inte spara:', err); }
    saveTimer = null;
    bus.emit('save:written');           // molnsparningen lyssnar på den här
  };
  if (immediate){ if (saveTimer) clearTimeout(saveTimer); write(); return; }
  if (saveTimer) return;
  saveTimer = setTimeout(write, 400);
}

/** Ersätter hela spelläget med en sparfil (t.ex. från molnet) och sparar lokalt. */
export function loadFrom(data){
  replaceState(migrate(data));
  repair();
  save(true);
}

export function hasSave(){ try{ return !!localStorage.getItem(KEY); }catch{ return false; } }

export function resetSave(keepSettings = true){
  const s = keepSettings ? { ...state.settings } : null;
  replaceState(emptySave());
  if (s) state.settings = s;
  save(true);
  bus.emit('state:changed');
}

/** Äldre sparfiler fylls på med det som saknas istället för att kastas. */
function migrate(data){
  const base = emptySave();
  if (!data || typeof data !== 'object') return base;
  const out = { ...base, ...data, v: SCHEMA };
  out.currency = { ...base.currency, ...(data.currency || {}) };
  out.career   = { ...base.career,   ...(data.career   || {}) };
  out.quests   = { ...base.quests,   ...(data.quests   || {}) };
  out.flags    = { ...base.flags,    ...(data.flags    || {}) };
  out.settings = { ...base.settings, ...(data.settings || {}) };
  out.story    = { ...base.story,    ...(data.story    || {}) };
  out.weekly   = { ...base.weekly,   ...(data.weekly   || {}) };
  out.profile  = { ...base.profile,  ...(data.profile  || {}) };
  out.daily    = { ...base.daily,    ...(data.daily    || {}) };
  out.streak   = { ...base.streak,   ...(data.streak   || {}) };
  out.counters = { ...base.counters, ...(data.counters || {}) };
  out.achievements = { ...(data.achievements || {}) };

  // Sparfiler från före schema 3 hade alla tre platser öppna och ingen
  // guide. Ta inte ifrån någon något — och visa inte guiden för den som
  // redan spelat förbi träningen.
  if ((data.v || 0) < 3){
    out.slotsUnlocked = 3;
    if ((data.sector || 1) > 1){
      out.flags.tutorialDone = true;
      out.flags.battleTutDone = true;
      out.flags.hangarTut2Done = true;
    } else if ((data.bays || []).some(Boolean)){
      out.flags.tutorialDone = true;
    }
  }

  // Före schema 4 fanns inga nivåer. Den som redan klarat träningen får
  // en nivå som motsvarar hur mycket den har spelat, räknat på samma sätt
  // som XP räknas nu. Inget som redan köpts tas bort.
  if ((data.v || 0) < 4){
    if ((data.sector || 1) > 1){
      const c = { ...base.career, ...(data.career || {}) };
      out.xp = Math.round(c.waves * 15 + c.kills * 2 + c.bosses * 50);
      out.level = levelForXp(out.xp);
    } else {
      out.level = 1; out.xp = 0;
    }
  }
  return out;
}

/** Skyddsnät mot trasig data (handredigerad sparfil, gammal robotid, m.m.) */
function repair(){
  if (!Array.isArray(state.bays) || state.bays.length !== 3) state.bays = [null, null, null];
  state.slotsUnlocked = clamp(state.slotsUnlocked | 0 || 1, 1, 3);
  state.bays = state.bays.map(slot => {
    if (!slot) return null;
    if (!ROBOTS[slot.tpl]) return null;
    const tpl = ROBOTS[slot.tpl];
    slot.lvl = { hp: 0, shield: 0, ability: 0, speed: 0, ...(slot.lvl || {}) };
    if (!Array.isArray(slot.weapons) || slot.weapons.length !== tpl.mounts.length)
      slot.weapons = tpl.mounts.map(() => tpl.defaultWeapon);
    slot.weapons = slot.weapons.map(w => WEAPONS[w] ? w : tpl.defaultWeapon);
    if (!Array.isArray(slot.mountLvls) || slot.mountLvls.length !== tpl.mounts.length)
      slot.mountLvls = tpl.mounts.map(() => ({ dmg: 0, rate: 0, reload: 0, mag: 0 }));
    slot.extraLvl = { dmg: 0, rate: 0, reload: 0, mag: 0, ...(slot.extraLvl || {}) };
    if (!WEAPONS[slot.extraWeapon]) slot.extraWeapon = 'slug_light';
    return slot;
  });
  // En tom flotta är bara giltig medan första guiden pågår
  if (!state.bays.some(Boolean) && state.flags.tutorialDone) state.bays[0] = makeSlot('recon');
  // Robotar i platser som inte är upplåsta (handredigerad fil) flyttas inte — platsen låses upp
  state.bays.forEach((b, i) => { if (b && i >= state.slotsUnlocked) state.slotsUnlocked = i + 1; });
  state.selected = clamp(state.selected | 0, 0, 2);
  if (!state.bays[state.selected]) state.selected = Math.max(0, state.bays.findIndex(Boolean));
  if (!GAME_MODES[state.mode]) state.mode = 'sectors';
  state.settings.difficulty = 'soldat';           // ingen kan ändra svårigheten längre
  state.settings.server = '';                      // alla använder servern som är inbyggd i spelfilen
  if (!state.profile || typeof state.profile !== 'object') state.profile = { name: '', token: '', verified: false };
  if (!Array.isArray(state.ownedPaints)) state.ownedPaints = ['standard'];
  state.ownedPaints = [...new Set(['standard', ...state.ownedPaints.filter(id => PAINTS[id])])];
  for (const b of state.bays) if (b && (!PAINTS[b.paint] || !state.ownedPaints.includes(b.paint))) b.paint = 'standard';
  if (!Array.isArray(state.story.done)) state.story.done = [];
  state.story.done = state.story.done.filter(id => STORY_CHAPTERS.some(c => c.id === id));
  state.ownedWeapons = [...new Set((state.ownedWeapons || []).filter(w => WEAPONS[w]))];
  if (!state.ownedWeapons.length) state.ownedWeapons = ['slug_light'];
  ROBOT_ORDER.forEach(id => { if (ROBOTS[id].free) addWeapon(ROBOTS[id].defaultWeapon, true); });
  state.sector = Math.max(1, state.sector | 0);
}

/* ---------- Ekonomi ---------- */
export const priceEmpty = p => !p || (!p.ag && !p.au && !p.pl);

export function canAfford(price){
  if (priceEmpty(price)) return true;
  return state.currency.ag >= (price.ag || 0)
      && state.currency.au >= (price.au || 0)
      && state.currency.pl >= (price.pl || 0);
}

export function spend(price){
  if (!canAfford(price)) return false;
  state.currency.ag -= price.ag || 0;
  state.currency.au -= price.au || 0;
  state.currency.pl -= price.pl || 0;
  save(); bus.emit('state:changed');
  return true;
}

export function grant({ ag = 0, au = 0, pl = 0 }){
  state.currency.ag += ag;
  state.currency.au += au;
  state.currency.pl += pl;
  save(); bus.emit('state:changed');
}

export function addWeapon(id, silent = false){
  if (!WEAPONS[id] || state.ownedWeapons.includes(id)) return false;
  state.ownedWeapons.push(id);
  if (!silent){ save(); bus.emit('state:changed'); }
  return true;
}

export const ownsWeapon = id => state.ownedWeapons.includes(id);
export const selectedSlot = () => state.bays[state.selected] || null;

/* ---------- Nivåberäkning ---------- */
export function slotLevel(slot){
  if (!slot) return 0;
  let n = 1 + slot.lvl.hp + slot.lvl.shield + slot.lvl.ability + slot.lvl.speed;
  slot.mountLvls.forEach(m => { n += m.dmg + m.rate + m.reload + m.mag; });
  if (slot.extraUnlocked){ const e = slot.extraLvl; n += e.dmg + e.rate + e.reload + e.mag; }
  return n;
}

/** Kostnad för nästa nivå på en given uppgradering. */
export function upgradePrice(kindBase, lvl){
  return { ag: ECONOMY.upgradeCost(kindBase, lvl), au: 0, pl: 0 };
}

export const EXTRA_MOUNT_PRICE = { ag: 0, au: 45, pl: 0 };

/* ---------- Robotplatser och spellägen ---------- */
export const slotPrice = i => SLOT_PRICES[i] || null;
export const slotUnlocked = i => i < state.slotsUnlocked;

/** Alla spellägen utöver träningen öppnas när sektor 1 är klar. */
export const modesUnlocked = () => state.level >= 2;

/** Köper nästa lediga plats. Platserna låses upp i ordning. */
export function buySlot(i){
  if (i !== state.slotsUnlocked || i > 2) return false;
  if (state.level < SLOT_LEVELS[i]) return false;
  if (!spend(slotPrice(i))) return false;
  state.slotsUnlocked = i + 1;
  save(true); bus.emit('state:changed');
  return true;
}

/** Nästa kapitel som inte är klart, eller null om alla är klara. */
export function nextStoryChapter(){
  return STORY_CHAPTERS.find(c => !state.story.done.includes(c.id)) || null;
}
/** Ett kapitel är spelbart om det är klart eller om alla före det är klara. */
export function chapterOpen(id){
  const idx = STORY_CHAPTERS.findIndex(c => c.id === id);
  return STORY_CHAPTERS.slice(0, idx).every(c => state.story.done.includes(c.id));
}

/* ---------- Lackeringar ---------- */
export const ownsPaint = id => state.ownedPaints.includes(id);
/** Färgen en robot faktiskt har: vald lackering, annars fabriksfärgen. */
export function slotColor(slot){
  const p = PAINTS[slot?.paint];
  return (p && p.color) || ROBOTS[slot?.tpl]?.color || '#8fd3e6';
}

/* =========================================================
   NIVÅER OCH XP
   ========================================================= */
/** Hur långt man kommit mot nästa nivå. */
export function levelProgress(){
  const L = state.level;
  if (L < 2) return { level: L, into: 0, need: 1, pct: 0, max: false };
  if (L >= MAX_LEVEL) return { level: L, into: 0, need: 0, pct: 1, max: true };
  const lo = xpForLevel(L), hi = xpForLevel(L + 1);
  return { level: L, into: state.xp - lo, need: hi - lo, pct: (state.xp - lo) / (hi - lo), max: false };
}

/** Får spelaren använda/köpa den här roboten eller det här vapnet? */
export function levelAllows(kind, id){ return state.level >= unlockLevel(kind, id); }

/** Allt som låses upp mellan två nivåer (för notiser och resultatskärmen). */
export function unlocksBetween(from, to){
  const list = [];
  for (let L = from + 1; L <= to; L++){
    const u = LEVEL_UNLOCKS[L];
    if (!u) continue;
    for (const id of u.robots || []) list.push({ L, kind: 'robot', id, name: ROBOTS[id]?.name });
    for (const id of u.weapons || []) list.push({ L, kind: 'weapon', id, name: WEAPONS[id]?.name });
    if (u.slot) list.push({ L, kind: 'slot', name: `Robotplats ${u.slot} kan köpas` });
    if (u.modes) list.push({ L, kind: 'modes', name: 'Story, Utmaning och Multiplayer' });
    for (const id of u.paints || []) list.push({ L, kind: 'paint', id, name: PAINTS[id]?.name + ' (lackering)' });
  }
  for (const t of TITLES) if (t.level > from && t.level <= to && t.level > 1) list.push({ L: t.level, kind: 'title', name: `Titeln ${t.name}` });
  return list;
}

/** Sätter nivån och delar ut belöningar för varje nivå man passerade. */
function reachLevel(to){
  const from = state.level;
  if (to <= from) return null;
  state.level = to;
  const reward = { ag: 0, au: 0, pl: 0 };
  for (let L = from + 1; L <= to; L++){
    const r = levelReward(L);
    reward.ag += r.ag; reward.au += r.au; reward.pl += r.pl;
    for (const id of LEVEL_UNLOCKS[L]?.paints || []) if (!state.ownedPaints.includes(id)) state.ownedPaints.push(id);
  }
  state.currency.ag += reward.ag; state.currency.au += reward.au; state.currency.pl += reward.pl;
  const unlocks = unlocksBetween(from, to);
  bus.emit('level:up', { from, to, unlocks, reward });
  return { from, to, unlocks, reward };
}

/** Träningen klar: direkt till nivå 2. */
export function completeTraining(){
  if (state.level >= 2) return null;
  state.xp = xpForLevel(2);
  return reachLevel(2);
}

/** Lägger till XP (bara från nivå 2 och uppåt) och går upp i nivå om det räcker. */
export function addXp(amount){
  const before = levelProgress();
  if (state.level < 2 || amount <= 0) return { gained: 0, before, after: before, up: null };
  state.xp += Math.round(amount);
  const up = reachLevel(levelForXp(state.xp));
  return { gained: Math.round(amount), before, after: levelProgress(), up };
}

/** Din nuvarande titel. */
export const myTitle = () => titleFor(state.level);
