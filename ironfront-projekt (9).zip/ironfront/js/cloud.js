/* =========================================================
   IRONFRONT — molnsparning
   Är du inloggad (verifierat namn med nyckel) laddas sparfilen
   upp till servern: några sekunder efter varje ändring, och
   direkt när en utryckning är slut. Loggar du in med namn och
   lösenord på en annan dator hämtas den därifrån.
   Går servern inte att nå sparas allt som vanligt lokalt.
   ========================================================= */
import { bus } from './util.js';
import { state } from './state.js';
import { cloudSave } from './net.js';

let timer = null, busy = false, again = false;
export const cloud = { last: 0, ok: null };

const allowed = () => !!(state.profile?.verified && state.profile?.token && state.profile?.name);

async function upload(){
  if (!allowed()) return;
  if (busy){ again = true; return; }
  busy = true;
  const res = await cloudSave(state.profile.name, state.profile.token, JSON.parse(JSON.stringify(state)));
  busy = false;
  cloud.ok = !!res.ok;
  if (res.ok){ cloud.last = Date.now(); bus.emit('cloud:saved', cloud); }
  if (again){ again = false; schedule(2000); }
}

let due = 0;
/** Planerar en uppladdning. En tidigare planerad (snabbare) skjuts aldrig upp. */
function schedule(ms){
  const at = Date.now() + ms;
  if (timer && due <= at) return;
  clearTimeout(timer);
  due = at;
  timer = setTimeout(() => { timer = null; upload(); }, ms);
}

export function initCloud(){
  bus.on('save:written', () => schedule(6000));
  bus.on('battle:finished', () => schedule(800));
}
export const cloudNow = () => schedule(0);
