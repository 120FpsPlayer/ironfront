/* =========================================================
   IRONFRONT — effektlager
   Allt som inte påverkar spelreglerna men bestämmer hur det
   känns: gnistor, rök, ljussken, skakning och siffror.
   ========================================================= */
import { Pool, rand, randi, TAU, clamp, rgba } from './util.js';
import { state } from './state.js';

const partPool = new Pool(
  () => ({}),
  (o, i) => Object.assign(o, {
    x: 0, y: 0, vx: 0, vy: 0, life: 1, max: 1, size: 2,
    color: '#fff', drag: 0.92, grav: 0, kind: 'spark', spin: 0, rot: 0, glow: false
  }, i)
);

export const Fx = {
  parts: partPool,
  lights: [],       // additiva ljuskällor, ritas i ett eget pass
  numbers: [],      // skadesiffror
  scorches: [],     // brännmärken på marken, äldst försvinner först
  shakeAmt: 0,
  shakeX: 0, shakeY: 0,
  hitStopLeft: 0,
  flash: 0,

  reset(){
    partPool.clear();
    this.lights.length = 0;
    this.numbers.length = 0;
    this.scorches.length = 0;
    this.shakeAmt = 0; this.hitStopLeft = 0; this.flash = 0;
  },

  /** Hur många partiklar som faktiskt skapas — inställningen skalar allt. */
  get density(){ return state.settings.particles; },

  spark(x, y, color, n = 6, speed = 4, spread = TAU, dir = 0){
    n = Math.round(n * this.density);
    for (let i = 0; i < n; i++){
      const a = dir + (Math.random() - 0.5) * spread;
      const s = speed * rand(1.3, 0.35);
      partPool.spawn({
        x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s,
        life: rand(420, 160), max: 420, size: rand(2.6, 0.9),
        color, drag: 0.90, grav: 0.012, kind: 'spark', glow: true
      });
    }
  },

  smoke(x, y, n = 4, color = '#2a2a2e', size = 9){
    n = Math.round(n * this.density);
    for (let i = 0; i < n; i++){
      const a = Math.random() * TAU;
      partPool.spawn({
        x: x + Math.cos(a) * 4, y: y + Math.sin(a) * 4,
        vx: Math.cos(a) * rand(.8, .1) , vy: Math.sin(a) * rand(.8, .1) - 0.25,
        life: rand(1500, 700), max: 1500, size: rand(size * 1.6, size * .7),
        color, drag: 0.965, grav: -0.004, kind: 'smoke'
      });
    }
  },

  debris(x, y, color, n = 5){
    n = Math.round(n * this.density);
    for (let i = 0; i < n; i++){
      const a = Math.random() * TAU, s = rand(5, 1.5);
      partPool.spawn({
        x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s,
        life: rand(1100, 500), max: 1100, size: rand(4.5, 1.8),
        color, drag: 0.93, grav: 0.055, kind: 'debris',
        rot: Math.random() * TAU, spin: rand(.3, -.3)
      });
    }
  },

  /** Tomhylsa som studsar ut ur vapnet — liten detalj, stor skillnad. */
  casing(x, y, angle){
    if (this.density < 0.5) return;
    const a = angle + Math.PI / 2 + rand(.5, -.5);
    partPool.spawn({
      x, y, vx: Math.cos(a) * rand(2.4, 1), vy: Math.sin(a) * rand(2.4, 1),
      life: 900, max: 900, size: 2.2, color: '#c9a25e',
      drag: 0.94, grav: 0.07, kind: 'debris', rot: Math.random() * TAU, spin: rand(.5, -.5)
    });
  },

  muzzle(x, y, angle, color, scale = 1){
    this.light(x, y, 90 * scale, color, 90);
    const n = Math.round(4 * this.density);
    for (let i = 0; i < n; i++){
      const a = angle + rand(.34, -.34);
      partPool.spawn({
        x, y, vx: Math.cos(a) * rand(9, 4), vy: Math.sin(a) * rand(9, 4),
        life: rand(120, 50), max: 120, size: rand(4, 1.6),
        color, drag: 0.82, kind: 'spark', glow: true
      });
    }
  },

  explosion(x, y, scale = 1, color = '#ff8a3c'){
    const n = Math.round(14 * scale * this.density);
    this.spark(x, y, color, n, 7 * scale);
    this.smoke(x, y, Math.round(6 * scale), '#1c1a19', 13 * scale);
    this.debris(x, y, '#3a3230', Math.round(5 * scale));
    this.light(x, y, 210 * scale, color, 260);
    this.shake(7 * scale);
    this.scorch(x, y, 26 * scale);
  },

  scorch(x, y, r){
    this.scorches.push({ x, y, r, a: 0.5, rot: Math.random() * TAU });
    if (this.scorches.length > 90) this.scorches.shift();
  },

  light(x, y, r, color, life = 120){
    this.lights.push({ x, y, r, color, life, max: life });
  },

  number(x, y, text, color = '#ffd9a8', big = false){
    if (!state.settings.dmgNumbers) return;
    this.numbers.push({
      x: x + rand(14, -14), y, text, color, big,
      life: big ? 1000 : 720, max: big ? 1000 : 720,
      vy: big ? -0.9 : -0.55, vx: rand(.35, -.35)
    });
    if (this.numbers.length > 70) this.numbers.shift();
  },

  shake(amount){ this.shakeAmt = Math.min(34, this.shakeAmt + amount * state.settings.shake); },

  /** Fryser bilden ett kort ögonblick — används vid tunga träffar. */
  hitStop(ms){ this.hitStopLeft = Math.max(this.hitStopLeft, ms); },

  screenFlash(v = 0.5){ this.flash = Math.max(this.flash, v); },

  update(dt){
    const f = dt / 16.67;

    partPool.sweep(p => {
      p.life -= dt;
      if (p.life <= 0) return false;
      p.x += p.vx * f; p.y += p.vy * f;
      p.vx *= Math.pow(p.drag, f); p.vy *= Math.pow(p.drag, f);
      p.vy += p.grav * f;
      if (p.spin) p.rot += p.spin * f;
      return true;
    });

    for (let i = this.lights.length - 1; i >= 0; i--){
      this.lights[i].life -= dt;
      if (this.lights[i].life <= 0) this.lights.splice(i, 1);
    }
    for (let i = this.numbers.length - 1; i >= 0; i--){
      const n = this.numbers[i];
      n.life -= dt; n.y += n.vy * f; n.x += n.vx * f; n.vy *= Math.pow(0.97, f);
      if (n.life <= 0) this.numbers.splice(i, 1);
    }
    for (let i = this.scorches.length - 1; i >= 0; i--){
      this.scorches[i].a -= dt * 0.00003;
      if (this.scorches[i].a <= 0) this.scorches.splice(i, 1);
    }

    this.shakeAmt *= Math.pow(0.86, f);
    if (this.shakeAmt < 0.05) this.shakeAmt = 0;
    const a = Math.random() * TAU;
    this.shakeX = Math.cos(a) * this.shakeAmt;
    this.shakeY = Math.sin(a) * this.shakeAmt;

    this.flash *= Math.pow(0.86, f);
    if (this.hitStopLeft > 0) this.hitStopLeft -= dt;
  }
};

/** Ritar partiklar. Ljuspasset sköts av render.js. */
export function drawParticles(ctx){
  for (const p of Fx.parts.live){
    const t = clamp(p.life / p.max, 0, 1);
    ctx.globalAlpha = p.kind === 'smoke' ? t * 0.34 : t;
    if (p.kind === 'smoke'){
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size * (1.8 - t), 0, TAU);
      ctx.fill();
    } else if (p.kind === 'debris'){
      ctx.save();
      ctx.translate(p.x, p.y); ctx.rotate(p.rot);
      ctx.fillStyle = p.color;
      ctx.fillRect(-p.size / 2, -p.size / 3, p.size, p.size * 0.66);
      ctx.restore();
    } else {
      ctx.fillStyle = p.color;
      const s = p.size * (0.4 + t * 0.6);
      // Gnistor ritas som korta streck i färdriktningen — mer fart i bilden
      const sp = Math.hypot(p.vx, p.vy);
      if (sp > 1.2){
        ctx.strokeStyle = p.color;
        ctx.lineWidth = s;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(p.x - p.vx * 1.8, p.y - p.vy * 1.8);
        ctx.stroke();
      } else {
        ctx.beginPath(); ctx.arc(p.x, p.y, s, 0, TAU); ctx.fill();
      }
    }
  }
  ctx.globalAlpha = 1;
}

export function drawNumbers(ctx){
  for (const n of Fx.numbers){
    const t = clamp(n.life / n.max, 0, 1);
    ctx.globalAlpha = t > .75 ? (1 - t) * 4 : t / .75;
    ctx.font = `700 ${n.big ? 26 : 17}px Oxanium, sans-serif`;
    ctx.textAlign = 'center';
    ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(0,0,0,.85)';
    ctx.strokeText(n.text, n.x, n.y);
    ctx.fillStyle = n.color;
    ctx.fillText(n.text, n.x, n.y);
  }
  ctx.globalAlpha = 1;
  ctx.textAlign = 'left';
}

export function drawScorches(ctx){
  for (const s of Fx.scorches){
    ctx.save();
    ctx.globalAlpha = clamp(s.a, 0, 1);
    ctx.translate(s.x, s.y); ctx.rotate(s.rot);
    const g = ctx.createRadialGradient(0, 0, 0, 0, 0, s.r);
    g.addColorStop(0, 'rgba(10,8,7,.85)');
    g.addColorStop(.6, 'rgba(18,14,12,.45)');
    g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.ellipse(0, 0, s.r, s.r * .78, 0, 0, TAU); ctx.fill();
    ctx.restore();
  }
  ctx.globalAlpha = 1;
}

/** Additivt ljuspass. Ger scenen dramatik utan riktig ljusberäkning. */
export function drawLights(ctx, projectiles){
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  for (const l of Fx.lights){
    const t = clamp(l.life / l.max, 0, 1);
    const g = ctx.createRadialGradient(l.x, l.y, 0, l.x, l.y, l.r);
    g.addColorStop(0, rgba(l.color, 0.42 * t));
    g.addColorStop(.45, rgba(l.color, 0.12 * t));
    g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(l.x, l.y, l.r, 0, TAU); ctx.fill();
  }
  // Varje projektil bär sitt eget lilla ljus
  if (projectiles) for (const p of projectiles){
    if (!p.light) continue;
    const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.light);
    g.addColorStop(0, rgba(p.color, .30));
    g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(p.x, p.y, p.light, 0, TAU); ctx.fill();
  }
  ctx.restore();
}
