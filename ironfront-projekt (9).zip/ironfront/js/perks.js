/* =========================================================
   IRONFRONT — fältuppgraderingar
   Var tredje våg får du välja en av tre. De gäller bara det
   pågående uppdraget, så varje utryckning bygger sin egen robot.
   ========================================================= */

/** Standardvärden. Allt i combat läser från player.mods. */
export function baseMods(){
  return {
    dmg: 1, rate: 1, reload: 1, mag: 1, speed: 1,
    crit: 0, critMult: 2.2,
    lifesteal: 0, pierce: 0, explode: 0,
    thorns: 0, shieldOnKill: 0, hpPerWave: 0,
    slowOnHit: 0, ricochet: 0, overheal: 0,
    pickupRange: 1, scoreMult: 1, lastStand: false, usedLastStand: false,
    firstShot: 0, closeDmg: 0, farDmg: 0, lowHpDmg: 0
  };
}

export const PERKS = [
  /* ---- Vanliga: små, pålitliga steg ---- */
  { id:'cal',      rank:'common', name:'Kalibrering',        text:'Siktmekaniken justeras om mellan vågorna.',        eff:'+12 % skada',              apply:m => m.dmg *= 1.12 },
  { id:'feed',     rank:'common', name:'Matarverk',          text:'Ammunitionsbandet dras fram snabbare.',            eff:'+10 % eldhastighet',       apply:m => m.rate *= 0.90 },
  { id:'mag',      rank:'common', name:'Utökat magasin',     text:'Fler patroner innan du måste stanna upp.',         eff:'+25 % magasin',            apply:m => m.mag *= 1.25 },
  { id:'hands',    rank:'common', name:'Snabba händer',      text:'Omladdningen går märkbart fortare.',               eff:'−20 % omladdningstid',     apply:m => m.reload *= 0.80 },
  { id:'servo',    rank:'common', name:'Servopaket',         text:'Benens ställdon får mer ström.',                   eff:'+14 % rörelsehastighet',   apply:m => m.speed *= 1.14 },
  { id:'plate',    rank:'common', name:'Pansarplåt',         text:'Extra plåt svetsas på skrovet.',                   eff:'+18 % maxskrov',           apply:(m,p) => { p.maxHp = Math.round(p.maxHp * 1.18); p.hp += Math.round(p.maxHp * 0.18); } },
  { id:'scav',     rank:'common', name:'Fältplundring',      text:'Vrakdelar ger användbar skrot.',                   eff:'+25 % poäng',              apply:m => m.scoreMult *= 1.25 },
  { id:'magnet',   rank:'common', name:'Bärgningsmagnet',    text:'Förråd dras till dig på håll.',                    eff:'+120 % upplockningsradie', apply:m => m.pickupRange *= 2.2 },

  /* ---- Ovanliga: byter beteende ---- */
  { id:'crit',     rank:'rare',   name:'Svagpunktsanalys',   text:'Sensorn hittar fogarna i fiendens pansar.',        eff:'20 % chans till kritisk träff', apply:m => { m.crit += 0.20; } },
  { id:'pierce',   rank:'rare',   name:'Pansarkärna',        text:'Projektilerna går rakt igenom första målet.',      eff:'Genomslag +1 mål',         apply:m => { m.pierce += 1; } },
  { id:'leech',    rank:'rare',   name:'Bärgningsarm',       text:'Skadad fiende ger material tillbaka till skrovet.',eff:'2 % av skadan som reparation', apply:m => { m.lifesteal += 0.02; } },
  { id:'kinetic',  rank:'rare',   name:'Kinetisk laddning',  text:'Första skottet efter omladdning slår hårdast.',    eff:'Första skottet +150 %',    apply:m => { m.firstShot += 1.5; } },
  { id:'cqb',      rank:'rare',   name:'Närstridsprotokoll', text:'Systemet prioriterar mål på nära håll.',           eff:'+35 % skada under 300 m',  apply:m => { m.closeDmg += 0.35; } },
  { id:'marks',    rank:'rare',   name:'Prickskytteläge',    text:'Långa skott får bättre laddning.',                 eff:'+35 % skada över 500 m',   apply:m => { m.farDmg += 0.35; } },
  { id:'cryo',     rank:'rare',   name:'Kylmedelsspets',     text:'Träffade fiender segnar ner i farten.',            eff:'Träffar saktar ner 30 %',  apply:m => { m.slowOnHit = Math.max(m.slowOnHit, 0.30); } },
  { id:'thorn',    rank:'rare',   name:'Reaktivt pansar',    text:'Pansaret slår tillbaka mot den som träffar det.',  eff:'Returnerar 25 % av skadan', apply:m => { m.thorns += 0.25; } },
  { id:'cells',    rank:'rare',   name:'Nödceller',          text:'Varje avklarad våg lagar en del av skrovet.',      eff:'+12 % skrov per våg',      apply:m => { m.hpPerWave += 0.12; } },
  { id:'ric',      rank:'rare',   name:'Studsammunition',    text:'Skott som träffar hoppar vidare till nästa mål.',  eff:'1 studs',                  apply:m => { m.ricochet += 1; } },

  /* ---- Sällsynta: förändrar hur du spelar ---- */
  { id:'he',       rank:'epic',   name:'Sprängverkan',       text:'Varje träff detonerar i en liten radie.',          eff:'Splitterskada i 70 m',     apply:m => { m.explode += 1; } },
  { id:'overdr',   rank:'epic',   name:'Tvångsmatning',      text:'Hela vapensystemet körs över rekommenderad nivå.', eff:'+25 % skada, +20 % eldhastighet', apply:m => { m.dmg *= 1.25; m.rate *= 0.80; } },
  { id:'last',     rank:'epic',   name:'Sista linjen',       text:'Ett dödligt slag lämnar dig med skrovet intakt.',  eff:'Överlever ett dödsslag',   apply:m => { m.lastStand = true; } },
  { id:'berserk',  rank:'epic',   name:'Bärsärk',            text:'Skadade system dras hårdare.',                     eff:'Upp till +60 % skada vid lågt skrov', apply:m => { m.lowHpDmg += 0.6; } },
  { id:'barrier',  rank:'epic',   name:'Fältbarriär',        text:'Varje nedskjuten fiende ger dig sköld.',           eff:'+180 sköld per kill',      apply:(m,p) => { m.shieldOnKill += 180; if (!p.shield) p.shield = { type:'blue', capacity:900, current:0, regenDelay:6000, regenRate:0, sinceHit:0 }; } },
  { id:'exec',     rank:'epic',   name:'Avrättningsorder',   text:'Kritiska träffar blir betydligt farligare.',       eff:'Kritisk skada ×3,4',       apply:m => { m.critMult = 3.4; m.crit += 0.08; } }
];

const WEIGHT = { common: 62, rare: 30, epic: 8 };

/**
 * Drar tre förslag. Redan tagna uppgraderingar kan komma igen
 * (staplingsbara) men vi undviker dubbletter i samma dragning.
 */
export function rollPerks(taken = [], count = 3, luck = 0){
  const w = { common: WEIGHT.common - luck * 10, rare: WEIGHT.rare + luck * 6, epic: WEIGHT.epic + luck * 4 };
  const out = [];
  const seen = new Set();
  let guard = 0;
  while (out.length < count && guard++ < 200){
    const total = w.common + w.rare + w.epic;
    let r = Math.random() * total;
    const rank = r < w.common ? 'common' : r < w.common + w.rare ? 'rare' : 'epic';
    const pool = PERKS.filter(p => p.rank === rank && !seen.has(p.id) && !isMaxed(p, taken));
    if (!pool.length) continue;
    const p = pool[(Math.random() * pool.length) | 0];
    seen.add(p.id);
    out.push(p);
  }
  return out;
}

/** Vissa uppgraderingar ska inte staplas i oändlighet. */
function isMaxed(perk, taken){
  const n = taken.filter(t => t === perk.id).length;
  const caps = { last: 1, pierce: 3, ric: 2, he: 2, exec: 1, barrier: 2, crit: 4 };
  return n >= (caps[perk.id] ?? 6);
}

export const perkById = id => PERKS.find(p => p.id === id);
export const RANK_LABEL = { common: 'STANDARD', rare: 'FÄLTMODIFIERING', epic: 'PROTOTYP' };
