/* =========================================================
   IRONFRONT — stridsgränssnittet
   Läser spelets tillstånd och skriver till DOM. Ändrar aldrig
   något i spelet — HUD:en är en mätare, inte en spak.
   ========================================================= */
import { abilityInfo } from './entities.js';
import { sectorName, fmtRace } from './data.js';
import { state } from './state.js';
import { WORLD } from './arena.js';
import { $, el, bus, clamp, fmt, TAU, rgba, esc } from './util.js';

let node = {}, radarCtx = null, lastWeaponSig = '';

export function initHud(){
  node = {
    name: $('#hudName'), tpl: $('#hudTpl'),
    hpFill: $('#hpFill'), hpTxt: $('#hpTxt'),
    shLine: $('#shieldLine'), shFill: $('#shFill'), shTxt: $('#shTxt'),
    sector: $('#hudSector'), wave: $('#hudWave'), pips: $('#hudPips'),
    score: $('#hudScore'), combo: $('#hudCombo'), comboBar: $('#comboBar'),
    bossBar: $('#bossBar'), bossName: $('#bossName'), bossType: $('#bossType'),
    bossHp: $('#bossHp'), bossShieldWrap: $('#bossShieldWrap'), bossShield: $('#bossShield'),
    event: $('#eventPanel'), evName: $('#evName'), evTime: $('#evTime'), evText: $('#evText'),
    story: $('#storyBanner'), storyTtl: $('#storyTtl'), storyTxt: $('#storyTxt'),
    killfeed: $('#killfeed'), ability: $('#abilityWrap'), weapons: $('#weaponList'),
    radar: $('#radar'), crosshair: $('#crosshair'), hurt: $('#hurtFlash'),
    toasts: $('#toasts'),
    coach: $('#coach'), coachTtl: $('#coachTtl'), coachTxt: $('#coachTxt'),
    coachKeys: $('#coachKeys'), coachStep: $('#coachStep'), keys: $('#hudKeys')
  };
  radarCtx = node.radar.getContext('2d');

  bus.on('battle:started', onStart);
  bus.on('battle:tick', onTick);
  bus.on('wave:start', onWave);
  bus.on('boss:start', onBossStart);
  bus.on('boss:end', () => node.bossBar.classList.remove('on'));
  bus.on('boss:phase', ({ phase }) => {
    node.bossBar.classList.remove('p2', 'p3');
    node.bossBar.classList.add('p' + phase);
    node.bossType.textContent = phase === 3 ? 'BÄRSÄRK' : 'FAS ' + phase;
  });
  bus.on('event:start', onEventStart);
  bus.on('event:tick', ev => { node.evTime.textContent = Math.ceil(ev.left / 1000) + 's'; });
  bus.on('event:end', () => node.event.classList.remove('on'));
  bus.on('story:show', onStory);
  bus.on('story:hide', () => node.story.classList.remove('on'));
  bus.on('killfeed', onKill);
  bus.on('toast', toast);
  bus.on('player:hurt', hurtFlash);
  bus.on('coach:show', onCoach);
  bus.on('coach:hide', () => { node.coach.classList.remove('on'); node.keys.classList.remove('gone'); });
  bus.on('coach:check', () => {
    node.coach.classList.remove('check');
    void node.coach.offsetWidth;
    node.coach.classList.add('check');
  });

  addEventListener('mousemove', e => {
    node.crosshair.style.transform = `translate(${e.clientX}px, ${e.clientY}px)`;
  });
}

function onStart(g){
  node.name.textContent = g.player.name;
  node.tpl.textContent = 'MK ' + ['I','II','III','IV','V'][Math.min(4, Math.floor(g.perksTaken.length / 2))];
  node.killfeed.innerHTML = '';
  node.bossBar.classList.remove('on');
  node.event.classList.remove('on');
  buildAbility(g.player);
  lastWeaponSig = '';
  node.crosshair.style.display = '';
  node.coach.classList.remove('on');
  node.bossBar.classList.remove('on', 'p2', 'p3');   // ingen kvarglömd bossmätare från förra striden
  // Tangentraden längst ned försvinner efter en stund så den inte skräpar
  node.keys.classList.remove('gone');
  clearTimeout(keysTimer);
  keysTimer = setTimeout(() => node.keys.classList.add('gone'), 14000);
  onWave(g);
}

let keysTimer = null;
function onCoach({ title, text, keys = [], step, total, tip }){
  node.coachTtl.textContent = title;
  node.coachTxt.textContent = text;
  node.coachKeys.innerHTML = keys.map(k => `<kbd>${esc(k)}</kbd>`).join('');
  node.coachKeys.hidden = !keys.length;
  node.coachStep.textContent = tip ? 'TIPS' : `TRÄNING ${step} / ${total}`;
  node.coach.classList.toggle('tip', !!tip);
  node.coach.classList.add('on');
  node.keys.classList.add('gone');
}

function onWave(g){
  node.sector.textContent = g.trial ? `ARENA · ${g.trial.name.toUpperCase()}`
    : g.mode === 'survival' ? `ÖVERLEVNAD · REKORD VÅG ${state.records?.survival?.wave || 0}`
    : g.coop
    ? `CO-OP · ${g.coop.players.length} SPELARE · SEKTOR ${g.sector}`
    : g.weekly
    ? `VECKANS UTMANING · VECKA ${g.weekly.week}`
    : g.chapter
    ? `STORY · KAPITEL ${g.chapter.id} · ${g.chapter.title.toUpperCase()}`
    : g.tut || g.sector === 1 ? 'TRÄNING · SEKTOR 1'
    : `SEKTOR ${g.sector} · ${sectorName(g.sector).toUpperCase()}`;
  node.wave.textContent = Number.isFinite(g.waveTotal) ? `${g.waveInSector} / ${g.waveTotal}` : `${g.waveInSector}`;
  // Pips visar hela sektorn i ett ögonkast: klara vågor, bossvågor, nuvarande
  node.pips.innerHTML = '';
  const show = Math.min(g.waveTotal, 20);
  for (let i = 1; i <= show; i++){
    const p = el('i');
    if (i % (g.mods?.bossEvery || 5) === 0 || i === g.waveTotal) p.className = 'boss';
    if (i < g.waveInSector) p.classList.add('done');
    if (i === g.waveInSector) p.classList.add('live');
    node.pips.appendChild(p);
  }
}

function onBossStart(boss){
  node.bossBar.classList.add('on');
  node.bossName.textContent = boss.name;
  node.bossType.textContent = boss.isFinale ? 'SEKTORSVAKT' : boss.typeLabel;
  node.bossShieldWrap.hidden = !boss.shield || boss.shield.type === 'purple';
  node.bossBar.classList.remove('p2', 'p3');
}

function onEventStart(ev){
  node.event.classList.add('on');
  node.evName.textContent = ev.def.name;
  node.evText.textContent = ev.def.text;
  node.evTime.textContent = Math.ceil(ev.left / 1000) + 's';
}

function onStory({ title, text }){
  node.storyTtl.textContent = title;
  node.storyTxt.textContent = text;
  node.story.classList.add('on');
}

function onKill({ name, boss }){
  const d = el('div', boss ? 'boss' : '', esc(boss ? `◆ ${name} NEDKÄMPAD` : `${name} nedkämpad`));
  node.killfeed.appendChild(d);
  while (node.killfeed.children.length > 5) node.killfeed.firstChild.remove();
  setTimeout(() => d.remove(), 4200);
}

let hurtTimer = null;
function hurtFlash(intensity){
  node.hurt.style.opacity = clamp(intensity, 0, 1) * 0.9;
  clearTimeout(hurtTimer);
  hurtTimer = setTimeout(() => { node.hurt.style.opacity = 0; }, 130);
}

export function toast({ text, kind = '', ms }){
  const t = el('div', 'toast ' + kind, esc(text));
  node.toasts.appendChild(t);
  // Längre text syns längre — ingen ska behöva hinna läsa på två sekunder
  const life = ms || clamp(1800 + String(text).length * 45, 2200, 7000);
  setTimeout(() => {
    t.style.transition = 'opacity 300ms';
    t.style.opacity = '0';
    setTimeout(() => t.remove(), 320);
  }, life);
}

/* ---------- Per bildruta ---------- */
function onTick(g){
  const p = g.player;
  // Arena: klockan tickar i vågrutan
  if (g.trial && g.trial.rank === 'time') node.sector.textContent = `ARENA · ${g.trial.name.toUpperCase()} · ${fmtRace(g.elapsed)}`;

  const hpPct = clamp(p.hp / p.maxHp, 0, 1);
  node.hpFill.style.width = hpPct * 100 + '%';
  node.hpTxt.textContent = `${fmt(Math.max(0, p.hp))}/${fmt(p.maxHp)}`;

  if (p.shield && p.shield.type !== 'purple'){
    node.shLine.hidden = false;
    node.shFill.className = 'fill ' + (p.shield.type === 'gold' ? 'gold' : 'shield');
    node.shFill.style.width = clamp(p.shield.current / p.shield.capacity, 0, 1) * 100 + '%';
    node.shTxt.textContent = fmt(Math.max(0, p.shield.current));
  } else node.shLine.hidden = true;

  node.score.textContent = fmt(g.score);
  if (g.combo > 1){
    node.combo.classList.add('on');
    node.combo.firstChild.textContent = '×' + g.combo;
    node.comboBar.style.width = clamp(g.comboTimer / 3200, 0, 1) * 100 + '%';
  } else node.combo.classList.remove('on');

  const boss = g.enemies.find(e => e.isBoss);
  if (boss){
    node.bossHp.style.width = clamp(boss.hp / boss.maxHp, 0, 1) * 100 + '%';
    if (boss.shield && boss.shield.type !== 'purple')
      node.bossShield.style.width = clamp(boss.shield.current / boss.shield.capacity, 0, 1) * 100 + '%';
  }

  updateAbility(p);
  updateWeapons(p);
  if (state.settings.minimap) drawRadar(g); else clearRadar();
}

/* ---------- Förmåga ---------- */
function buildAbility(p){
  node.ability.innerHTML = '';
  const info = abilityInfo(p);
  if (!info){
    node.ability.appendChild(el('div', 'ability-cell',
      `<div class="key">R</div><div class="nm">LADDA OM</div><div class="meter"><div class="fill hull" style="width:100%"></div></div>`));
    return;
  }
  node.ability.appendChild(el('div', 'ability-cell',
    `<div class="key">SHIFT / Q</div><div class="nm">${esc(info.name)}</div><div class="meter"><div class="fill hull"></div></div>`));
  node._abCell = node.ability.firstChild;
  node._abFill = node._abCell.querySelector('.fill');
  node._abInfo = info;
}

function updateAbility(p){
  if (!node._abInfo) return;
  const info = node._abInfo, cell = node._abCell, fill = node._abFill;
  let pct = 1, active = false;

  if (info.key === 'prism' && p.shield){
    active = p.shield.active;
    pct = active ? p.shield.activeLeft / p.shield.duration : 1 - p.shield.cdLeft / p.shield.cooldown;
  } else if (info.key === 'dash' && p.dash){
    active = p.dash.active;
    pct = 1 - p.dash.cdLeft / p.dash.cooldown;
  } else if (info.key === 'special' && p.special){
    active = p.special.active;
    pct = active ? p.special.activeLeft / Math.max(1, p.special.duration) : 1 - p.special.cdLeft / p.special.cooldown;
  } else if (info.key === 'scan' && p.scan){
    active = p.scan.active;
    pct = active ? p.scan.activeLeft / p.scan.duration : 1 - p.scan.cdLeft / p.scan.cooldown;
  } else if (info.key === 'over' && p.overdrive){
    active = p.overdrive.active;
    pct = active ? p.overdrive.activeLeft / p.overdrive.duration : 1 - p.overdrive.cdLeft / p.overdrive.cooldown;
  }
  pct = clamp(pct, 0, 1);
  fill.style.width = pct * 100 + '%';
  cell.classList.toggle('ready', pct >= 1 && !active);
  cell.classList.toggle('active', active);
}

/* ---------- Vapen ---------- */
function updateWeapons(p){
  const sig = p.weaponGroups.map(g => g.id + g.magSize).join('|');
  if (sig !== lastWeaponSig){
    lastWeaponSig = sig;
    node.weapons.innerHTML = '';
    p.weaponGroups.forEach((grp, i) => {
      const w = el('div', 'wpn',
        `<span class="nm">${esc(grp.name)}${grp.mounts.length > 1 ? ` ×${grp.mounts.length}` : ''}</span>
         <span class="ammo"><b>0</b>/${grp.magSize}</span>`);
      node.weapons.appendChild(w);
      grp._node = w;
      grp._ammo = w.querySelector('.ammo');
    });
  }
  for (const grp of p.weaponGroups){
    if (!grp._node) continue;
    if (grp.reloading){
      grp._node.classList.add('reloading');
      grp._ammo.textContent = `LADDAR ${(grp.reloadTimer / 1000).toFixed(1)}s`;
    } else {
      grp._node.classList.remove('reloading');
      grp._node.classList.toggle('dry', grp.ammoLeft <= grp.magSize * 0.25);
      grp._ammo.innerHTML = `<b>${grp.ammoLeft}</b>/${grp.magSize}`;
    }
  }
}

/* ---------- Radar ---------- */
function clearRadar(){
  radarCtx.clearRect(0, 0, node.radar.width, node.radar.height);
}

function drawRadar(g){
  const c = radarCtx, W = node.radar.width, H = node.radar.height;
  const cx = W / 2, cy = H / 2, R = W / 2 - 6;
  const scan = !!g.player.scan?.active;
  const jam = g.event?.type === 'jammer' && !scan;   // sensorpulsen skär igenom störningen

  c.clearRect(0, 0, W, H);
  c.fillStyle = 'rgba(6,10,14,.92)';
  c.fillRect(0, 0, W, H);

  // Rutnät
  c.strokeStyle = 'rgba(70,100,125,.28)'; c.lineWidth = 1;
  c.beginPath(); c.arc(cx, cy, R, 0, TAU); c.stroke();
  c.beginPath(); c.arc(cx, cy, R * 0.6, 0, TAU); c.stroke();
  c.beginPath(); c.arc(cx, cy, R * 0.3, 0, TAU); c.stroke();
  c.beginPath();
  c.moveTo(cx - R, cy); c.lineTo(cx + R, cy);
  c.moveTo(cx, cy - R); c.lineTo(cx, cy + R);
  c.stroke();

  if (g.mods?.noRadar && !scan){
    c.fillStyle = '#8093a5';
    c.font = '700 11px Oxanium, sans-serif';
    c.textAlign = 'center';
    c.fillText('RADAR AVSLAGEN', cx, cy + 4);
    c.textAlign = 'left';
    return;
  }
  if (jam){
    // Störd radar: brus istället för fiender
    c.fillStyle = 'rgba(201,106,245,.20)';
    for (let i = 0; i < 90; i++)
      c.fillRect(Math.random() * W, Math.random() * H, 2, 2);
    c.fillStyle = '#c96af5';
    c.font = '700 11px Oxanium, sans-serif';
    c.textAlign = 'center';
    c.fillText('SIGNAL STÖRD', cx, cy + 4);
    c.textAlign = 'left';
    return;
  }

  // Svepande stråle
  const sweep = (performance.now() / 2600) % 1 * TAU;
  const grd = c.createRadialGradient(cx, cy, 0, cx, cy, R);
  grd.addColorStop(0, 'rgba(255,90,30,.20)');
  grd.addColorStop(1, 'rgba(255,90,30,0)');
  c.fillStyle = grd;
  c.beginPath();
  c.moveTo(cx, cy);
  c.arc(cx, cy, R, sweep - 0.5, sweep);
  c.closePath(); c.fill();

  // Under sensorpulsen zoomar radarn ut och visar hela kartan
  const scale = R / (scan ? 3200 : 1500);
  const p = g.player;

  // Hinder som svaga konturer
  c.fillStyle = 'rgba(90,120,145,.18)';
  for (const o of g.arena.obstacles){
    if (o.hp <= 0 || o.type === 'wall') continue;
    const dx = (o.x + o.w / 2 - p.x) * scale, dy = (o.y + o.h / 2 - p.y) * scale;
    if (Math.hypot(dx, dy) > R) continue;
    c.fillRect(cx + dx - o.w * scale / 2, cy + dy - o.h * scale / 2, Math.max(2, o.w * scale), Math.max(2, o.h * scale));
  }

  // Fiender
  for (const en of g.enemies){
    if (en.cloak) continue;                     // smygare syns inte på radarn heller
    const dx = (en.x - p.x) * scale, dy = (en.y - p.y) * scale;
    const d = Math.hypot(dx, dy);
    if (d > R){
      // Utanför räckhåll: markera riktningen på kanten
      const a = Math.atan2(dy, dx);
      c.fillStyle = 'rgba(226,74,68,.5)';
      c.fillRect(cx + Math.cos(a) * R - 1.5, cy + Math.sin(a) * R - 1.5, 3, 3);
      continue;
    }
    if (scan && !en.isBoss){
      c.strokeStyle = 'rgba(143,211,230,.8)';
      c.strokeRect(cx + dx - 3.5, cy + dy - 3.5, 7, 7);
    }
    if (en.isBoss){
      c.fillStyle = '#ff5a1e';
      c.beginPath(); c.arc(cx + dx, cy + dy, 5, 0, TAU); c.fill();
      c.strokeStyle = 'rgba(255,90,30,.5)';
      c.beginPath(); c.arc(cx + dx, cy + dy, 8 + Math.sin(performance.now() / 200) * 2, 0, TAU); c.stroke();
    } else {
      c.fillStyle = '#e24a44';
      c.fillRect(cx + dx - 2, cy + dy - 2, 4, 4);
    }
  }

  // Lagkamrater i co-op: gröna trianglar
  if (g.allies) for (const al of g.allies){
    if (al.hp <= 0) continue;
    const dx = (al.x - p.x) * scale, dy = (al.y - p.y) * scale;
    const d = Math.hypot(dx, dy);
    const k = d > R ? R / d : 1;
    c.save();
    c.translate(cx + dx * k, cy + dy * k); c.rotate(al.angle);
    c.fillStyle = '#9fe0b8';
    c.beginPath(); c.moveTo(5, 0); c.lineTo(-3, 3.5); c.lineTo(-3, -3.5); c.closePath(); c.fill();
    c.restore();
  }

  // Upplockbart
  c.fillStyle = '#58c98a';
  for (const pu of g.pickups){
    const dx = (pu.x - p.x) * scale, dy = (pu.y - p.y) * scale;
    if (Math.hypot(dx, dy) > R) continue;
    c.fillRect(cx + dx - 1.5, cy + dy - 1.5, 3, 3);
  }

  // Händelsemål
  if (g.event?.objects){
    c.fillStyle = g.event.def.color;
    for (const o of g.event.objects){
      if (o.hp <= 0) continue;
      const dx = (o.x - p.x) * scale, dy = (o.y - p.y) * scale;
      if (Math.hypot(dx, dy) > R) continue;
      c.beginPath(); c.arc(cx + dx, cy + dy, 3.5, 0, TAU); c.fill();
    }
  }

  // Spelaren i mitten, med blickriktning
  c.save();
  c.translate(cx, cy); c.rotate(p.angle);
  c.fillStyle = '#d3dfe9';
  c.beginPath();
  c.moveTo(6, 0); c.lineTo(-4, 4); c.lineTo(-4, -4);
  c.closePath(); c.fill();
  c.restore();
}

/** Döljer siktet när striden inte pågår. */
export function showCrosshair(on){
  if (node.crosshair) node.crosshair.style.display = on ? '' : 'none';
}
