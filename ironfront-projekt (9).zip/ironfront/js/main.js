/* =========================================================
   IRONFRONT — start
   Enda filen som index.html laddar. Kopplar ihop delarna i
   rätt ordning och lämnar sedan över till gränssnittet.
   ========================================================= */
import { load, state, makeSlot } from './state.js';
import { initHud } from './hud.js';
import { bindBattleCanvas } from './battle.js';
import { bootUI } from './ui.js';
import * as Audio from './audio.js';
import { $, log } from './util.js';

function boot(){
  // 1. Tillstånd först — allt annat läser från det.
  load();

  // 2. Stridsytan: rendering och indata pekas mot samma canvas.
  bindBattleCanvas($('#stage'));

  // 3. HUD:en prenumererar på bussen innan första striden startar.
  initHud();

  // 4. Ljudvolymerna speglar sparade inställningar direkt.
  Audio.applyVolumes();

  // 5. Gränssnittet tar över och visar titelskärmen.
  bootUI();
  initCloud();
  initProgress();

  // Ett halvt varv extra: om fönstret redan är litet får hangaren
  // sidopanelen utfälld så att inget viktigt hamnar utanför.
  if (innerWidth <= 1040) $('#spec').classList.remove('open');

  document.documentElement.dataset.ready = '1';
  // Ren text, ingen %c-formatering: alla konsoler kan inte färglägga,
  // och de som inte kan skriver ut formatsträngen rakt av istället.
  log.info('IRONFRONT build 2.0 — redo');
}

if (document.readyState === 'loading') addEventListener('DOMContentLoaded', boot);
else boot();

// Praktiskt vid felsökning i VS Code: state, Battle och Guide nås från konsolen.
import { Battle } from './battle.js';
import { Guide } from './guide.js';
import { initCloud } from './cloud.js';
import { initProgress } from './progress.js';
window.IRONFRONT = { state, Battle, Guide, makeSlot };
