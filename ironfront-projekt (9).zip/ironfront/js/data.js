/* =========================================================
   IRONFRONT — speldata
   Allt innehåll bor här: robotar, vapen, fiender, kartor,
   bossar och kampanjtext. Systemen läser, men skriver aldrig.
   ========================================================= */

/* ---------------------------------------------------------
   SVÅRIGHET
   --------------------------------------------------------- */
export const DIFFICULTIES = {
  rekryt:  { id:'rekryt',  name:'Rekryt',  enemyDmg:0.65, enemyHp:0.80, reward:0.85, desc:'För att lära sig kartan.' },
  soldat:  { id:'soldat',  name:'Soldat',  enemyDmg:1.00, enemyHp:1.00, reward:1.00, desc:'Så spelet är balanserat.' },
  veteran: { id:'veteran', name:'Veteran', enemyDmg:1.35, enemyHp:1.25, reward:1.30, desc:'Fienden skjuter tidigare och hårdare.' },
  jarnvarg:{ id:'jarnvarg',name:'Järnvarg',enemyDmg:1.75, enemyHp:1.55, reward:1.70, desc:'Ett misstag räcker.' }
};

/* ---------------------------------------------------------
   ROBOTAR
   HP och skada ligger i tusental, som i de stora mech-spelen,
   så att varje träff känns som metall mot metall.
   --------------------------------------------------------- */
export const ROBOTS = {
  recon: {
    id:'recon', name:'RECON', role:'Spanare', color:'#8fd3e6', free:true,
    baseHp:2500, speed:1.0, mounts:[{spread:8}], defaultWeapon:'slug_std',
    frame:'light', shield:null, price:{ag:0,au:0,pl:0},
    // Sensorpuls: märker alla fiender — syns på radarn oavsett avstånd
    // (även genom störsändare) och tar extra skada så länge märkningen sitter.
    scan:{ cooldown:14000, duration:6000, dmgBonus:0.2 },
    desc:'Spanare med sensorpuls: märker alla fiender så de syns på radarn och tar mer skada.'
  },
  vulcan: {
    id:'vulcan', name:'VULCAN', role:'Tvillingkanon', color:'#efd06a',
    baseHp:2750, speed:0.95, mounts:[{offset:-14},{offset:14}], defaultWeapon:'slug_light',
    frame:'medium', shield:null, price:{ag:4200,au:0,pl:0},
    desc:'Två montage som delar ammo — dubbel eldhastighet så länge magasinet räcker.'
  },
  raptor: {
    id:'raptor', name:'RAPTOR', role:'Jägare', color:'#84e096',
    baseHp:1900, speed:1.55, mounts:[{spread:6}], defaultWeapon:'rapid_std',
    frame:'light', shield:null, price:{ag:6800,au:0,pl:0},
    desc:'Tunn pansar, men rör sig snabbare än fiendens siktberäkning.'
  },
  aegis: {
    id:'aegis', name:'AEGIS', role:'Skyddsvakt', color:'#5fb3d4',
    baseHp:3000, speed:0.9, mounts:[{spread:4}], defaultWeapon:'slug_std',
    frame:'medium', shield:{type:'blue', capacity:1750, regenDelay:5000, regenRate:350},
    price:{ag:9500,au:0,pl:0},
    desc:'Blå barriär som laddar om av sig själv när du bryter kontakt.'
  },
  titan: {
    id:'titan', name:'TITAN', role:'Stormtank', color:'#c8683e',
    baseHp:5200, speed:0.72, mounts:[{spread:2}], defaultWeapon:'shell_super',
    frame:'heavy', shield:null, price:{ag:14000,au:25,pl:0},
    desc:'Långsam som en byggnad och ungefär lika lätt att förstöra.'
  },
  hydra: {
    id:'hydra', name:'HYDRA', role:'Trippelkanon', color:'#e277b6',
    baseHp:2900, speed:0.9, mounts:[{offset:-16},{offset:0},{offset:16}], defaultWeapon:'slug_light',
    frame:'medium', shield:null, price:{ag:19000,au:45,pl:0},
    desc:'Tre montage. Eldkraften är enorm, omladdningen brutal.'
  },
  warden: {
    id:'warden', name:'WARDEN', role:'Sköldvakt', color:'#6ec6f2',
    baseHp:3100, speed:0.88, mounts:[{offset:-13},{offset:13}], defaultWeapon:'slug_light',
    frame:'medium', shield:{type:'blue', capacity:1400, regenDelay:4200, regenRate:380},
    price:{ag:0,au:70,pl:0},
    desc:'Sköld och dubbla montage — den mest förlåtande roboten i flottan.'
  },
  paladin: {
    id:'paladin', name:'PALADIN', role:'Sköldbärare', color:'#e8a53e',
    baseHp:3500, speed:0.82, mounts:[{spread:5}], defaultWeapon:'shell_heavy',
    frame:'heavy', shield:{type:'gold', capacity:2250, regenDelay:5000, regenRate:300},
    price:{ag:0,au:110,pl:0},
    desc:'Guldsköld som tål betydligt mer än den blå, men laddar långsammare.'
  },
  nova: {
    id:'nova', name:'NOVA', role:'Dash-anfallare', color:'#ff93d2',
    baseHp:2200, speed:1.1, mounts:[{spread:6}], defaultWeapon:'rapid_std',
    frame:'light', shield:null,
    dash:{cooldown:6000, dashSpeed:3.4, duration:220, vulnDuration:2000},
    price:{ag:0,au:150,pl:0},
    desc:'Kastar sig framåt på en knapptryckning — men står oskyddad efteråt.'
  },
  surge: {
    id:'surge', name:'SURGE', role:'Överladdare', color:'#ffd964',
    baseHp:2600, speed:0.95, mounts:[{spread:5}], defaultWeapon:'slug_std',
    frame:'medium', shield:null,
    overdrive:{cooldown:16000, duration:4000, fireRateMult:0.5, dmgMult:1.25},
    price:{ag:0,au:190,pl:0},
    desc:'Fyra sekunder dubbel eldhastighet. Använd dem när bossen står stilla.'
  },
  phantom: {
    id:'phantom', name:'PHANTOM', role:'Prisma-anfallare', color:'#b88df2',
    baseHp:2500, speed:1.05, mounts:[{spread:3}], defaultWeapon:'plasma_std',
    frame:'light', shield:{type:'purple', duration:3000, cooldown:20000},
    price:{ag:0,au:0,pl:30},
    desc:'Prismaskölden stoppar allt i tre sekunder. Timingen är hela roboten.'
  }
};
export const ROBOT_ORDER = ['recon','vulcan','raptor','aegis','titan','hydra','warden','paladin','nova','surge','phantom'];

/* ---------------------------------------------------------
   VAPEN
   Fristående från robotarna: lås upp en gång, montera fritt.
   rangeProfile avgör hur skadan förändras med avstånd.
   --------------------------------------------------------- */
export const WEAPONS = {
  slug_light:  {id:'slug_light',  name:'Lätt kanon',      kind:'slug',    ammo:'normal',  dmg:150, fireRate:230, mag:24, reload:1800, range:'balanced', price:{ag:0,au:0,pl:0},      desc:'Pålitlig. Gör sitt jobb på alla avstånd utan att briljera någonstans.'},
  slug_std:    {id:'slug_std',    name:'Standardkanon',   kind:'slug',    ammo:'normal',  dmg:225, fireRate:280, mag:26, reload:1700, range:'balanced', price:{ag:2600,au:0,pl:0},   desc:'Tyngre slugs, samma jämna skada oavsett håll.'},
  rapid_std:   {id:'rapid_std',   name:'Snabbeldskanon',  kind:'rapid',   ammo:'normal',  dmg:110, fireRate:150, mag:32, reload:1500, range:'close',    price:{ag:3400,au:0,pl:0},   desc:'Spyr bly. Tappar träffsäkerhet så fort målet drar sig undan.'},
  burst_std:   {id:'burst_std',   name:'Spridningskanon', kind:'burst',   ammo:'normal',  dmg:95,  fireRate:380, mag:18, reload:2000, range:'close',    price:{ag:5200,au:0,pl:0},   desc:'Tre projektiler i solfjäder. Dödlig i ansiktet, oanvändbar på håll.'},
  laser_std:   {id:'laser_std',   name:'Laserkanon',      kind:'laser',   ammo:'normal',  dmg:130, fireRate:170, mag:30, reload:1600, range:'long',     price:{ag:7800,au:12,pl:0},  desc:'Strålen blir farligare ju längre den hinner färdas.'},
  shell_heavy: {id:'shell_heavy', name:'Tungkanon',       kind:'shell',   ammo:'normal',  dmg:300, fireRate:400, mag:16, reload:2300, range:'close',    price:{ag:9000,au:18,pl:0},  desc:'Granater. Tunga att bära, förödande när de träffar.'},
  shell_super: {id:'shell_super', name:'Stormkanon',      kind:'shell',   ammo:'normal',  dmg:520, fireRate:620, mag:8,  reload:2800, range:'close',    price:{ag:0,au:60,pl:0},     desc:'Ett skott, ett hål. Missar du hinner fienden göra mycket.'},
  plasma_std:  {id:'plasma_std',  name:'Plasmakanon',     kind:'plasma',  ammo:'special', dmg:325, fireRate:300, mag:14, reload:2200, range:'long',     price:{ag:0,au:85,pl:0},     desc:'Går rakt igenom blå sköldar. Starkare ju längre skottet flyger.'},
  missile_std: {id:'missile_std', name:'Robotkastare',    kind:'missile', ammo:'special', dmg:420, fireRate:900, mag:8,  reload:2600, range:'balanced', price:{ag:0,au:120,pl:0},    desc:'Självsökande. Låt den kröka sig runt hörnet åt dig.'},
  sniper_rail: {id:'sniper_rail', name:'Railgun',         kind:'plasma',  ammo:'special', dmg:650, fireRate:850, mag:5,  reload:3000, range:'long',     price:{ag:0,au:0,pl:22},     desc:'Byggd för ett enda avstånd: långt. På nära håll är den nästan ofarlig.'}
};
export const WEAPON_ORDER = ['slug_light','slug_std','rapid_std','burst_std','laser_std','shell_heavy','shell_super','plasma_std','missile_std','sniper_rail'];

/** Hur mycket skada som når fram beroende på hur långt skottet färdats. */
export function rangeMult(profile, traveled){
  const t = traveled / 520;                       // 1.0 ≈ halva skärmen
  if (profile === 'close')  return Math.max(0.28, 1.35 - t * 0.62);
  if (profile === 'long')   return Math.min(1.70, 0.55 + t * 0.55);
  return 1;
}

/** Visuell profil per ammunitionstyp — färg, storlek, svans, ljud. */
export const AMMO_FX = {
  slug:    { color:'#ffd9a8', hostile:'#ff9b6b', size:3.4, trail:16, speed:15.0, light:24, sfx:'slug'   },
  rapid:   { color:'#ffe9c0', hostile:'#ffae7a', size:2.6, trail:12, speed:16.5, light:16, sfx:'rapid'  },
  shell:   { color:'#ffb35c', hostile:'#ff8a4c', size:5.2, trail:10, speed:11.0, light:40, sfx:'shell'  },
  laser:   { color:'#9fe8ff', hostile:'#ff7070', size:2.4, trail:34, speed:20.0, light:22, sfx:'laser'  },
  plasma:  { color:'#d0a4ff', hostile:'#c78bff', size:4.6, trail:20, speed:13.0, light:34, sfx:'plasma' },
  missile: { color:'#ffcf8a', hostile:'#ff9a5c', size:4.0, trail:8,  speed:6.4,  light:28, sfx:'missile'},
  burst:   { color:'#ffe0b0', hostile:'#ffa070', size:3.0, trail:9,  speed:13.5, light:18, sfx:'burst'  }
};

/* ---------------------------------------------------------
   FIENDER
   --------------------------------------------------------- */
export const ENEMIES = {
  drone:    { key:'drone',    name:'Drönare',   hp:650,  dmg:150, speed:1.6, fireRate:1100, range:280, color:'#8a4444', r:14, ammo:'normal',  kind:'laser',   mag:12, reload:1600, score:40  },
  swarmer:  { key:'swarmer',  name:'Svärmare',  hp:220,  dmg:70,  speed:2.4, fireRate:900,  range:170, color:'#9a6a2a', r:10, ammo:'normal',  kind:'burst',   mag:12, reload:1300, score:25  },
  brute:    { key:'brute',    name:'Brute',     hp:1500, dmg:280, speed:0.9, fireRate:1900, range:260, color:'#7a3030', r:19, ammo:'special', kind:'missile', mag:5,  reload:2600, score:90  },
  sniper:   { key:'sniper',   name:'Krypskytt', hp:500,  dmg:350, speed:1.1, fireRate:1900, range:430, color:'#5a3a7a', r:13, ammo:'special', kind:'plasma',  mag:5,  reload:2600, score:75, telegraph:700 },
  guardian: { key:'guardian', name:'Väktare',   hp:900,  dmg:190, speed:1.0, fireRate:1300, range:240, color:'#3d6a78', r:17, ammo:'normal',  kind:'slug',    mag:10, reload:1900, score:85, miniShield:600 },
  sapper:   { key:'sapper',   name:'Sprängare', hp:420,  dmg:620, speed:2.1, fireRate:0,    range:52,  color:'#a65a22', r:13, ammo:'normal',  kind:'shell',   mag:1,  reload:1,    score:70, suicide:true },
  artillery:{ key:'artillery',name:'Artilleri', hp:1100, dmg:460, speed:0.55,fireRate:3000, range:620, color:'#6a5030', r:20, ammo:'special', kind:'shell',   mag:3,  reload:3200, score:120, mortar:true, telegraph:1300 },
  // Nya typer: reparerar andra, syns inte förrän de är nära, ger andra sköld
  medic:    { key:'medic',    name:'Fältmekaniker', hp:700, dmg:90, speed:1.3, fireRate:1500, range:380, color:'#3f8a5a', r:14, ammo:'normal', kind:'laser', mag:8, reload:1800, score:95, healer:true },
  stalker:  { key:'stalker',  name:'Smygare',   hp:600,  dmg:240, speed:2.2, fireRate:700,  range:150, color:'#4a4a5e', r:12, ammo:'normal',  kind:'burst',   mag:9,  reload:1400, score:90, stealth:true },
  caster:   { key:'caster',   name:'Barriärbärare', hp:950, dmg:120, speed:1.0, fireRate:1600, range:330, color:'#2f5f8f', r:16, ammo:'normal', kind:'slug', mag:8, reload:2000, score:110, caster:true }
};

/** Vilka fiendetyper som får dyka upp när — svårighetskurvan i en tabell. */
export function enemyPoolFor(globalWave){
  const pool = ['drone'];
  if (globalWave >= 2)  pool.push('swarmer');
  if (globalWave >= 4)  pool.push('brute');
  if (globalWave >= 6)  pool.push('sniper', 'sapper');
  if (globalWave >= 9)  pool.push('guardian');
  if (globalWave >= 13) pool.push('artillery');
  if (globalWave >= 7)  pool.push('medic');
  if (globalWave >= 8)  pool.push('stalker');
  if (globalWave >= 11) pool.push('caster');
  return pool;
}

/* ---------------------------------------------------------
   BOSSAR
   Fyra arketyper som roterar. Varje har egen sköld, färg och
   specialattack — och varje special varnas innan den avfyras.
   --------------------------------------------------------- */
export const BOSS_ARCHETYPES = [
  { key:'sentinel',   title:'VÄKTARE',    color:'#5fb3d4', kind:'slug',    shield:'blue',   tell:'ringattack'  },
  { key:'warlord',    title:'KRIGSHERRE', color:'#e8a53e', kind:'shell',   shield:'gold',   tell:'salva'       },
  { key:'reaper',     title:'SKÖRDARE',   color:'#b88df2', kind:'laser',   shield:'pulse',  tell:'solfjäder'   },
  { key:'juggernaut', title:'JUGGERNAUT', color:'#c8683e', kind:'missile', shield:null,     tell:'missilregn'  }
];
export const BOSS_NAMES = ['GOLIAT','RAVAGER','DOMEDAGSVAKT','MONARK','KOLOSS','ÖDESBRINGARE'];

/* ---------------------------------------------------------
   KARTOR
   Varje biom har egen palett, terrängtyp och luftpartiklar.
   --------------------------------------------------------- */
export const MAPS = [
  { name:'Askfältet',   biome:'ash',     ground:'#2b2019', deep:'#1a120d', rock:'#463629', accent:'#ff8a4c', sky:'#120c09', air:'ember' },
  { name:'Frostravinen',biome:'frost',   ground:'#16232e', deep:'#0c141c', rock:'#2d4557', accent:'#8fe8f5', sky:'#0a121a', air:'snow'  },
  { name:'Rostslätten', biome:'rust',    ground:'#272014', deep:'#16110a', rock:'#4a3f22', accent:'#e0a840', sky:'#120e08', air:'dust'  },
  { name:'Kärnreaktorn',biome:'reactor', ground:'#20132a', deep:'#120a18', rock:'#3e2050', accent:'#c96af5', sky:'#0e0714', air:'spark' }
];

/* ---------------------------------------------------------
   SEKTORER OCH KAMPANJ
   --------------------------------------------------------- */
export function sectorLength(sector){ return sector === 1 ? 5 : 20 + (sector - 2) * 10; }
export function mapForSector(sector){ return MAPS[(sector - 1) % MAPS.length]; }

const SECTOR_NAMES = [
  'Tutorial','Signalen','Testfältet','Samordningen','Tystnaden','Signaturen','Väktarna',
  'Arkitekten','Sabotaget','Störningen','Hotet mot basen','Avhopparen','Supervapnet',
  'Sista fronten','Efter stormen'
];
export function sectorName(sector){
  if (sector >= 1 && sector <= SECTOR_NAMES.length) return SECTOR_NAMES[sector - 1];
  const region = ['Yttre bältet','Glömda ravinen','Norra fronten','Askfälten','Tysta zonen','Djuphålan','Gränslinjen','Kärnzonen'];
  return region[sector % region.length];
}

const INTRO_TUTORIAL = 'Fem vågor och en slutboss. Lär dig gå, sikta och ladda om innan det börjar kosta något.';
const INTROS = [
  'Ett nödrop från gränssektorn tystnade mitt i sändningen. Du är närmaste enhet.',
  'Fiendens rörelser är för exakta för att vara slump. De testar nya modeller på levande mål.',
  'Signalanalysen visar ett enda kommandonät bakom allt. Någon dirigerar offensiven.',
  'Tre angränsande sektorer tappade kontakten samtidigt. Ingen nödsignal. Bara tystnad.',
  'Sensorerna mäter en energisignatur i sektorns kärna som växer för varje timme.',
  'Sköldbärande enheter har synts i fält. Grannenheten som rapporterade dem hördes aldrig av igen.',
  'Ett namn återkommer i varje avlyssnat meddelande: Arkitekten.',
  'Fiendens ingenjörer planterar laddningar längs frontlinjen. Skjut sönder dem innan tiden går ut.',
  'Störsändare slår ut vår kommunikation mitt i strid. Förstör dem först.',
  'Arkitekten har riktat om sina styrkor mot vår egen bas. Vi kan inte dra oss tillbaka nu.',
  'En krypterad signal ber om skydd. Någon inifrån fiendens led vill hjälpa oss.',
  'Arkitektens projekt avslöjas: en reaktor stor nog att släcka en hel sektor.',
  'Allt som byggts upp möter dig här, samtidigt, i sektorns hjärta.',
  'Huvudstyrkan är krossad. Nätet sträcker sig längre än så. Kriget fortsätter.'
];
export function sectorIntro(sector){
  if (sector === 1) return INTRO_TUTORIAL;
  const i = sector - 2;
  if (i < INTROS.length) return INTROS[i];
  const threat = ['nya robotvarianter','förstärkta väktarenheter','okänd teknik','rester av Arkitektens nät','en ny befälhavare','autonoma svärmar'];
  return `Fronten flyttas vidare. Underrättelser varnar för ${threat[(sector * 3) % threat.length]}. Ingen förstärkning i sikte.`;
}

/* ---------------------------------------------------------
   HÄNDELSER MITT I STRID
   --------------------------------------------------------- */
export const EVENTS = {
  bomb:   { id:'bomb',   name:'SABOTAGE',    color:'#ff6a3d', time:32000, text:'Laddningar aktiverade. Förstör alla innan tiden går ut.', fail:'Laddningarna detonerade — skrovskada.' },
  jammer: { id:'jammer', name:'STÖRSÄNDARE', color:'#c96af5', time:28000, text:'Sensorn störd. Slå ut sändarna för att återfå radarn.',    fail:'Störningen håller i sig. Radarn är nere vågen ut.' },
  supply: { id:'supply', name:'FÖRRÅDSFALL', color:'#58c98a', time:26000, text:'Förrådskapslar landade. Hämta dem innan fienden gör det.', fail:'Kapslarna plundrades.' }
};

/* ---------------------------------------------------------
   EKONOMI
   --------------------------------------------------------- */
export const ECONOMY = {
  agPerWave: 95,          // × vågnummer
  agPerKill: 14,
  auPerBoss: 8,
  auPerSector: 25,
  plPerSectorFinale: 2,
  /** Uppgraderingskostnad för nivå `lvl` → `lvl+1`. */
  upgradeCost(base, lvl){ return Math.round(base * Math.pow(1.42, lvl)); }
};

/* ---------------------------------------------------------
   ROBOTPLATSER
   Man börjar med en plats. Plats 2 och 3 köps efter träningen
   (sektor 1) — den andra guiden visar var.
   --------------------------------------------------------- */
export const SLOT_PRICES = [
  null,                          // plats 1 ingår alltid
  { ag: 1200, au: 0,  pl: 0 },   // plats 2
  { ag: 0,    au: 25, pl: 0 }    // plats 3
];

/* ---------------------------------------------------------
   SPELLÄGEN
   Alla utom träningen låses upp när sektor 1 är klar.
   --------------------------------------------------------- */
export const GAME_MODES = {
  sectors: { id:'sectors', name:'Sektorer',    short:'Egen kampanj, sektor för sektor' },
  story:   { id:'story',   name:'Story',       short:'Berättelsen i kapitel' },
  weekly:  { id:'weekly',  name:'Utmaning',    short:'Ny twist varje vecka' },
  survival:{ id:'survival',name:'Överlevnad',  short:'Oändliga vågor' },
  trial:   { id:'trial',   name:'Arena',       short:'Bossrush, tidsattack, dagens' },
  multi:   { id:'multi',   name:'Multiplayer', short:'Upp till 4 spelare' }
};
export const MODE_ORDER = ['sectors', 'story', 'weekly', 'survival', 'trial', 'multi'];
export const MULTI_MAX_PLAYERS = 4;

/* ---------------------------------------------------------
   STORY — handskrivna kapitel
   Varje kapitel är en kort, fast utryckning: bestämt antal
   vågor, en tvingad händelse och en slutboss. `sector` styr
   karta och bossnivå, `startWave` styr fiendernas styrka.
   `lines` visas som berättelsebanner när vågen börjar.
   --------------------------------------------------------- */
export const STORY_CHAPTERS = [
  { id:1, title:'Nödropet', sector:2, startWave:2, waves:4, event:null, eventWave:0,
    brief:'Utpost Vega sände ett nödrop och tystnade sedan. Du är närmaste enhet. Ta dig in och ta reda på vad som hände.',
    lines:{ 2:'Utposten är tom. Bara spår av bandvagnar som går norrut.', 4:'Något stort rör sig mot dig. Det här var ingen patrull.' },
    debrief:'Utposten föll inte av en slump. Någon visste exakt när vakten byttes.',
    reward:{ ag:900, au:10, pl:0 } },
  { id:2, title:'Spåren norrut', sector:3, startWave:3, waves:5, event:'supply', eventWave:2,
    brief:'Bandvagnsspåren leder till ett förråd som fienden tömmer. Säkra lådorna innan de hinner lasta allt.',
    lines:{ 2:'Förrådskapslar på väg ned. Plocka upp dem innan fienden gör det.', 5:'Förrådets vakt har vaknat.' },
    debrief:'Lådorna var märkta med en symbol ingen känner igen — en triangel i en ring.',
    reward:{ ag:1300, au:15, pl:0 } },
  { id:3, title:'Tystnaden', sector:4, startWave:4, waves:5, event:'jammer', eventWave:3,
    brief:'Tre sektorer tappade kontakten samtidigt. Något stör våra sändningar. Hitta källan.',
    lines:{ 3:'Radarn dör. Störsändarna står nära — slå ut dem.', 5:'Sändarens operatör skyddar sin maskin.' },
    debrief:'Störsändarna var nya. Byggda i veckan. Någon rustar upp snabbt.',
    reward:{ ag:1700, au:20, pl:0 } },
  { id:4, title:'Sabotören', sector:5, startWave:5, waves:6, event:'bomb', eventWave:3,
    brief:'Laddningar har placerats längs försörjningsvägen. Om de detonerar är fronten avskuren.',
    lines:{ 3:'Laddningarna är armerade. Förstör dem innan tiden tar slut.', 6:'Sabotörernas befäl tar själv till fältet.' },
    debrief:'Befälet bar samma symbol. Triangeln i ringen. Arkitektens märke.',
    reward:{ ag:2200, au:25, pl:1 } },
  { id:5, title:'Avhopparen', sector:6, startWave:6, waves:6, event:'supply', eventWave:2,
    brief:'En krypterad signal ber om skydd. En av Arkitektens ingenjörer vill hoppa av — om du hinner fram först.',
    lines:{ 2:'Avhopparen skickar förnödenheter som bevis. Hämta dem.', 6:'Arkitekten har skickat en jägare efter avhopparen.' },
    debrief:'Avhopparen lever. Hon vet var reaktorn byggs.',
    reward:{ ag:2800, au:30, pl:1 } },
  { id:6, title:'Reaktorn', sector:8, startWave:8, waves:7, event:'jammer', eventWave:4,
    brief:'Reaktorn är nästan klar. Stor nog att släcka en hel sektor. Det här är sista chansen att stoppa den.',
    lines:{ 4:'Försvarsnätet slår ut sensorerna. Hitta sändarna.', 7:'Arkitekten själv står mellan dig och reaktorn.' },
    debrief:'Reaktorn är släckt. Arkitekten är borta — men nätet han byggde lever vidare i sektorerna.',
    reward:{ ag:3600, au:45, pl:3 } }
];

/* ---------------------------------------------------------
   LACKERINGAR — vad Platina köper
   Rent utseende: påverkar inte värden. En lackering köps en
   gång och kan sedan läggas på alla robotar. 'standard' är
   robotens egen fabriksfärg och är alltid gratis.
   --------------------------------------------------------- */
export const PAINTS = {
  standard: { id:'standard', name:'Fabrikslack',   color:null,      price:{ag:0,au:0,pl:0}, desc:'Robotens egen färg.' },
  ash:      { id:'ash',      name:'Aska',          color:'#9aa3ab', price:{ag:0,au:0,pl:2}, desc:'Matt grå, syns knappt i rök.' },
  forest:   { id:'forest',   name:'Skogskamo',     color:'#6f9a5c', price:{ag:0,au:0,pl:3}, desc:'Mörkgrön fältlack.' },
  desert:   { id:'desert',   name:'Ökensand',      color:'#d8b27a', price:{ag:0,au:0,pl:3}, desc:'Blekt sandfärg.' },
  arctic:   { id:'arctic',   name:'Arktis',        color:'#e4eef4', price:{ag:0,au:0,pl:4}, desc:'Nästan vit, med blå skugga.' },
  crimson:  { id:'crimson',  name:'Karmosin',      color:'#d9425a', price:{ag:0,au:0,pl:5}, desc:'Djupröd, för den som vill synas.' },
  violet:   { id:'violet',   name:'Nattviol',      color:'#a07ae8', price:{ag:0,au:0,pl:6}, desc:'Blålila med kall glans.' },
  gold:     { id:'gold',     name:'Veteranguld',   color:'#f0c24e', price:{ag:0,au:0,pl:10}, desc:'Blankt guld. Förtjänat, inte köpt — nästan.' },
  ember:    { id:'ember',    name:'Glöd',          color:'#ff6a2c', price:{ag:0,au:0,pl:12}, desc:'IRONFRONTs egen orange.' }
};
export const PAINT_ORDER = ['standard','ash','forest','desert','arctic','crimson','violet','gold','ember'];

/* ---------------------------------------------------------
   VECKANS UTMANING
   Varje vecka väljs två regler ur listan nedan, utifrån
   veckonumret — alla spelare får samma utmaning samma vecka.
   Reglerna är data: battle.js läser flaggorna, inget mer.
   --------------------------------------------------------- */
export const WEEKLY_MODS = {
  swarm:   { id:'swarm',   name:'Svärm',         text:'Dubbelt så många fiender, men de tål hälften.',     enemyCount:2,   enemyHp:0.5 },
  glass:   { id:'glass',   name:'Glaskanon',     text:'Du gör 60 % mer skada men har halva livet.',        playerDmg:1.6,  playerHp:0.5 },
  blind:   { id:'blind',   name:'Blind front',   text:'Radarn är avslagen hela uppdraget.',                noRadar:true },
  dry:     { id:'dry',     name:'Torrlagt',      text:'Inga reparationer faller från fiender eller lådor.', noRepair:true },
  rush:    { id:'rush',    name:'Stormlöpning',  text:'Fienderna rör sig 35 % snabbare.',                  enemySpeed:1.35 },
  armored: { id:'armored', name:'Pansarvåg',     text:'Fienderna tål 50 % mer, men ger dubbelt Argentum.', enemyHp:1.5, agMult:2 },
  bosses:  { id:'bosses',  name:'Bossjakt',      text:'Boss var tredje våg istället för var femte.',       bossEvery:3 }
};
export const WEEKLY_REWARD = { ag:0, au:20, pl:4 };
export const WEEKLY_WAVES = 8;

/** ISO-veckonummer, t.ex. { year: 2026, week: 39 }. */
export function isoWeek(date = new Date()){
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const day = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - day);
  const y0 = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  return { year: d.getUTCFullYear(), week: Math.ceil(((d - y0) / 86400000 + 1) / 7) };
}

/** Veckans utmaning — samma för alla, bestäms helt av veckonumret. */
export function weeklyChallenge(date = new Date()){
  const { year, week } = isoWeek(date);
  let seed = (year * 53 + week) >>> 0;
  const rnd = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
  const keys = Object.keys(WEEKLY_MODS);
  const a = keys[Math.floor(rnd() * keys.length)];
  let b = keys[Math.floor(rnd() * keys.length)];
  if (b === a) b = keys[(keys.indexOf(a) + 1 + Math.floor(rnd() * (keys.length - 1))) % keys.length];
  // Nästa måndag 00:00 lokal tid — när utmaningen byts
  const reset = new Date(date);
  reset.setHours(0, 0, 0, 0);
  reset.setDate(reset.getDate() + ((8 - (reset.getDay() || 7)) % 7 || 7));
  return { id: `${year}-v${week}`, year, week, mods: [a, b], mapSeed: 3 + (week % 9), reset };
}

/** Co-op: antal vågor i en gemensam utryckning (boss på våg 5 och 10). */
export const COOP_WAVES = 10;

/* ---------------------------------------------------------
   SVÅRIGHET PER SEKTOR
   Träningen (sektor 1) har "dumma" fiender: svaga, långsamma,
   dålig sikt och ingen sköld på bossen. Från sektor 2 är de
   smarta: siktar dit du är på väg och rör sig i sidled — och
   varje sektor börjar ett par steg starkare än den förra, så
   att det faktiskt blir svårare ju längre man kommer.
   --------------------------------------------------------- */
export const TRAINING_ENEMY = { hp: 0.45, dmg: 0.4, fireRate: 1.9, speed: 0.8 };
export const TRAINING_BOSS  = { hp: 6500, dmg: 0.45, specialCooldown: 9500 };

/** Vilken "global våg" (styrka) en sektor börjar på. Sektor 2 börjar lätt. */
export function sectorStartWave(sector){ return sector <= 2 ? 1 : 1 + (sector - 2) * 4; }

/** Hur mycket fienden förutser din rörelse när den siktar (0 = inget alls). */
export function enemyLead(sector){ return sector <= 1 ? 0 : Math.min(0.2, 0.07 + (sector - 2) * 0.02); }

/* =========================================================
   NIVÅER (1–30)
   Man börjar på nivå 1. Klarar man träningen hoppar man
   direkt till nivå 2 — sedan är det XP som gäller. XP kommer
   från alla spellägen: mer för vinst, mindre för förlust,
   inget alls om man lämnar. Varje nivå låser upp något.
   ========================================================= */
export const MAX_LEVEL = 30;

/** XP som krävs för att gå från nivå L till L+1 (L ≥ 2). Växer mjukt. */
export function xpStep(L){ return Math.round((550 + 240 * Math.pow(Math.max(0, L - 2), 1.2)) / 10) * 10; }

/** Total XP som krävs för att NÅ nivå L. Nivå 2 = 0: den ges av träningen. */
export function xpForLevel(L){
  if (L <= 2) return 0;
  let t = 0;
  for (let i = 2; i < L; i++) t += xpStep(i);
  return t;
}

/** Vilken nivå en viss XP-summa motsvarar (från nivå 2 och uppåt). */
export function levelForXp(xp){
  let L = 2;
  while (L < MAX_LEVEL && xp >= xpForLevel(L + 1)) L++;
  return L;
}

/** Robotplatser: plats 2 kan köpas från nivå 2, plats 3 från nivå 15. */
export const SLOT_LEVELS = [1, 2, 15];

/* Vad varje nivå låser upp. Robotar och vapen som inte står här
   (RECON, Lätt kanon, Standardkanon) finns från start. */
export const LEVEL_UNLOCKS = {
  2:  { robots: ['vulcan', 'raptor'], weapons: ['rapid_std'], slot: 2, modes: true },
  3:  { weapons: ['burst_std'] },
  4:  { robots: ['aegis'] },
  5:  { weapons: ['laser_std'] },
  6:  { robots: ['titan'] },
  7:  { weapons: ['shell_heavy'] },
  8:  { robots: ['hydra'] },
  10: { robots: ['warden'], weapons: ['plasma_std'] },
  12: { robots: ['paladin'], weapons: ['missile_std'] },
  14: { weapons: ['shell_super'] },
  15: { slot: 3 },
  17: { robots: ['nova'] },
  20: { robots: ['surge'], weapons: ['sniper_rail'] },
  24: { robots: ['phantom'] },
  30: { paints: ['gold'] }
};

/* ---------------------------------------------------------
   TITLAR — en ny var femte nivå
   Visas under ditt namn över roboten, i lobbyn och i hangaren.
   `tier` styr färgen; den sista har en levande aura.
   --------------------------------------------------------- */
export const TITLES = [
  { level: 1,  name: 'Rekryt',          color: '#9fb0bf', tier: 0 },
  { level: 5,  name: 'Soldat',          color: '#c8d4de', tier: 1 },
  { level: 10, name: 'Stridspilot',     color: '#6fd39a', tier: 2 },
  { level: 15, name: 'Veteran',         color: '#5fb3d4', tier: 3 },
  { level: 20, name: 'Stålhjärta',      color: '#b07af0', tier: 4 },
  { level: 25, name: 'Frontens skräck', color: '#ff6a2c', tier: 5 },
  { level: 30, name: 'Järnvarg',        color: '#ffd35a', tier: 6, aura: true }
];
export function titleFor(level){
  let t = TITLES[0];
  for (const x of TITLES) if (level >= x.level) t = x;
  return t;
}

/** Belöning för varje ny nivå — lite extra att handla för. */
export function levelReward(L){
  return { ag: 300 + L * 60, au: L % 5 === 0 ? 10 + L : 0, pl: L % 10 === 0 ? 5 : 0 };
}

/** Lägsta nivå för en robot eller ett vapen (1 = från start). */
export function unlockLevel(kind, id){
  for (const [L, u] of Object.entries(LEVEL_UNLOCKS)) if (u[kind]?.includes(id)) return +L;
  return 1;
}

/* XP för en utryckning:
   grund = vågor × 15 + nedkämpade × 2 + bossar × 50
   vinst → grund + bonus för läget, förlust → halva grunden, lämnat → 0 */
export const XP_WIN_BONUS = { sectors: s => 150 + 30 * s, story: first => first ? 250 : 100, weekly: () => 350, coop: () => 300 };
export function runXp({ reason, won, waves, kills, bosses, mode, sector, firstClear }){
  if (reason === 'abandon') return 0;
  const base = waves * 15 + kills * 2 + bosses * 50;
  // Överlevnad går inte att vinna — det räknas som en hel insats oavsett hur det slutar
  if (mode === 'survival') return Math.round(base * 1.1);
  if (!won) return Math.round(base * 0.5);
  const bonus = mode === 'trial' ? 250
              : mode === 'story' ? XP_WIN_BONUS.story(firstClear)
              : mode === 'weekly' ? XP_WIN_BONUS.weekly()
              : mode === 'coop' ? XP_WIN_BONUS.coop()
              : XP_WIN_BONUS.sectors(sector);
  return Math.round(base + bonus);
}

/* =========================================================
   FÖRMÅGOR FÖR ALLA ROBOTAR
   RECON (sensorpuls), NOVA (kast), SURGE (överladdning) och
   PHANTOM (prisma) har sina förmågor ovan. Resten får en
   egen här — alla på Shift/Q, alla uppgraderbara via
   "Förmågekärna".
   ========================================================= */
export const SPECIALS = {
  barrage: { name: 'SPÄRRELD',        text: 'Ingen ammo går åt och vapnen skjuter 40 % snabbare',       cooldown: 16000, duration: 4000 },
  hunt:    { name: 'JAKTLÄGE',        text: '60 % snabbare och 30 % mer skada',                         cooldown: 15000, duration: 4000 },
  pulse:   { name: 'SKÖLDPULS',       text: 'Fyller skölden direkt och slår undan fiender runt dig',    cooldown: 18000, duration: 0, radius: 260, dmg: 350 },
  stomp:   { name: 'STAMPA',          text: 'Tryckvåg som skadar och bromsar alla fiender nära dig',    cooldown: 14000, duration: 0, radius: 240, dmg: 900 },
  swarm:   { name: 'MISSILSVÄRM',     text: 'Skjuter 8 målsökande missiler mot närmaste fiender',       cooldown: 15000, duration: 0, count: 8, dmg: 260 },
  repair:  { name: 'REPARATIONSFÄLT', text: 'Reparerar dig och lagkamrater nära dig i 4 sekunder',       cooldown: 22000, duration: 4000, radius: 320, heal: 0.09 },
  bastion: { name: 'BASTION',         text: 'Tar 70 % mindre skada och skölden laddas om snabbare',      cooldown: 20000, duration: 4000, reduce: 0.7 }
};
const SPECIAL_OF = { vulcan: 'barrage', raptor: 'hunt', aegis: 'pulse', titan: 'stomp', hydra: 'swarm', warden: 'repair', paladin: 'bastion' };
for (const [robot, kind] of Object.entries(SPECIAL_OF)) if (ROBOTS[robot]) ROBOTS[robot].special = { kind, ...SPECIALS[kind] };

/* =========================================================
   ARENA — tre korta utmaningar med egna topplistor
   Fast svårighet (samma sektor för alla) så att topplistorna
   blir rättvisa. Det som skiljer spelarna åt är robotar,
   uppgraderingar och skicklighet.
   ========================================================= */
export const TRIALS = {
  bossrush:   { id: 'bossrush',   name: 'Bossrush',      sector: 4, waves: 5,  bossEvery: 1, rank: 'time',
                text: 'Fem bossar i rad, inga vanliga vågor. Snabbast tid vinner.' },
  timeattack: { id: 'timeattack', name: 'Tidsattack',    sector: 3, waves: 10, rank: 'time',
                text: 'Tio vågor så snabbt som möjligt. Klockan startar när striden börjar.' },
  daily:      { id: 'daily',      name: 'Dagens sektor', sector: 3, waves: 10, rank: 'score',
                text: 'Samma sektor och samma två regler för alla i dag. Högst poäng vinner.' }
};

/** Dagens sektor: två regler (samma som veckans utmaning använder), valda utifrån datumet. */
export function dailyTrial(date = new Date()){
  const id = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
  let seed = 0; for (const c of id) seed = (seed * 31 + c.charCodeAt(0)) >>> 0;
  const rnd = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
  const keys = Object.keys(WEEKLY_MODS);
  const a = keys[Math.floor(rnd() * keys.length)];
  let b = keys[Math.floor(rnd() * keys.length)];
  if (b === a) b = keys[(keys.indexOf(a) + 1) % keys.length];
  return { id, mods: [a, b] };
}

/** 83 456 ms → "1:23.4" */
export function fmtRace(ms){
  const s = Math.max(0, ms) / 1000;
  return `${Math.floor(s / 60)}:${(s % 60).toFixed(1).padStart(4, '0')}`;
}
