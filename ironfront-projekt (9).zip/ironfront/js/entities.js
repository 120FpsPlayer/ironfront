/* =========================================================
   IRONFRONT — enheter
   Här översätts data (mallar, nivåer, uppgraderingar) till
   de objekt som striden faktiskt räknar på.
   ========================================================= */
import { ROBOTS, WEAPONS, ENEMIES, BOSS_ARCHETYPES, BOSS_NAMES, DIFFICULTIES } from './data.js';
import { baseMods } from './perks.js';
import { state, slotColor } from './state.js';
import { clamp } from './util.js';

/** Vapnets värden efter uppgraderingar. Används både i strid och i menyn. */
export function weaponStats(def, lvl){
  return {
    dmg:    def.dmg * (1 + lvl.dmg * 0.16),
    fireRate: def.fireRate * (1 - lvl.rate * 0.09),
    mag:    Math.round(def.mag * (1 + (lvl.mag || 0) * 0.15)),
    reload: def.reload * Math.max(0.6, 1 - (lvl.reload || 0) * 0.07)
  };
}

export function buildPlayer(slot){
  const tpl = ROBOTS[slot.tpl];
  const lvl = slot.lvl;
  const hp = Math.round(tpl.baseHp * (1 + lvl.hp * 0.14));

  // Varje montage har egen uppgraderingsnivå. Montage med exakt samma
  // vapen OCH samma nivå delar magasin — skiljer de sig åt får de var sitt.
  const mountDefs = tpl.mounts.map((mount, i) => ({
    mount, weaponId: slot.weapons[i], lvl: slot.mountLvls[i]
  }));
  if (slot.extraUnlocked)
    mountDefs.push({ mount: { offset: 0, spread: 7 }, weaponId: slot.extraWeapon, lvl: slot.extraLvl });

  const groups = new Map();
  for (const md of mountDefs){
    const k = `${md.weaponId}|${md.lvl.dmg},${md.lvl.rate},${md.lvl.reload},${md.lvl.mag || 0}`;
    if (!groups.has(k)) groups.set(k, { id: md.weaponId, lvl: md.lvl, mounts: [] });
    groups.get(k).mounts.push(md.mount);
  }

  const weaponGroups = [];
  for (const g of groups.values()){
    const def = WEAPONS[g.id] || WEAPONS.slug_light;
    const st = weaponStats(def, g.lvl);
    weaponGroups.push({
      id: g.id, name: def.name, kind: def.kind, ammo: def.ammo, range: def.range,
      magSize: st.mag, ammoLeft: st.mag, reloading: false, reloadTimer: 0, reloadTime: st.reload,
      freshMag: true,
      mounts: g.mounts.map(m => ({
        dmg: st.dmg, fireRate: st.fireRate, spread: m.spread || 0, offset: m.offset || 0, cooldown: 0
      }))
    });
  }

  let shield = null;
  if (tpl.shield){
    if (tpl.shield.type === 'purple'){
      shield = {
        type: 'purple',
        duration: tpl.shield.duration * (1 + lvl.ability * 0.09),
        cooldown: tpl.shield.cooldown * (1 - lvl.ability * 0.07),
        cdLeft: 0, active: false, activeLeft: 0
      };
    } else {
      const cap = tpl.shield.capacity * (0.5 + lvl.shield * 0.22);
      shield = {
        type: tpl.shield.type, capacity: cap, current: cap,
        regenDelay: tpl.shield.regenDelay, regenRate: tpl.shield.regenRate, sinceHit: 99999
      };
    }
  }

  const speed = 3.1 * tpl.speed * (1 + lvl.speed * 0.05);

  return {
    isPlayer: true,
    name: tpl.name, tplId: tpl.id, frame: tpl.frame, color: slotColor(slot),
    x: 0, y: 0, angle: 0, moveAngle: 0, walk: 0, radius: tpl.frame === 'heavy' ? 26 : tpl.frame === 'light' ? 20 : 23,
    speed, baseSpeed: speed,
    hp, maxHp: hp,
    weaponGroups, shield, shieldHits: [],
    mods: baseMods(), perks: [],
    invuln: 0, tookDamage: false, slowLeft: 0,
    dash: tpl.dash ? {
      cooldown: tpl.dash.cooldown * (1 - lvl.ability * 0.07), cdLeft: 0,
      active: false, activeLeft: 0, dashSpeed: tpl.dash.dashSpeed, duration: tpl.dash.duration,
      vulnDuration: tpl.dash.vulnDuration * (1 - lvl.ability * 0.09), vulnLeft: 0, dirX: 1, dirY: 0
    } : null,
    scan: tpl.scan ? {
      cooldown: tpl.scan.cooldown * (1 - lvl.ability * 0.07), cdLeft: 0,
      active: false, activeLeft: 0, duration: tpl.scan.duration * (1 + lvl.ability * 0.09),
      dmgBonus: tpl.scan.dmgBonus
    } : null,
    special: tpl.special ? {
      ...tpl.special,
      cooldown: tpl.special.cooldown * (1 - lvl.ability * 0.07), cdLeft: 0,
      active: false, activeLeft: 0, duration: tpl.special.duration * (1 + lvl.ability * 0.09),
      power: 1 + lvl.ability * 0.1
    } : null,
    overdrive: tpl.overdrive ? {
      cooldown: tpl.overdrive.cooldown * (1 - lvl.ability * 0.07), cdLeft: 0,
      active: false, activeLeft: 0, duration: tpl.overdrive.duration * (1 + lvl.ability * 0.09),
      rateMult: tpl.overdrive.fireRateMult, dmgMult: tpl.overdrive.dmgMult
    } : null,
    get barrels(){
      return this.weaponGroups.flatMap(g =>
        g.mounts.map(m => ({ offset: m.offset * 0.9, heavy: g.kind === 'shell' })));
    },
    get hpPct(){ return this.hp / this.maxHp; },
    stats: { shots: 0, hits: 0, damage: 0, taken: 0, kills: 0 }
  };
}

/** Vilken sorts förmåga roboten har — HUD:en behöver veta. */
export function abilityInfo(p){
  if (p.shield?.type === 'purple') return { key: 'prism', name: 'PRISMA', max: p.shield.cooldown };
  if (p.dash) return { key: 'dash', name: 'KAST', max: p.dash.cooldown };
  if (p.overdrive) return { key: 'over', name: 'ÖVERLADD', max: p.overdrive.cooldown };
  if (p.scan) return { key: 'scan', name: 'SENSORPULS', max: p.scan.cooldown };
  if (p.special) return { key: 'special', name: p.special.name, max: p.special.cooldown };
  return null;
}

/* ---------------------------------------------------------
   FIENDER
   --------------------------------------------------------- */
export function makeEnemy(typeKey, x, y, hpMult = 1, dmgMult = 1){
  const t = ENEMIES[typeKey];
  const diff = DIFFICULTIES[state.settings.difficulty] || DIFFICULTIES.soldat;
  const hp = t.hp * hpMult * diff.enemyHp;
  return {
    key: typeKey, name: t.name,
    x, y, angle: 0, moveAngle: 0, walk: Math.random() * 6,
    radius: t.r, frame: t.r > 17 ? 'heavy' : t.r < 12 ? 'light' : 'medium',
    color: t.color,
    hp, maxHp: hp,
    dmg: t.dmg * dmgMult * diff.enemyDmg,
    speed: t.speed, baseSpeed: t.speed,
    fireRate: t.fireRate, range: t.range,
    cooldown: 300 + Math.random() * 900,
    ammo: t.ammo, kind: t.kind,
    magSize: t.mag, ammoLeft: t.mag, reloading: false, reloadTimer: 0, reloadTime: t.reload,
    score: t.score, suicide: !!t.suicide, mortar: !!t.mortar,
    healer: !!t.healer, stealth: !!t.stealth, caster: !!t.caster, traitTimer: 1500 + Math.random() * 1500, sinceHit: 9999,
    telegraph: t.telegraph || 0, tellLeft: 0, tellTotal: t.telegraph || 1,
    slowLeft: 0, strafe: Math.random() < 0.5 ? 1 : -1, strafeTimer: 1200 + Math.random() * 1600,
    shield: t.miniShield ? {
      type: 'blue', capacity: t.miniShield * diff.enemyHp, current: t.miniShield * diff.enemyHp,
      regenDelay: 4000, regenRate: 120, sinceHit: 0
    } : null,
    shieldHits: [],
    get hpPct(){ return this.hp / this.maxHp; },
    barrels: [{ offset: 0, heavy: t.r > 17 }]
  };
}

/* ---------------------------------------------------------
   BOSSAR
   --------------------------------------------------------- */
export function makeBoss(sector, waveInSector, isFinale, x, y){
  const tier = sector === 1 ? 0 : (sector - 2) * 4 + Math.floor(waveInSector / 5);
  const arch = BOSS_ARCHETYPES[tier % BOSS_ARCHETYPES.length];
  const diff = DIFFICULTIES[state.settings.difficulty] || DIFFICULTIES.soldat;

  const finale = isFinale ? 1.7 : 1;
  const hpBoost = arch.key === 'juggernaut' ? 1.25 : 1;
  const hp = 10500 * (1 + tier * 0.42) * finale * hpBoost * diff.enemyHp;
  const shieldCap = hp * (arch.key === 'warlord' ? 0.34 : 0.26);

  return {
    isBoss: true, isFinale: !!isFinale, archetype: arch.key, tell: arch.tell,
    key: 'boss', name: (isFinale ? 'SEKTORSVAKT ' : arch.title + ' ') + BOSS_NAMES[tier % BOSS_NAMES.length],
    typeLabel: arch.title,
    x, y, angle: 0, moveAngle: 0, walk: 0,
    radius: isFinale ? 58 : 46, frame: 'heavy', color: isFinale ? '#e0355c' : arch.color,
    hp, maxHp: hp,
    dmg: 325 * (1 + tier * 0.18) * (isFinale ? 1.3 : 1) * diff.enemyDmg,
    speed: arch.key === 'juggernaut' ? 0.6 : 0.8,
    baseSpeed: arch.key === 'juggernaut' ? 0.6 : 0.8,
    fireRate: 900, range: 480, cooldown: 1400,
    ammo: 'special', kind: arch.kind,
    magSize: isFinale ? 34 : 26, ammoLeft: isFinale ? 34 : 26,
    reloading: false, reloadTimer: 0, reloadTime: 1300,
    specialTimer: 4200, specialCooldown: isFinale ? 5200 : 6600,
    // Faser: bossen byter beteende vid 66 % och 33 % liv (se battle.js → bossPhase)
    phase: 1, staggerLeft: 0,
    // Bossen sidoförflyttar sig som vanliga fiender. Utan de här två fälten
    // blev rörelseriktningen NaN så fort spelaren kom på skjutavstånd —
    // bossen "försvann" och ritningen kraschade (spelet frös).
    strafe: Math.random() < 0.5 ? 1 : -1, strafeTimer: 1600,
    tellLeft: 0, tellTotal: 1200,
    score: 900 * (1 + tier * 0.4), slowLeft: 0,
    shield: makeBossShield(arch, shieldCap),
    shieldHits: [],
    get hpPct(){ return this.hp / this.maxHp; },
    barrels: [{ offset: -14, heavy: true }, { offset: 14, heavy: true }]
  };
}

function makeBossShield(arch, cap){
  if (arch.shield === 'blue')
    return { type: 'blue', capacity: cap, current: cap, regenDelay: 5000, regenRate: cap * 0.15, sinceHit: 99999 };
  if (arch.shield === 'gold')
    return { type: 'gold', capacity: cap, current: cap, regenDelay: 5000, regenRate: cap * 0.12, sinceHit: 99999 };
  if (arch.shield === 'pulse')
    return { type: 'purple', cooldown: 10000, cdLeft: 5000, active: false, activeLeft: 0, duration: 2500 };
  return null;
}

/** Hur svåra fienderna är på en given global våg. */
export function waveScaling(globalWave){
  return {
    hp:  1 + (globalWave - 1) * 0.17,
    dmg: 1 + (globalWave - 1) * 0.085,
    count: clamp(3 + Math.floor(globalWave * 0.85), 3, 16)
  };
}
