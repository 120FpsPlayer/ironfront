/* =========================================================
   IRONFRONT — arenan
   Varje sektor har ett frö. Samma sektor ger alltid samma
   karta, så man kan lära sig terrängen istället för att
   varje försök kännas slumpat.
   ========================================================= */
import { mapForSector } from './data.js';
import { mulberry32, hashSeed, TAU, rgba, shade, clamp } from './util.js';

export const WORLD = { w: 4400, h: 3100 };

/** Ljusriktning för hela spelet. All skuggning utgår från samma sol. */
export const LIGHT = { x: -0.48, y: -0.88 };

export function buildArena(sector){
  const map = mapForSector(sector);
  const rnd = mulberry32(hashSeed(`ironfront|sector:${sector}|${map.biome}`));
  const obstacles = [];
  const decals = [];

  const { w, h } = WORLD;
  const cx = w / 2, cy = h / 2;

  /* --- Ytterväggar: en sluten arena istället för en osynlig gräns --- */
  const T = 90;
  push({ x: 0, y: 0, w, h: T, type: 'wall' });
  push({ x: 0, y: h - T, w, h: T, type: 'wall' });
  push({ x: 0, y: T, w: T, h: h - T * 2, type: 'wall' });
  push({ x: w - T, y: T, w: T, h: h - T * 2, type: 'wall' });

  function push(o){
    o.seed = rnd() * 9999;
    o.hp = o.type === 'crate' ? 420 : Infinity;
    o.maxHp = o.hp;
    if (o.type === 'rock') o.poly = rockPoly(o, rnd);
    obstacles.push(o);
    return o;
  }

  /** Kollar att en ny yta inte klämmer in sig för tätt intill en annan. */
  function free(x, y, ww, hh, pad = 120){
    if (x < T + 40 || y < T + 40 || x + ww > w - T - 40 || y + hh > h - T - 40) return false;
    // Mitten hålls öppen — där startar spelaren.
    if (Math.hypot(x + ww / 2 - cx, y + hh / 2 - cy) < 340) return false;
    return !obstacles.some(o =>
      x < o.x + o.w + pad && x + ww + pad > o.x &&
      y < o.y + o.h + pad && y + hh + pad > o.y);
  }

  function tryPlace(ww, hh, type, tries = 26){
    for (let i = 0; i < tries; i++){
      const x = T + 60 + rnd() * (w - T * 2 - ww - 120);
      const y = T + 60 + rnd() * (h - T * 2 - hh - 120);
      if (free(x, y, ww, hh)) return push({ x, y, w: ww, h: hh, type });
    }
    return null;
  }

  /* --- Fyra försvarsvärn kring mitten: ger täckning direkt vid start --- */
  const ring = 470;
  for (let i = 0; i < 4; i++){
    const a = TAU * (i / 4) + Math.PI / 4;
    const bx = cx + Math.cos(a) * ring, by = cy + Math.sin(a) * ring;
    const horiz = Math.abs(Math.cos(a)) < 0.7;
    const bw = horiz ? 260 : 60, bh = horiz ? 60 : 260;
    push({ x: bx - bw / 2, y: by - bh / 2, w: bw, h: bh, type: 'barrier' });
  }

  /* --- Ruiner: L- och T-formade murrester som bildar gränder --- */
  const ruinCount = 7 + Math.floor(rnd() * 4);
  for (let i = 0; i < ruinCount; i++){
    const long = 200 + rnd() * 240, thick = 52 + rnd() * 18;
    const vertical = rnd() < 0.5;
    const first = tryPlace(vertical ? thick : long, vertical ? long : thick, 'ruin');
    if (!first) continue;
    // Andra benet i vinkel mot det första
    if (rnd() < 0.65){
      const l2 = 150 + rnd() * 180;
      const x2 = vertical ? first.x : first.x + first.w - thick;
      const y2 = vertical ? first.y + first.h - thick : first.y;
      const ww = vertical ? l2 : thick, hh = vertical ? thick : l2;
      if (free(x2, y2, ww, hh, 40)) push({ x: x2, y: y2, w: ww, h: hh, type: 'ruin' });
    }
  }

  /* --- Klippblock och pelare --- */
  const rocks = 14 + Math.floor(rnd() * 8);
  for (let i = 0; i < rocks; i++){
    const s = 70 + rnd() * 110;
    tryPlace(s, s * (0.72 + rnd() * 0.5), 'rock');
  }
  const pylons = map.biome === 'reactor' ? 8 : 4;
  for (let i = 0; i < pylons; i++) tryPlace(46, 46, 'pylon');

  /* --- Lådor: förstörbara, och de enda hindren som ger något tillbaka --- */
  const crates = 12 + Math.floor(rnd() * 8);
  for (let i = 0; i < crates; i++){
    const s = 40 + rnd() * 16;
    const c = tryPlace(s, s, 'crate', 14);
    // Lådor står ofta i par
    if (c && rnd() < 0.5 && free(c.x + c.w + 6, c.y, s, s, 0))
      push({ x: c.x + c.w + 6, y: c.y, w: s, h: s, type: 'crate' });
  }

  /* --- Markdekaler: slitage, brännmärken, fältmarkeringar --- */
  for (let i = 0; i < 46; i++){
    decals.push({
      x: T + rnd() * (w - T * 2), y: T + rnd() * (h - T * 2),
      r: 40 + rnd() * 160, rot: rnd() * TAU,
      kind: rnd() < 0.25 ? 'scorch' : rnd() < 0.5 ? 'plate' : 'crack',
      a: 0.12 + rnd() * 0.22
    });
  }
  // Landningsmarkeringar runt startpunkten — sektorn är bemannad, inte tom.
  for (let i = 0; i < 4; i++){
    const a = TAU * (i / 4);
    decals.push({ x: cx + Math.cos(a) * 200, y: cy + Math.sin(a) * 200, r: 60, rot: a, kind: 'mark', a: 0.5 });
  }

  return { map, obstacles, decals, tile: makeGroundTile(map, sector), w, h, spawn: { x: cx, y: cy } };
}

/** Oregelbunden stenform — slumpad en gång, sedan konstant. */
function rockPoly(o, rnd){
  const n = 7 + Math.floor(rnd() * 4);
  const pts = [];
  for (let i = 0; i < n; i++){
    const a = TAU * (i / n);
    const rr = 0.72 + rnd() * 0.36;
    pts.push({ x: Math.cos(a) * (o.w / 2) * rr, y: Math.sin(a) * (o.h / 2) * rr });
  }
  return pts;
}

/* =========================================================
   MARKTEXTUR
   En 512×512-bricka ritas en gång och läggs som mönster över
   hela världen. Det är skillnaden mellan "en färgad yta" och
   "mark". Att göra det per bildruta hade varit omöjligt.
   ========================================================= */
const tileCache = new Map();

export function makeGroundTile(map, sector){
  const key = map.biome;
  if (tileCache.has(key)) return tileCache.get(key);

  const S = 512;
  const c = document.createElement('canvas');
  c.width = c.height = S;
  const g = c.getContext('2d');
  const rnd = mulberry32(hashSeed('tile|' + map.biome));

  g.fillStyle = map.ground;
  g.fillRect(0, 0, S, S);

  // Stora fläckar av ljusare och mörkare mark
  for (let i = 0; i < 260; i++){
    const x = rnd() * S, y = rnd() * S, r = 18 + rnd() * 96;
    const up = rnd() < 0.5;
    g.globalAlpha = 0.035 + rnd() * 0.05;
    g.fillStyle = up ? shade(map.rock, 0.12) : map.deep;
    g.beginPath();
    g.ellipse(x, y, r, r * (0.55 + rnd() * 0.6), rnd() * TAU, 0, TAU);
    g.fill();
  }

  // Grus
  g.globalAlpha = 1;
  for (let i = 0; i < 2600; i++){
    const x = rnd() * S, y = rnd() * S, r = 0.5 + rnd() * 1.7;
    g.fillStyle = rnd() < 0.5 ? rgba(map.rock, 0.20 + rnd() * 0.3) : rgba('#000000', 0.16 + rnd() * 0.22);
    g.fillRect(x, y, r, r);
  }

  // Sprickor — korta, ledade linjer som följer en riktning
  for (let i = 0; i < 26; i++){
    let x = rnd() * S, y = rnd() * S, a = rnd() * TAU;
    g.strokeStyle = rgba('#000000', 0.16 + rnd() * 0.16);
    g.lineWidth = 0.6 + rnd() * 1.6;
    g.beginPath(); g.moveTo(x, y);
    const segs = 3 + Math.floor(rnd() * 5);
    for (let s = 0; s < segs; s++){
      a += (rnd() - 0.5) * 1.1;
      x += Math.cos(a) * (10 + rnd() * 34);
      y += Math.sin(a) * (10 + rnd() * 34);
      g.lineTo(x, y);
    }
    g.stroke();
  }

  // Biomspecifikt topplager
  if (map.biome === 'frost'){
    for (let i = 0; i < 90; i++){
      g.globalAlpha = 0.05 + rnd() * 0.09;
      g.fillStyle = '#dff4ff';
      g.beginPath();
      g.ellipse(rnd() * S, rnd() * S, 12 + rnd() * 54, 6 + rnd() * 22, rnd() * TAU, 0, TAU);
      g.fill();
    }
  } else if (map.biome === 'reactor'){
    g.globalAlpha = 0.5;
    g.strokeStyle = rgba(map.accent, 0.10); g.lineWidth = 1;
    for (let i = 0; i < 12; i++){
      const y = rnd() * S;
      g.beginPath(); g.moveTo(0, y); g.lineTo(S, y + (rnd() - 0.5) * 30); g.stroke();
    }
  } else if (map.biome === 'rust'){
    for (let i = 0; i < 60; i++){
      g.globalAlpha = 0.05 + rnd() * 0.08;
      g.fillStyle = '#8a4a16';
      g.beginPath();
      g.ellipse(rnd() * S, rnd() * S, 8 + rnd() * 40, 8 + rnd() * 40, 0, 0, TAU);
      g.fill();
    }
  } else {
    for (let i = 0; i < 70; i++){   // ask: mjuka drivor
      g.globalAlpha = 0.04 + rnd() * 0.06;
      g.fillStyle = '#6a5a4c';
      g.beginPath();
      g.ellipse(rnd() * S, rnd() * S, 20 + rnd() * 60, 6 + rnd() * 16, rnd() * TAU, 0, TAU);
      g.fill();
    }
  }
  g.globalAlpha = 1;

  tileCache.set(key, c);
  return c;
}

/* ---------- Kollision ---------- */
export function hitsObstacle(obstacles, x, y, r){
  for (const o of obstacles){
    if (o.hp <= 0) continue;
    const nx = clamp(x, o.x, o.x + o.w);
    const ny = clamp(y, o.y, o.y + o.h);
    if ((x - nx) ** 2 + (y - ny) ** 2 < r * r) return o;
  }
  return null;
}

export function outOfBounds(x, y, r){
  return x < r || y < r || x > WORLD.w - r || y > WORLD.h - r;
}

/** Fri sikt mellan två punkter? Enkel rasterisering, tillräckligt exakt för AI. */
export function lineOfSight(obstacles, x1, y1, x2, y2){
  const d = Math.hypot(x2 - x1, y2 - y1);
  const steps = Math.min(48, Math.ceil(d / 40));
  for (let i = 1; i < steps; i++){
    const t = i / steps;
    if (hitsObstacle(obstacles, x1 + (x2 - x1) * t, y1 + (y2 - y1) * t, 6)) return false;
  }
  return true;
}
