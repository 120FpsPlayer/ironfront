/* =========================================================
   IRONFRONT — dagliga uppdrag, prestationer, inloggningsbonus
   Allt här lyssnar på händelser från striden (bus) och på
   resultatet när en utryckning är slut. Inget i striden
   behöver veta att de här systemen finns.
   ========================================================= */
import { bus } from './util.js';
import { state, save, grant, addXp } from './state.js';
import { ROBOTS, WEAPONS, STORY_CHAPTERS, PAINTS } from './data.js';

/* ---------- Datum ---------- */
const pad = n => String(n).padStart(2, '0');
export const today = (d = new Date()) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const yesterday = () => { const d = new Date(); d.setDate(d.getDate() - 1); return today(d); };

/* =========================================================
   DAGLIGA UPPDRAG
   Tre uppdrag per dag, valda ur mallarna nedan utifrån
   datumet. Klara → XP och Argentum direkt (ingen knapp att
   trycka på). Nya uppdrag vid midnatt.
   ========================================================= */
const DAILY = [
  { id: 'kills',    text: n => `Fäll ${n} fiender`,                  n: [40, 70, 110],  xp: 260, ag: 400, on: 'kill' },
  { id: 'bosses',   text: n => `Fäll ${n} ${n > 1 ? 'bossar' : 'boss'}`, n: [1, 2, 3],   xp: 320, ag: 500, on: 'boss' },
  { id: 'waves',    text: n => `Klara ${n} vågor`,                   n: [12, 20, 30],   xp: 280, ag: 450, on: 'wave' },
  { id: 'win',      text: () => 'Vinn en utryckning (valfritt läge)', n: [1],           xp: 350, ag: 500, on: 'win' },
  { id: 'event',    text: n => `Klara ${n} ${n > 1 ? 'händelser' : 'händelse'} (sabotage, störsändare, förråd)`, n: [1, 2], xp: 300, ag: 450, on: 'event' },
  { id: 'pickups',  text: n => `Plocka upp ${n} föremål`,            n: [8, 14],        xp: 220, ag: 350, on: 'pickup' },
  { id: 'ability',  text: n => `Använd din förmåga ${n} gånger`,     n: [6, 12],        xp: 220, ag: 350, on: 'ability' },
  { id: 'elite',    text: n => `Fäll ${n} elitfiender`,              n: [2, 4],         xp: 300, ag: 450, on: 'elite' },
  { id: 'survival', text: n => `Nå våg ${n} i Överlevnad`,           n: [8, 12],        xp: 320, ag: 450, on: 'survivalWave', max: true },
  { id: 'coop',     text: () => 'Spela en co-op-match',              n: [1],            xp: 300, ag: 400, on: 'coop' }
];

function seeded(str){
  let h = 2166136261;
  for (const c of str) h = Math.imul(h ^ c.charCodeAt(0), 16777619);
  return () => { h = Math.imul(h ^ (h >>> 15), 2246822507); h = Math.imul(h ^ (h >>> 13), 3266489909); return ((h ^= h >>> 16) >>> 0) / 4294967296; };
}

/** Ser till att dagens uppdrag finns. Anropas när hangaren visas. */
export function ensureDaily(){
  const d = today();
  if (state.daily.date === d && state.daily.list?.length) return false;
  const rnd = seeded('ironfront-' + d + '-' + (state.profile?.name || ''));
  const pool = [...DAILY];
  const list = [];
  while (list.length < 3 && pool.length){
    const t = pool.splice(Math.floor(rnd() * pool.length), 1)[0];
    const n = t.n[Math.floor(rnd() * t.n.length)];
    list.push({ id: t.id, n, progress: 0, done: false });
  }
  state.daily = { date: d, list };
  save();
  return true;
}
export const dailyTemplate = id => DAILY.find(t => t.id === id);
export const dailyText = m => dailyTemplate(m.id).text(m.n);

function dailyProgress(on, amount = 1){
  if (state.level < 2) return;                     // efter träningen
  ensureDaily();
  let changed = false;
  for (const m of state.daily.list){
    const t = dailyTemplate(m.id);
    if (!t || m.done || t.on !== on) continue;
    m.progress = t.max ? Math.max(m.progress, amount) : m.progress + amount;
    changed = true;
    if (m.progress >= m.n){
      m.progress = m.n; m.done = true;
      grant({ ag: t.ag });
      const r = addXp(t.xp);
      state.counters.dailyDone++;
      bus.emit('toast', { text: `Dagligt uppdrag klart: ${t.text(m.n)} · +${t.xp} XP · +${t.ag} Ag`, kind: 'good' });
      if (r.up) bus.emit('toast', { text: `NIVÅ ${r.up.to}!`, kind: 'good' });
    }
  }
  if (changed){ save(); checkAchievements(); }
}

/* =========================================================
   INLOGGNINGSBONUS
   En belöning per dag man spelar. Obruten svit ger mer —
   dag 7 och därefter ger dessutom Platina.
   ========================================================= */
export function streakReward(day){ return { ag: 150 + 75 * Math.min(day, 7), au: day >= 3 ? 5 : 0, pl: day >= 7 ? 2 : 0 }; }

export function checkStreak(){
  if (state.level < 2) return null;
  const d = today();
  const s = state.streak;
  if (s.last === d) return null;
  s.days = s.last === yesterday() ? s.days + 1 : 1;
  s.best = Math.max(s.best || 0, s.days);
  s.last = d;
  const r = streakReward(s.days);
  grant(r);
  save();
  checkAchievements();
  return { days: s.days, reward: r };
}

/* =========================================================
   PRESTATIONER
   Varje prestation har ett villkor (test) och en belöning.
   De kontrolleras efter varje händelse som kan påverka dem.
   ========================================================= */
const ownedRobots = () => new Set(state.bays.filter(Boolean).map(b => b.tpl)).size;
export const ACHIEVEMENTS = [
  { id: 'first',     name: 'Första blodet',   text: 'Fäll din första fiende.',                     test: () => state.career.kills >= 1,       prog: () => [state.career.kills, 1],      reward: { pl: 1 } },
  { id: 'k500',      name: 'Skrotsamlare',    text: 'Fäll 500 fiender totalt.',                    test: () => state.career.kills >= 500,     prog: () => [state.career.kills, 500],    reward: { pl: 3 } },
  { id: 'k2500',     name: 'Tusentals',       text: 'Fäll 2 500 fiender totalt.',                  test: () => state.career.kills >= 2500,    prog: () => [state.career.kills, 2500],   reward: { pl: 8 } },
  { id: 'boss10',    name: 'Bossjägare',      text: 'Fäll 10 bossar.',                             test: () => state.career.bosses >= 10,     prog: () => [state.career.bosses, 10],    reward: { pl: 3 } },
  { id: 'boss50',    name: 'Bossmördare',     text: 'Fäll 50 bossar.',                             test: () => state.career.bosses >= 50,     prog: () => [state.career.bosses, 50],    reward: { pl: 8, paint: 'violet' } },
  { id: 'clean',     name: 'Oberörbar',       text: 'Fäll en boss utan att ta en enda träff under striden mot den.', test: () => state.counters.bossNoDamage >= 1, reward: { pl: 5 } },
  { id: 'elite20',   name: 'Elitjägare',      text: 'Fäll 20 elitfiender.',                        test: () => state.counters.eliteKills >= 20, prog: () => [state.counters.eliteKills, 20], reward: { pl: 4 } },
  { id: 'sector5',   name: 'Frontlinjen',     text: 'Rensa sektor 5.',                             test: () => state.sector >= 6,             prog: () => [Math.max(0, state.sector - 1), 5], reward: { pl: 5 } },
  { id: 'sector10',  name: 'Djupt in',        text: 'Rensa sektor 10.',                            test: () => state.sector >= 11,            prog: () => [Math.max(0, state.sector - 1), 10], reward: { pl: 10, paint: 'crimson' } },
  { id: 'story',     name: 'Arkitektens fall', text: 'Klara alla storykapitel.',                   test: () => state.story.done.length >= STORY_CHAPTERS.length, prog: () => [state.story.done.length, STORY_CHAPTERS.length], reward: { pl: 10 } },
  { id: 'weekly',    name: 'Veckans hjälte',  text: 'Klara en veckoutmaning.',                     test: () => !!state.weekly?.done, reward: { pl: 3 } },
  { id: 'surv15',    name: 'Överlevare',      text: 'Nå våg 15 i Överlevnad.',                     test: () => (state.records?.survival?.wave || 0) >= 15, prog: () => [state.records?.survival?.wave || 0, 15], reward: { pl: 5 } },
  { id: 'surv30',    name: 'Odödlig',         text: 'Nå våg 30 i Överlevnad.',                     test: () => (state.records?.survival?.wave || 0) >= 30, prog: () => [state.records?.survival?.wave || 0, 30], reward: { pl: 12, paint: 'ember' } },
  { id: 'coop',      name: 'Lagspelare',      text: 'Vinn en co-op-match.',                        test: () => state.counters.coopWins >= 1,  reward: { pl: 3 } },
  { id: 'events10',  name: 'Sabotör',         text: 'Klara 10 händelser.',                         test: () => state.counters.eventsDone >= 10, prog: () => [state.counters.eventsDone, 10], reward: { pl: 3 } },
  { id: 'robots5',   name: 'Flottchef',       text: 'Ha 3 olika robotar i hangaren samtidigt.',    test: () => ownedRobots() >= 3,            prog: () => [ownedRobots(), 3],           reward: { pl: 4 } },
  { id: 'weapons',   name: 'Vapensmed',       text: 'Äg 6 olika vapen.',                           test: () => state.ownedWeapons.length >= 6, prog: () => [state.ownedWeapons.length, 6], reward: { pl: 5 } },
  { id: 'paints',    name: 'Färgglad',        text: 'Äg 4 lackeringar.',                           test: () => state.ownedPaints.length >= 4, prog: () => [state.ownedPaints.length, 4], reward: { pl: 3 } },
  { id: 'daily20',   name: 'Pliktmedveten',   text: 'Klara 20 dagliga uppdrag.',                   test: () => state.counters.dailyDone >= 20, prog: () => [state.counters.dailyDone, 20], reward: { pl: 6 } },
  { id: 'streak7',   name: 'Trogen',          text: 'Spela 7 dagar i rad.',                        test: () => (state.streak.best || 0) >= 7, prog: () => [state.streak.days || 0, 7], reward: { pl: 6 } },
  { id: 'lvl10',     name: 'Stridspilot',     text: 'Nå nivå 10.',                                 test: () => state.level >= 10,             prog: () => [state.level, 10],            reward: { pl: 5 } },
  { id: 'lvl30',     name: 'Järnvarg',        text: 'Nå nivå 30.',                                 test: () => state.level >= 30,             prog: () => [state.level, 30],            reward: { pl: 20 } }
];

export function checkAchievements(){
  let got = 0;
  for (const a of ACHIEVEMENTS){
    if (state.achievements[a.id]) continue;
    let ok = false;
    try { ok = a.test(); } catch {}
    if (!ok) continue;
    state.achievements[a.id] = Date.now();
    const r = a.reward || {};
    grant({ ag: r.ag || 0, au: r.au || 0, pl: r.pl || 0 });
    if (r.paint && PAINTS[r.paint] && !state.ownedPaints.includes(r.paint)) state.ownedPaints.push(r.paint);
    bus.emit('achievement', a);
    bus.emit('toast', { text: `🏆 Prestation: ${a.name}` + (r.pl ? ` · +${r.pl} Pl` : '') + (r.paint ? ` · lackering ${PAINTS[r.paint].name}` : ''), kind: 'good' });
    got++;
  }
  if (got) save();
  return got;
}

/* =========================================================
   KOPPLING TILL STRIDEN
   ========================================================= */
export function initProgress(){
  bus.on('enemy:killed', e => {
    if (!e.mine) return;
    dailyProgress('kill');
    if (e.boss){
      dailyProgress('boss');
      if (e.noDamageBoss){ state.counters.bossNoDamage++; checkAchievements(); }
    }
    if (e.elite){ state.counters.eliteKills++; dailyProgress('elite'); }
  });
  bus.on('wave:cleared', () => dailyProgress('wave'));
  bus.on('event:end', e => { if (e?.success){ state.counters.eventsDone++; dailyProgress('event'); } });
  bus.on('pickup', () => { state.counters.pickups++; dailyProgress('pickup'); });
  bus.on('ability:used', () => { state.counters.abilities++; dailyProgress('ability'); });
  bus.on('battle:finished', ({ reason, won, stats }) => {
    if (stats.tutorial) { checkAchievements(); return; }
    if (won) dailyProgress('win');
    if (stats.mode === 'coop' && reason !== 'abandon'){
      dailyProgress('coop');
      if (won) state.counters.coopWins++;
    }
    if (stats.mode === 'survival') dailyProgress('survivalWave', stats.wave);
    checkAchievements();
    save(true);
  });
  bus.on('level:up', () => checkAchievements());
}
