/* =========================================================
   Små verktyg som resten av kodbasen vilar på.
   Inga beroenden — allt annat får importera härifrån.
   ========================================================= */

export const TAU = Math.PI * 2;

/* ---------- Loggning ----------
   Alla webbläsare och inbäddade vyer har inte hela console-objektet.
   En del previewfönster saknar t.ex. console.info helt, och då kraschar
   spelet på en rad som bara skulle skriva ut en hälsning. Därför går all
   loggning genom den här, som tar det som faktiskt finns — eller tiger. */
function pickLog(...names){
  const c = typeof console === 'object' && console ? console : null;
  if (!c) return () => {};
  for (const n of names){ if (typeof c[n] === 'function') return c[n].bind(c); }
  return () => {};
}
export const log = {
  info:  pickLog('info', 'log', 'debug'),
  warn:  pickLog('warn', 'log', 'info'),
  error: pickLog('error', 'warn', 'log')
};

export const clamp = (v, lo, hi) => v < lo ? lo : v > hi ? hi : v;
export const lerp  = (a, b, t) => a + (b - a) * t;
export const dist  = (x1, y1, x2, y2) => Math.hypot(x1 - x2, y1 - y2);
export const dist2 = (x1, y1, x2, y2) => { const dx = x1 - x2, dy = y1 - y2; return dx * dx + dy * dy; };
export const rand  = (a = 1, b = 0) => b + Math.random() * (a - b);
export const randi = (a, b = 0) => Math.floor(rand(a, b));
export const pick  = arr => arr[(Math.random() * arr.length) | 0];

/** Kortaste vinkelskillnaden mellan två riktningar (−π..π). */
export function angleDelta(from, to){
  let d = (to - from) % TAU;
  if (d > Math.PI) d -= TAU;
  if (d < -Math.PI) d += TAU;
  return d;
}

/** Rör sig mot en vinkel med högst `step` radianer. */
export function turnToward(from, to, step){
  const d = angleDelta(from, to);
  return from + clamp(d, -step, step);
}

/* ---------- Seedad slump ----------
   Samma sektor ska ge samma karta varje gång man spelar den.
   mulberry32 är liten, snabb och tillräckligt bra för terräng. */
export function mulberry32(seed){
  let a = seed >>> 0;
  return function(){
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
/** Gör en sträng till ett heltalsfrö. */
export function hashSeed(str){
  let h = 2166136261;
  for (let i = 0; i < str.length; i++){ h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}

/* ---------- Färg ---------- */
export function hexRgb(hex){
  const h = hex.replace('#', '');
  const n = parseInt(h.length === 3 ? h.split('').map(c => c + c).join('') : h, 16);
  return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
}
export function rgba(hex, a){
  const { r, g, b } = hexRgb(hex);
  return `rgba(${r},${g},${b},${a})`;
}
/** Ljusare (+) eller mörkare (−) variant av en hexfärg. amt = −1..1 */
export function shade(hex, amt){
  const { r, g, b } = hexRgb(hex);
  const f = v => Math.round(clamp(amt > 0 ? v + (255 - v) * amt : v * (1 + amt), 0, 255));
  return `rgb(${f(r)},${f(g)},${f(b)})`;
}
/** Blandar två hexfärger. */
export function mix(a, b, t){
  const A = hexRgb(a), B = hexRgb(b);
  return `rgb(${Math.round(lerp(A.r, B.r, t))},${Math.round(lerp(A.g, B.g, t))},${Math.round(lerp(A.b, B.b, t))})`;
}

/* ---------- Text ---------- */
export const fmt = n => Math.round(n).toLocaleString('sv-SE');
export function fmtTime(ms){
  const s = Math.floor(ms / 1000);
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}

/* ---------- DOM ---------- */
export const $  = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
export function el(tag, cls, html){
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (html != null) n.innerHTML = html;
  return n;
}
/** Skyddar mot att data hamnar i markup som kod. */
export const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

/* ---------- Händelsebuss ----------
   Låter strid, HUD och meny prata utan att importera varandra i cirkel. */
const listeners = new Map();
export const bus = {
  on(ev, fn){
    if (!listeners.has(ev)) listeners.set(ev, new Set());
    listeners.get(ev).add(fn);
    return () => listeners.get(ev).delete(fn);
  },
  emit(ev, payload){
    const set = listeners.get(ev);
    if (!set) return;
    for (const fn of set) { try { fn(payload); } catch (e) { log.error(`[bus:${ev}]`, e); } }
  }
};

/* ---------- Objektpool ----------
   Projektiler och partiklar skapas hundratals gånger per sekund.
   Att återanvända objekt istället för att allokera nya håller
   sopsamlaren borta, vilket syns direkt som jämnare bildfrekvens. */
export class Pool{
  constructor(factory, reset){ this.factory = factory; this.reset = reset; this.free = []; this.live = []; }
  spawn(init){
    const o = this.free.pop() || this.factory();
    this.reset(o, init);
    this.live.push(o);
    return o;
  }
  /** Går igenom alla levande objekt; returnerar fn false så återvinns objektet. */
  sweep(fn){
    for (let i = this.live.length - 1; i >= 0; i--){
      if (fn(this.live[i]) === false){
        this.free.push(this.live[i]);
        this.live.splice(i, 1);
      }
    }
  }
  clear(){ this.free.push(...this.live); this.live.length = 0; }
  get count(){ return this.live.length; }
}
