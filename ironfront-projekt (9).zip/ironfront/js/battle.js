/* =========================================================
   IRONFRONT — strid
   Hela spelloopen: rörelse, eldgivning, fiende-AI, vågor,
   händelser och belöningar. Allt som ändrar spelets tillstånd
   går genom update(); rendering läser bara.
   ========================================================= */
import {
  AMMO_FX, EVENTS, ECONOMY, DIFFICULTIES,
  enemyPoolFor, rangeMult, sectorLength, sectorName, sectorIntro,
  WEEKLY_MODS, WEEKLY_REWARD, WEEKLY_WAVES, COOP_WAVES, TRIALS, dailyTrial,
  TRAINING_ENEMY, TRAINING_BOSS, sectorStartWave, enemyLead, runXp, titleFor
} from './data.js';
import { buildArena, hitsObstacle, outOfBounds, lineOfSight, WORLD } from './arena.js';
import { buildPlayer, makeEnemy, makeBoss, waveScaling, abilityInfo } from './entities.js';
import { rollPerks, perkById } from './perks.js';
import { Fx } from './fx.js';
import { Input, pollPadEdges } from './input.js';
import { state, save, grant, makeSlot, addXp, completeTraining, levelProgress } from './state.js';
import { onNet, relay, endMatch, leaveLobby } from './net.js';
import { initRender, renderScene, resize, viewW, viewH } from './render.js';
import * as Audio from './audio.js';
import { bus, clamp, dist, rand, pick, TAU, turnToward, lerp } from './util.js';

export const Battle = {
  game: null,
  running: false,
  paused: false,
  _raf: 0,

  /**
   * Startar en utryckning.
   *   Battle.start(slot, sector)                                  → sektorläget
   *   Battle.start(slot, chapter.sector, { mode:'story', chapter }) → ett storykapitel
   */
  start(slot, sector, opts = {}){
    const mode = opts.mode || 'sectors';
    const chapter = mode === 'story' ? opts.chapter : null;
    const weekly = mode === 'weekly' ? opts.weekly : null;
    const coop = mode === 'coop' ? opts.coop : null;
    const survival = mode === 'survival';
    const trial = mode === 'trial' ? { ...TRIALS[opts.trial], daily: opts.trial === 'daily' ? dailyTrial() : null } : null;
    if (trial) sector = trial.sector;
    // Veckans regler slås ihop till ett enda objekt med multiplikatorer och flaggor
    const mods = { enemyCount: 1, enemyHp: 1, enemySpeed: 1, playerDmg: 1, playerHp: 1, agMult: 1, bossEvery: 5 };
    const modList = weekly ? weekly.mods : trial?.daily ? trial.daily.mods : [];
    if (trial?.bossEvery) mods.bossEvery = trial.bossEvery;
    for (const id of modList){
      const m = WEEKLY_MODS[id];
      for (const k of ['enemyCount','enemyHp','enemySpeed','playerDmg','playerHp','agMult']) if (m[k]) mods[k] *= m[k];
      if (m.bossEvery) mods.bossEvery = m.bossEvery;
      if (m.noRadar) mods.noRadar = true;
      if (m.noRepair) mods.noRepair = true;
    }
    const arena = buildArena(sector);
    const player = buildPlayer(slot);
    player.x = arena.spawn.x;
    player.y = arena.spawn.y;
    // Namn och titel syns över roboten
    player.tag = state.profile?.name || 'DU';
    player.rank = titleFor(state.level);
    if (mods.playerHp !== 1){ player.maxHp = Math.round(player.maxHp * mods.playerHp); player.hp = player.maxHp; }
    if (mods.playerDmg !== 1) player.mods.dmg *= mods.playerDmg;

    // Träningen: sektor 1 i sektorläget tills den genomförts en gång
    const tutorial = mode === 'sectors' && sector === 1 && !state.flags.battleTutDone;

    this.game = {
      arena, player, mode, chapter, weekly, mods, trial,
      camera: { x: 0, y: 0 },
      enemies: [], projectiles: [], pickups: [], markers: [],
      sector, waveInSector: 1,
      globalWave: chapter ? chapter.startWave : survival ? 1 : sectorStartWave(sector),
      // Överlevnad har inget slut — vågorna fortsätter tills roboten faller
      waveTotal: survival ? Infinity : trial ? trial.waves : chapter ? chapter.waves : weekly ? WEEKLY_WAVES : coop ? COOP_WAVES : sectorLength(sector),
      tut: tutorial ? { i: 0, t: 0, moved: 0, lx: player.x, ly: player.y,
                        reloaded: false, usedAbility: false, hold: true, basicDone: false,
                        flash: null, seen: {} } : null,
      phase: 'fight',              // fight | cleared | draft | done
      event: null, eventCooldown: 0,
      score: 0, combo: 1, comboTimer: 0, kills: 0,
      elapsed: 0, waveBreak: 0,
      perksTaken: [],
      bannerTimer: 0,
      _pattern: null
    };
    Fx.reset();
    this.paused = false;
    this.running = true;
    if (coop) setupCoop(this.game, coop, slot);

    resize();
    // I träningen kommer första vågen först när grunderna är avklarade.
    // En co-op-gäst skapar inga fiender alls — de kommer från värden.
    if (!this.game.tut && coop?.role !== 'guest') spawnWave(this.game);
    bus.emit('battle:started', this.game);
    if (this.game.tut) startTutorial(this.game);
    else if (chapter) story(this.game, `KAPITEL ${chapter.id} · ${chapter.title.toUpperCase()}`, chapter.brief);
    else if (trial) story(this.game, `ARENA · ${trial.name.toUpperCase()}`, trial.text +
      (trial.daily ? ' Regler: ' + trial.daily.mods.map(id => WEEKLY_MODS[id].name).join(' + ') + '.' : ''));
    else if (survival) story(this.game, 'ÖVERLEVNAD',
      'Vågorna tar aldrig slut. Hur långt kommer du? Boss var femte våg, fältuppgradering var tredje.');
    else if (coop) story(this.game, `CO-OP · SEKTOR ${sector}`,
      `${coop.players.length} robotar mot ${COOP_WAVES} vågor. Den som faller är tillbaka nästa våg — striden är förlorad först när hela laget ligger.`);
    else if (weekly) story(this.game, `VECKANS UTMANING · VECKA ${weekly.week}`,
      weekly.mods.map(id => WEEKLY_MODS[id].name + ': ' + WEEKLY_MODS[id].text).join(' '));
    else story(this.game, `SEKTOR ${sector} · ${sectorName(sector).toUpperCase()}`, sectorIntro(sector));

    Audio.unlock();
    Audio.startMusic();
    document.body.style.cursor = 'none';

    this._last = performance.now();
    cancelAnimationFrame(this._raf);
    this._raf = requestAnimationFrame(t => this.loop(t));
  },

  loop(now){
    if (!this.running) return;
    this._raf = requestAnimationFrame(t => this.loop(t));

    let dt = now - this._last;
    this._last = now;
    if (dt > 100) dt = 100;               // efter en flikväxling: hoppa inte fram
    this.game.fps = lerp(this.game.fps || 60, 1000 / Math.max(dt, 1), 0.08);

    if (this.game.coop?.role === 'guest'){
      // Gästen räknar inte ut striden — den visar värdens bild och skickar sin inmatning
      updateGuest(this.game, dt);
      renderScene(this.game);
      bus.emit('battle:tick', this.game);
      Input.endFrame();
      return;
    }
    // I co-op går striden vidare även när man har pausmenyn uppe
    if (!this.paused || this.game.coop){
      // Kort frys vid tunga träffar — slaget får tyngd
      if (Fx.hitStopLeft > 0){
        Fx.update(dt);
        renderScene(this.game);
        bus.emit('battle:tick', this.game);
        Input.endFrame();
        return;
      }
      update(this.game, dt);
      Audio.tickMusic(dt);
    }
    renderScene(this.game);
    bus.emit('battle:tick', this.game);
    Input.endFrame();
  },

  pause(){
    if (!this.running || this.paused) return;
    this.paused = true;
    document.body.style.cursor = '';
    bus.emit('battle:paused');
  },
  resume(){
    if (!this.running || !this.paused) return;
    this.paused = false;
    this._last = performance.now();
    document.body.style.cursor = 'none';
    bus.emit('battle:resumed');
  },
  abandon(){
    const g = this.game;
    if (g?.coop?.role === 'guest'){ leaveLobby(); teardownCoop(g); }
    finish(g, 'abandon');
  },

  stop(){
    this.running = false;
    cancelAnimationFrame(this._raf);
    document.body.style.cursor = '';
    Audio.stopMusic();
  },

  get alive(){ return this.running && this.game && this.game.player.hp > 0; }
};

export function bindBattleCanvas(canvas){
  initRender(canvas);
  Input.bind(canvas);
}

/* =========================================================
   UPPDATERING
   ========================================================= */
function update(g, dt){
  const p = g.player;
  g.elapsed += dt;

  Input.poll();
  pollPadEdges();

  if (Input.hit('pause')){ Battle.pause(); if (!g.coop) return; }

  updatePlayer(g, p, dt);
  if (g.allies) for (const al of g.allies){ updatePlayer(g, al, dt, remoteInput(al)); updateShieldHits(al, dt); }
  updateEnemies(g, dt);
  updateProjectiles(g, dt);
  updatePickups(g, dt);
  updateMarkers(g, dt);
  updateEvent(g, dt);
  updateWave(g, dt);
  updateCamera(g, dt);
  if (g.scanWave){ g.scanWave.r += dt * 2.4; if (g.scanWave.r > 2600) g.scanWave = null; }
  tickMarks(g, dt);
  if (Input.hit('ping')) placePing(g, g.player);
  if (g.tut) updateTutorial(g, dt);

  // Kombon rinner ut om man slutar träffa
  if (g.comboTimer > 0){
    g.comboTimer -= dt;
    if (g.comboTimer <= 0) g.combo = 1;
  }
  if (g.bannerTimer > 0){
    g.bannerTimer -= dt;
    if (g.bannerTimer <= 0) bus.emit('story:hide');
  }

  Fx.update(dt);
  updateShieldHits(p, dt);
  if (g.coop){ updateRevives(g, dt); coopHostTick(g, dt); }
}

/* ---------------------------------------------------------
   ÅTERUPPLIVNING (co-op)
   Stå intill en utslagen lagkamrat i tre sekunder så kommer
   den tillbaka med en tredjedel av livet — utan att vänta på
   nästa våg.
   --------------------------------------------------------- */
const REVIVE_MS = 3000;
function updateRevives(g, dt){
  if (g.coop.role !== 'host') return;
  for (const a of actors(g)){
    if (a.hp > 0) continue;
    const helper = actors(g).find(h => h !== a && h.hp > 0 && dist(h.x, h.y, a.x, a.y) < 90);
    if (helper){
      a.reviveT = (a.reviveT || 0) + dt;
      if (a.reviveT >= REVIVE_MS){
        a.reviveT = 0;
        a.hp = Math.round(a.maxHp * 0.35);
        a.invuln = 1500;
        Fx.light(a.x, a.y, 120, '#58c98a', 500);
        Audio.sfx('uiBig', { vol: .6 });
        g.coop.fx.push(['r', a.netId]);
        g.coop.fx.push(['s', 'ÅTERUPPLIVAD', `${helper.tag || 'En lagkamrat'} fick upp ${a.tag || 'dig'} igen.`]);
        if (a === g.player) bus.emit('toast', { text: 'Du är återupplivad!', kind: 'good' });
      }
    } else a.reviveT = Math.max(0, (a.reviveT || 0) - dt * 2);
  }
}

/* ---------------------------------------------------------
   INMATNING
   Spelarroboten läser sin inmatning via ett litet gränssnitt,
   inte direkt från tangentbordet. Den lokala spelaren använder
   tangentbord/mus/handkontroll; en lagkamrat i co-op använder
   det som senast kom över nätet. Samma robotlogik för båda.
   --------------------------------------------------------- */
const LOCAL_INPUT = {
  move: () => Input.move(),
  aim: (p, g) => Input.aim(p.x, p.y, g.camera),
  fire: () => Input.down('fire'),
  hit: a => Input.hit(a)
};
export function remoteInput(al){
  const s = al.net;
  return {
    move: () => { const len = Math.min(1, Math.hypot(s.mx, s.my)); return { x: s.mx, y: s.my, len }; },
    aim: () => s.aim,
    fire: () => s.fire,
    hit: a => { if (s.hits.has(a)){ s.hits.delete(a); return true; } return false; }
  };
}

/** Alla robotar på spelarsidan: du och eventuella lagkamrater. */
export function actors(g){ return g.allies ? [g.player, ...g.allies] : [g.player]; }
const living = g => actors(g).filter(a => a.hp > 0);

/* ---------------------------------------------------------
   SPELAREN
   --------------------------------------------------------- */
function updatePlayer(g, p, dt, inp = LOCAL_INPUT){
  const local = p === g.player;
  const f = dt / 16.67;
  if (p.hp <= 0) return;
  const x0 = p.x, y0 = p.y;

  if (p.invuln > 0) p.invuln -= dt;
  if (p.slowLeft > 0) p.slowLeft -= dt;

  // --- Rörelse ---
  const mv = inp.move();
  let speed = p.baseSpeed * p.mods.speed * (p.slowLeft > 0 ? 0.6 : 1) * (p.special?.kind === 'hunt' && p.special.active ? 1.6 : 1);

  if (p.dash?.active){
    p.dash.activeLeft -= dt;
    if (p.dash.activeLeft <= 0){ p.dash.active = false; p.dash.vulnLeft = p.dash.vulnDuration; }
    moveWith(g, p, p.dash.dirX * speed * p.dash.dashSpeed * f, p.dash.dirY * speed * p.dash.dashSpeed * f);
    Fx.spark(p.x, p.y, p.color, 2, 2);
  } else if (mv.len > 0.05){
    moveWith(g, p, mv.x * speed * f, mv.y * speed * f);
    p.moveAngle = Math.atan2(mv.y, mv.x);
    p.walk += 0.22 * f * (speed / 3.1);
  } else {
    p.walk = lerp(p.walk, Math.round(p.walk / Math.PI) * Math.PI, 0.1 * f);
  }

  if (p.dash && p.dash.cdLeft > 0) p.dash.cdLeft -= dt;
  if (p.dash && p.dash.vulnLeft > 0) p.dash.vulnLeft -= dt;

  p.vx = (p.x - x0) / Math.max(f, .001);
  p.vy = (p.y - y0) / Math.max(f, .001);

  // --- Sikte ---
  p.angle = inp.aim(p, g);

  // --- Förmåga ---
  if (inp.hit('ability')){
    const act = () => [p.scan?.active, p.overdrive?.active, p.dash?.active, p.shield?.active, p.special?.cdLeft, p.special?.active].join();
    const before = act();
    useAbility(g, p, inp);
    if (local && act() !== before) bus.emit('ability:used');
    if (g.tut && local) g.tut.usedAbility = true;
  }
  if (p.shield?.type === 'purple'){
    if (p.shield.active){
      p.shield.activeLeft -= dt;
      if (p.shield.activeLeft <= 0){ p.shield.active = false; p.shield.cdLeft = p.shield.cooldown; }
    } else if (p.shield.cdLeft > 0) p.shield.cdLeft -= dt;
  }
  if (p.special){
    const sp = p.special;
    if (sp.active){
      sp.activeLeft -= dt;
      if (sp.kind === 'repair') for (const a of actors(g))
        if (a.hp > 0 && dist(a.x, a.y, p.x, p.y) < sp.radius) healPlayer(g, a.maxHp * sp.heal * sp.power * dt / 1000, a);
      if (sp.kind === 'bastion' && p.shield && p.shield.type !== 'purple')
        p.shield.current = Math.min(p.shield.capacity, p.shield.current + p.shield.capacity * 0.25 * dt / 1000);
      if (sp.activeLeft <= 0){ sp.active = false; sp.cdLeft = sp.cooldown; }
    } else if (sp.cdLeft > 0) sp.cdLeft -= dt;
  }
  if (p.scan){
    if (p.scan.active){
      p.scan.activeLeft -= dt;
      if (p.scan.activeLeft <= 0){ p.scan.active = false; p.scan.cdLeft = p.scan.cooldown; }
    } else if (p.scan.cdLeft > 0) p.scan.cdLeft -= dt;
  }
  if (p.overdrive){
    if (p.overdrive.active){
      p.overdrive.activeLeft -= dt;
      if (p.overdrive.activeLeft <= 0){ p.overdrive.active = false; p.overdrive.cdLeft = p.overdrive.cooldown; }
    } else if (p.overdrive.cdLeft > 0) p.overdrive.cdLeft -= dt;
  }

  // --- Sköldåterladdning ---
  if (p.shield && (p.shield.type === 'blue' || p.shield.type === 'gold')){
    p.shield.sinceHit += dt;
    if (p.shield.sinceHit > p.shield.regenDelay && p.shield.current < p.shield.capacity){
      p.shield.current = Math.min(p.shield.capacity, p.shield.current + p.shield.regenRate * dt / 1000);
    }
  }

  // --- Eldgivning ---
  const firing = inp.fire();
  if (inp.hit('reload')){ manualReload(p); if (g.tut && local) g.tut.reloaded = true; }

  for (const grp of p.weaponGroups){
    if (grp.reloading){
      grp.reloadTimer -= dt;
      if (grp.reloadTimer <= 0){
        grp.reloading = false;
        grp.ammoLeft = grp.magSize;
        grp.freshMag = true;
      }
      continue;
    }
    for (const m of grp.mounts){
      if (m.cooldown > 0) m.cooldown -= dt;
      if (!firing || m.cooldown > 0) continue;
      if (grp.ammoLeft <= 0){
        grp.reloading = true;
        grp.reloadTimer = grp.reloadTime * p.mods.reload;
        Audio.sfx('reload', { vol: .7 });
        break;
      }
      fireMount(g, p, grp, m);
      m.cooldown = m.fireRate * p.mods.rate * (p.overdrive?.active ? p.overdrive.rateMult : 1) * (p.special?.kind === 'barrage' && p.special.active ? 0.6 : 1);
    }
  }
}

function moveWith(g, e, dx, dy){
  // Axlarna testas var för sig så att man glider längs en vägg
  // istället för att fastna i den.
  if (!hitsObstacle(g.arena.obstacles, e.x + dx, e.y, e.radius) && !outOfBounds(e.x + dx, e.y, e.radius)) e.x += dx;
  if (!hitsObstacle(g.arena.obstacles, e.x, e.y + dy, e.radius) && !outOfBounds(e.x, e.y + dy, e.radius)) e.y += dy;
}

function manualReload(p){
  let did = false;
  for (const grp of p.weaponGroups){
    if (!grp.reloading && grp.ammoLeft < grp.magSize){
      grp.reloading = true;
      grp.reloadTimer = grp.reloadTime * p.mods.reload;
      did = true;
    }
  }
  Audio.sfx(did ? 'reload' : 'dry', { vol: .8 });
}

function useAbility(g, p, inp = LOCAL_INPUT){
  if (p.shield?.type === 'purple' && !p.shield.active && p.shield.cdLeft <= 0){
    p.shield.active = true;
    p.shield.activeLeft = p.shield.duration;
    Audio.sfx('ability'); Fx.light(p.x, p.y, 160, '#b07af0', 300);
    return;
  }
  if (p.dash && !p.dash.active && p.dash.cdLeft <= 0){
    const mv = inp.move();
    const a = mv.len > 0.1 ? Math.atan2(mv.y, mv.x) : p.angle;
    p.dash.dirX = Math.cos(a); p.dash.dirY = Math.sin(a);
    p.dash.active = true; p.dash.activeLeft = p.dash.duration;
    p.dash.cdLeft = p.dash.cooldown;
    Audio.sfx('ability', { pitch: 1.3 });
    return;
  }
  if (p.scan && !p.scan.active && p.scan.cdLeft <= 0){
    p.scan.active = true;
    p.scan.activeLeft = p.scan.duration;
    g.scanWave = { x: p.x, y: p.y, r: 0 };           // pulsringen som sveper ut över kartan
    Audio.sfx('ability', { pitch: 1.6 });
    Fx.light(p.x, p.y, 220, '#8fd3e6', 500);
    return;
  }
  if (p.special && !p.special.active && p.special.cdLeft <= 0){
    useSpecial(g, p, p.special);
    return;
  }
  if (p.overdrive && !p.overdrive.active && p.overdrive.cdLeft <= 0){
    p.overdrive.active = true;
    p.overdrive.activeLeft = p.overdrive.duration;
    Audio.sfx('ability', { pitch: .8 });
    Fx.light(p.x, p.y, 140, '#ffd964', 400);
  }
}

/* ---------------------------------------------------------
   ELDGIVNING
   --------------------------------------------------------- */
function fireMount(g, p, grp, m){
  const fx = AMMO_FX[grp.kind];
  const spread = (m.spread || 0) * (Math.PI / 180);
  const baseAngle = p.angle + rand(spread, -spread) * 0.5;

  // Vapnet sitter en bit ut från centrum
  const ox = Math.cos(p.angle + Math.PI / 2) * (m.offset || 0);
  const oy = Math.sin(p.angle + Math.PI / 2) * (m.offset || 0);
  const mx = p.x + ox + Math.cos(p.angle) * p.radius * 1.2;
  const my = p.y + oy + Math.sin(p.angle) * p.radius * 1.2;

  let dmg = m.dmg * p.mods.dmg * (p.overdrive?.active ? p.overdrive.dmgMult : 1) * (p.special?.kind === 'hunt' && p.special.active ? 1.3 : 1);
  if (grp.freshMag && p.mods.firstShot > 0){ dmg *= 1 + p.mods.firstShot; grp.freshMag = false; }
  if (p.mods.lowHpDmg > 0) dmg *= 1 + p.mods.lowHpDmg * (1 - p.hpPct);

  const pellets = grp.kind === 'burst' ? 3 : 1;
  for (let i = 0; i < pellets; i++){
    const a = baseAngle + (pellets > 1 ? (i - 1) * 0.13 : 0);
    shoot(g, {
      x: mx, y: my, angle: a, dmg, ammo: grp.ammo, kind: grp.kind,
      range: grp.range, fromPlayer: true, mods: p.mods, owner: p
    });
  }

  if (!(p.special?.kind === 'barrage' && p.special.active)) grp.ammoLeft--;   // spärreld: ingen ammo går åt
  p.stats.shots += pellets;
  Fx.muzzle(mx, my, p.angle, fx.color, grp.kind === 'shell' ? 1.5 : 1);
  Fx.casing(mx, my, p.angle);
  const local = p === g.player;
  if (local) Fx.shake(grp.kind === 'shell' ? 2.4 : 0.5);
  Audio.sfx(fx.sfx, { vol: local ? .9 : .35, pan: clamp((p.x - g.camera.x - viewW() / 2) / 600, -1, 1) });

  if (grp.ammoLeft <= 0){
    grp.reloading = true;
    grp.reloadTimer = grp.reloadTime * p.mods.reload;
    Audio.sfx('reload', { vol: .7 });
  }
}

function shoot(g, o){
  const fx = AMMO_FX[o.kind];
  const speed = o.speed || fx.speed;
  g.projectiles.push({
    x: o.x, y: o.y,
    vx: Math.cos(o.angle) * speed, vy: Math.sin(o.angle) * speed,
    dmg: o.dmg, ammo: o.ammo, kind: o.kind, range: o.range || 'balanced',
    fromPlayer: !!o.fromPlayer,
    color: o.fromPlayer ? fx.color : fx.hostile,
    size: fx.size, trail: fx.trail, light: fx.light,
    life: o.life || 2200, traveled: 0,
    homing: !!o.homing, target: null, speed,
    pierceLeft: o.fromPlayer ? (o.mods?.pierce || 0) : 0,
    ricochetLeft: o.fromPlayer ? (o.mods?.ricochet || 0) : 0,
    explode: o.fromPlayer ? (o.mods?.explode || 0) : (o.explode || 0),
    crit: o.fromPlayer && o.mods ? Math.random() < o.mods.crit : false,
    mods: o.mods || null, owner: o.owner || null,
    hitList: null
  });
}

/* ---------------------------------------------------------
   PROJEKTILER
   --------------------------------------------------------- */
function updateProjectiles(g, dt){
  const f = dt / 16.67;
  const p = g.player;

  for (let i = g.projectiles.length - 1; i >= 0; i--){
    const pr = g.projectiles[i];
    pr.life -= dt;
    if (pr.life <= 0){ g.projectiles.splice(i, 1); continue; }

    // Missiler söker mål
    if (pr.homing){
      if (!pr.target || pr.target.hp <= 0){
        pr.target = pr.fromPlayer ? nearestEnemy(g, pr.x, pr.y) : nearestActor(g, pr.x, pr.y);
      }
      if (pr.target){
        const want = Math.atan2(pr.target.y - pr.y, pr.target.x - pr.x);
        const cur = Math.atan2(pr.vy, pr.vx);
        const a = turnToward(cur, want, 0.055 * f);
        pr.vx = Math.cos(a) * pr.speed;
        pr.vy = Math.sin(a) * pr.speed;
      }
      if (Math.random() < 0.4) Fx.smoke(pr.x, pr.y, 1, '#3a3438', 4);
    }

    const stepX = pr.vx * f, stepY = pr.vy * f;
    pr.x += stepX; pr.y += stepY;
    pr.traveled += Math.hypot(stepX, stepY);

    // Terräng
    const hit = hitsObstacle(g.arena.obstacles, pr.x, pr.y, pr.size);
    if (hit){
      if (hit.type === 'crate' && pr.fromPlayer){
        hit.hp -= pr.dmg;
        Fx.spark(pr.x, pr.y, '#c9a25e', 5, 3);
        if (hit.hp <= 0) breakCrate(g, hit);
      }
      impact(g, pr, pr.x, pr.y);
      g.projectiles.splice(i, 1);
      continue;
    }
    if (outOfBounds(pr.x, pr.y, 0)){
      impact(g, pr, pr.x, pr.y);
      g.projectiles.splice(i, 1);
      continue;
    }

    // Träff på enheter
    if (pr.fromPlayer){
      let removed = false;
      for (const en of g.enemies){
        if (en.hp <= 0) continue;
        if (pr.hitList?.includes(en)) continue;
        if (dist(pr.x, pr.y, en.x, en.y) > en.radius + pr.size) continue;

        const mult = rangeMult(pr.range, pr.traveled);
        let dmg = pr.dmg * mult;
        if (pr.mods){
          if (pr.mods.closeDmg && pr.traveled < 300) dmg *= 1 + pr.mods.closeDmg;
          if (pr.mods.farDmg && pr.traveled > 500) dmg *= 1 + pr.mods.farDmg;
        }
        if (pr.crit) dmg *= pr.mods?.critMult || 2.2;
        const own = pr.owner || p;
        const scanner = actors(g).find(a => a.scan?.active);
        if (scanner) dmg *= 1 + scanner.scan.dmgBonus;   // märkt av sensorpulsen

        en.lastHitBy = own; en.lastHitKind = pr.kind;
        damageEnemy(g, en, dmg, pr.ammo, pr.crit);
        own.stats.hits++;
        own.stats.damage += dmg;

        if (pr.mods?.lifesteal) healPlayer(g, dmg * pr.mods.lifesteal, own);
        if (pr.mods?.slowOnHit) en.slowLeft = 1400;
        if (pr.explode) explode(g, pr.x, pr.y, 70, dmg * 0.45, true);

        impact(g, pr, pr.x, pr.y, en);

        if (pr.pierceLeft > 0){
          pr.pierceLeft--;
          pr.hitList = pr.hitList || [];
          pr.hitList.push(en);
        } else if (pr.ricochetLeft > 0){
          const next = nearestEnemy(g, pr.x, pr.y, en);
          if (next){
            pr.ricochetLeft--;
            pr.hitList = pr.hitList || [];
            pr.hitList.push(en);
            const a = Math.atan2(next.y - pr.y, next.x - pr.x);
            pr.vx = Math.cos(a) * pr.speed;
            pr.vy = Math.sin(a) * pr.speed;
            pr.life = Math.max(pr.life, 700);
          } else { g.projectiles.splice(i, 1); removed = true; }
        } else { g.projectiles.splice(i, 1); removed = true; }
        break;
      }
      if (removed) continue;
    } else {
      const hit = actors(g).find(a => a.hp > 0 && dist(pr.x, pr.y, a.x, a.y) < a.radius + pr.size);
      if (hit){
        damagePlayer(g, pr.dmg * rangeMult(pr.range, pr.traveled), pr.ammo, Math.atan2(pr.y - hit.y, pr.x - hit.x), hit);
        if (pr.explode) explode(g, pr.x, pr.y, 80, pr.dmg * 0.4, false);
        impact(g, pr, pr.x, pr.y, hit);
        g.projectiles.splice(i, 1);
      }
    }
  }
}

function impact(g, pr, x, y, target){
  const fx = AMMO_FX[pr.kind];
  Fx.spark(x, y, pr.color, pr.kind === 'shell' ? 9 : 5, pr.kind === 'shell' ? 5 : 3.2,
           Math.PI, Math.atan2(-pr.vy, -pr.vx));
  Fx.light(x, y, fx.light * 1.4, pr.color, 110);
  if (pr.kind === 'shell' || pr.kind === 'missile'){
    Fx.explosion(x, y, pr.kind === 'missile' ? 0.8 : 0.6, pr.color);
    Audio.sfx('explosion', { vol: .5 });
  } else {
    Audio.sfx('hit', { vol: .45 });
  }
}

function explode(g, x, y, radius, dmg, fromPlayer){
  Fx.explosion(x, y, radius / 90, '#ff9a4c');
  if (fromPlayer){
    for (const en of g.enemies){
      if (en.hp <= 0) continue;
      const d = dist(x, y, en.x, en.y);
      if (d < radius + en.radius) damageEnemy(g, en, dmg * (1 - d / (radius + en.radius)), 'normal', false);
    }
  } else {
    for (const a of actors(g)){
      if (a.hp <= 0) continue;
      const d = dist(x, y, a.x, a.y);
      if (d < radius + a.radius)
        damagePlayer(g, dmg * (1 - d / (radius + a.radius)), 'normal', Math.atan2(a.y - y, a.x - x), a);
    }
  }
}

/* ---------------------------------------------------------
   SKADA
   --------------------------------------------------------- */
function damageEnemy(g, en, dmg, ammoType, crit){
  en.sinceHit = 0;
  en.cloak = false;
  // Blå sköld stoppar vanlig ammunition men släpper igenom specialvapen.
  // Gyllene sköld stoppar allt tills den är slut.
  if (en.shield){
    const s = en.shield;
    if (s.type === 'purple' && s.active){
      Fx.spark(en.x, en.y, '#b07af0', 4, 2);
      Audio.sfx('hitShield', { vol: .4 });
      return;
    }
    const blocks = s.type === 'gold' || (s.type === 'blue' && ammoType === 'normal');
    if (blocks && s.current > 0){
      const used = Math.min(s.current, dmg);
      s.current -= used;
      dmg -= used;
      s.sinceHit = 0;
      en.shieldHits = en.shieldHits || [];
      en.shieldHits.push({ angle: Math.atan2(g.player.y - en.y, g.player.x - en.x) + Math.PI, life: 380, max: 380 });
      Audio.sfx('hitShield', { vol: .35 });
      if (dmg <= 0){
        Fx.number(en.x, en.y - en.radius, Math.round(used), '#7fd8f0');
        return;
      }
    }
  }

  en.hp -= dmg;
  Fx.number(en.x, en.y - en.radius - 6, Math.round(dmg), crit ? '#ff5a1e' : '#ffd9a8', crit);
  if (crit){ Fx.shake(2); Fx.hitStop(28); }

  if (en.hp <= 0) killEnemy(g, en);
}

function killEnemy(g, en){
  const p = g.player;
  en.hp = 0;

  Fx.explosion(en.x, en.y, en.isBoss ? 3.2 : 1, en.color);
  Audio.sfx(en.isBoss ? 'explosion' : 'kill', { vol: en.isBoss ? 1 : .6 });
  if (g.coop) g.coop.fx.push(['x', Math.round(en.x), Math.round(en.y), en.isBoss ? 1 : 0, en.color, en.name, en.lastHitBy?.netId || null, en.elite || 0]);
  // Bossmätaren ska försvinna direkt när bossen dör — inte först när nästa våg börjar
  if (en.isBoss && !g.enemies.some(e => e !== en && e.isBoss && e.hp > 0)) bus.emit('boss:end');
  if (en.isBoss){ Fx.hitStop(220); Fx.screenFlash(0.8); Fx.shake(26); }

  g.kills++;
  p.stats.kills++;
  // Uppdrag och prestationer lyssnar på det här (bara dina egna fällningar räknas)
  bus.emit('enemy:killed', { boss: !!en.isBoss, elite: en.elite || null, mine: !en.lastHitBy || en.lastHitBy === p,
    kind: en.lastHitKind || null, noDamageBoss: en.isBoss && !g.bossHurt, mode: g.mode, miniboss: !!en.miniboss });
  if (en.elite === 'explosiv') explode(g, en.x, en.y, 120, en.dmg * 2.2, false);
  if (en.elite){ grant({ ag: 60 }); g.score += 400; }
  if (en.miniboss){ grant({ ag: 250, au: 3 }); bus.emit('toast', { text: `${en.name} fälld · +250 Ag · +3 Au`, kind: 'good' }); }
  g.combo = Math.min(9, g.combo + 1);
  g.comboTimer = 3200;
  g.score += Math.round(en.score * g.combo * p.mods.scoreMult);

  if (p.mods.shieldOnKill && p.shield && p.shield.type !== 'purple'){
    p.shield.current = Math.min(p.shield.capacity, p.shield.current + p.mods.shieldOnKill);
  }

  bus.emit('killfeed', { name: en.name, boss: !!en.isBoss });

  // Fienden lämnar ibland något användbart efter sig
  const roll = Math.random();
  if (en.isBoss){
    dropPickup(g, en.x, en.y, 'repair');
    dropPickup(g, en.x + 40, en.y, 'shield');
  } else if (roll < 0.10) dropPickup(g, en.x, en.y, 'repair');
  else if (roll < 0.22) dropPickup(g, en.x, en.y, 'ammo');

  const i = g.enemies.indexOf(en);
  if (i >= 0) g.enemies.splice(i, 1);
}

function damagePlayer(g, dmg, ammoType, hitAngle, target){
  const p = target || g.player;
  const local = p === g.player;
  if (p.hp <= 0) return;
  if (p.special?.kind === 'bastion' && p.special.active) dmg *= 1 - p.special.reduce;
  if (p.invuln > 0 || p.dash?.active) return;

  const diff = DIFFICULTIES[state.settings.difficulty] || DIFFICULTIES.soldat;
  dmg *= p.dash?.vulnLeft > 0 ? 1.35 : 1;

  if (p.shield){
    const s = p.shield;
    if (s.type === 'purple' && s.active){
      Fx.spark(p.x + Math.cos(hitAngle) * p.radius, p.y + Math.sin(hitAngle) * p.radius, '#b07af0', 5, 3);
      Audio.sfx('hitShield');
      return;
    }
    const blocks = s.type === 'gold' || (s.type === 'blue' && ammoType === 'normal');
    if (blocks && s.current > 0){
      const used = Math.min(s.current, dmg);
      s.current -= used; dmg -= used; s.sinceHit = 0;
      p.shieldHits.push({ angle: hitAngle, life: 420, max: 420 });
      if (local){ Audio.sfx('hitShield', { vol: .6 }); Fx.shake(1.5); }
      if (dmg <= 0) return;
    }
  }

  p.hp -= dmg;
  p.tookDamage = true;
  p.stats.taken += dmg;

  // Reaktivt pansar slår tillbaka
  if (p.mods.thorns > 0){
    const near = nearestEnemy(g, p.x, p.y);
    if (near && dist(near.x, near.y, p.x, p.y) < 420) damageEnemy(g, near, dmg * p.mods.thorns, 'normal', false);
  }

  Fx.spark(p.x + Math.cos(hitAngle) * p.radius, p.y + Math.sin(hitAngle) * p.radius, '#ff7a4c', 6, 3.4);
  if (local){
    g.bossHurt = true;
    // Skadeindikator: en röd båge vid skärmkanten åt det håll skottet kom ifrån
    (g.hitMarks || (g.hitMarks = [])).push({ a: hitAngle, t: 900 });
    Fx.shake(3 + Math.min(8, dmg / 120));
    Audio.sfx('hurt', { vol: clamp(dmg / 400, .3, 1) });
    bus.emit('player:hurt', clamp(dmg / (p.maxHp * 0.22), 0.15, 1));
  }

  if (p.hp <= 0){
    if (p.mods.lastStand && !p.mods.usedLastStand){
      p.mods.usedLastStand = true;
      p.hp = Math.max(1, p.maxHp * 0.25);
      p.invuln = 1800;
      if (local){ Fx.screenFlash(1); Fx.shake(20); Audio.sfx('uiBig'); bus.emit('toast', { text: 'SISTA LINJEN HÖLL', kind: 'good' }); }
      return;
    }
    p.hp = 0;
    Fx.explosion(p.x, p.y, 3, p.color);
    if (local) Fx.screenFlash(1);
    // Co-op: den som faller är ute tills nästa våg. Striden är förlorad
    // först när hela laget ligger.
    if (g.coop){
      if (!living(g).length) finish(g, 'dead');
      else if (local) bus.emit('toast', { text: 'Du är utslagen — du återvänder nästa våg', kind: 'bad' });
      else bus.emit('toast', { text: `${p.tag || 'Lagkamrat'} är utslagen`, kind: 'bad' });
      return;
    }
    finish(g, 'dead');
  }
}

function healPlayer(g, amount, target){
  const p = target || g.player;
  p.hp = Math.min(p.maxHp, p.hp + amount);
}

function updateShieldHits(p, dt){
  for (let i = p.shieldHits.length - 1; i >= 0; i--){
    p.shieldHits[i].life -= dt;
    if (p.shieldHits[i].life <= 0) p.shieldHits.splice(i, 1);
  }
}

/* ---------------------------------------------------------
   FIENDE-AI
   --------------------------------------------------------- */
function updateEnemies(g, dt){
  const f = dt / 16.67;

  for (const en of g.enemies){
    if (en.hp <= 0) continue;
    // Varje fiende går på närmaste levande robot — i co-op sprids trycket
    const p = g.allies ? (nearestActor(g, en.x, en.y) || g.player) : g.player;
    if (en.healer || en.stealth || en.caster) enemyTraits(g, en, dt, p);
    if (en.slowLeft > 0) en.slowLeft -= dt;

    // Sköld på fiender laddar också om
    if (en.shield && (en.shield.type === 'blue' || en.shield.type === 'gold')){
      en.shield.sinceHit += dt;
      if (en.shield.sinceHit > en.shield.regenDelay)
        en.shield.current = Math.min(en.shield.capacity, en.shield.current + en.shield.regenRate * dt / 1000);
    }
    if (en.shieldHits?.length){
      for (let i = en.shieldHits.length - 1; i >= 0; i--){
        en.shieldHits[i].life -= dt;
        if (en.shieldHits[i].life <= 0) en.shieldHits.splice(i, 1);
      }
    }

    const d = dist(en.x, en.y, p.x, p.y);
    const toPlayer = Math.atan2(p.y - en.y, p.x - en.x);
    en.angle = turnToward(en.angle, toPlayer, (en.dumb ? 0.035 : 0.09) * f);

    const sees = d < en.range * 1.4 && lineOfSight(g.arena.obstacles, en.x, en.y, p.x, p.y);
    const speed = en.speed * (en.slowLeft > 0 ? 0.65 : 1) * (g.mods?.enemySpeed || 1);

    // --- Förflyttning ---
    let want = toPlayer;
    if (en.suicide){
      want = toPlayer;                                  // sprängare går rakt på
    } else if (!sees || d > en.range * 0.85){
      want = toPlayer;                                  // närma sig tills skjutavstånd
    } else if (en.dumb){
      want = toPlayer;                                  // träningsfiende: går fram, sedan står den still
      if (d <= en.range * 0.6) en.hold = true;
    } else if (d < en.range * 0.45){
      want = toPlayer + Math.PI;                        // backa undan
    } else {
      // Sidoförflyttning: fienden står inte still och blir skjuten
      if (!en.strafe){ en.strafe = 1; en.strafeTimer = 1200; }   // skydd för fiender som saknar fälten
      en.strafeTimer -= dt;
      if (en.strafeTimer <= 0){ en.strafe *= -1; en.strafeTimer = 1200 + Math.random() * 1800; }
      want = toPlayer + en.strafe * Math.PI / 2;
    }

    if (!Number.isFinite(want)) want = toPlayer;   // en trasig riktning får aldrig flytta fienden till NaN
    const bx = en.hold ? 0 : Math.cos(want) * speed * f, by = en.hold ? 0 : Math.sin(want) * speed * f;
    const before = { x: en.x, y: en.y };
    moveWith(g, en, bx, by);
    if (en.hold){ en.hold = false; }
    else if (Math.abs(en.x - before.x) + Math.abs(en.y - before.y) < 0.05 && !en.suicide){
      // Fast mot ett hinder — prova att glida runt det
      const side = want + (en.strafe > 0 ? 1 : -1) * 1.1;
      moveWith(g, en, Math.cos(side) * speed * f, Math.sin(side) * speed * f);
    }
    en.moveAngle = want;
    en.walk += 0.2 * f * speed;

    // Bossen har egen eldgivning, varningar och specialattacker
    if (en.isBoss){ updateBoss(g, en, dt, d, toPlayer); continue; }

    // --- Sprängare detonerar ---
    if (en.suicide){
      if (d < en.radius + p.radius + 16){
        explode(g, en.x, en.y, 110, en.dmg, false);
        Audio.sfx('explosion');
        killEnemy(g, en);
      } else if (d < 190){
        // Blinkar snabbare ju närmare den kommer
        if (Math.random() < 0.3) Fx.light(en.x, en.y, 50, '#ff3b2f', 120);
      }
      continue;
    }

    // --- Eldgivning ---
    if (en.reloading){
      en.reloadTimer -= dt;
      if (en.reloadTimer <= 0){ en.reloading = false; en.ammoLeft = en.magSize; }
      continue;
    }
    en.cooldown -= dt;

    if (en.tellLeft > 0){
      en.tellLeft -= dt;
      if (en.tellLeft <= 0) enemyFire(g, en, toPlayer, d, p);
      continue;
    }

    if (sees && d < en.range && en.cooldown <= 0){
      if (en.telegraph > 0){
        en.tellLeft = en.telegraph;
        en.tellTotal = en.telegraph;
        if (en.mortar) g.markers.push({ x: p.x, y: p.y, r: 90, left: en.telegraph, total: en.telegraph, owner: en });
        Audio.sfx('alarm', { vol: .25 });
      } else {
        enemyFire(g, en, toPlayer, d, p);
      }
    }
  }
}

function enemyFire(g, en, toPlayer, d, target){
  const p = target || g.player;
  const fx = AMMO_FX[en.kind];

  if (en.mortar){
    // Artilleriet slår ner där markören står — spelaren hann se den
    const mk = g.markers.find(m => m.owner === en);
    const tx = mk ? mk.x : p.x, ty = mk ? mk.y : p.y;
    if (mk) mk.left = 0;
    explode(g, tx, ty, 100, en.dmg, false);
    Audio.sfx('explosion', { vol: .8 });
  } else {
    // Prediktion: träningsfiender skjuter dit du ÄR, senare fiender dit du
    // är på väg — mer ju längre in i kampanjen man kommer.
    const diffLead = (DIFFICULTIES[state.settings.difficulty]?.enemyDmg || 1) > 1.2 ? 0.05 : 0;
    const lead = en.dumb ? 0 : enemyLead(g.sector) + diffLead;
    const a = Math.atan2(p.y - en.y + (p.vy || 0) * lead * d, p.x - en.x + (p.vx || 0) * lead * d);
    const spread = en.dumb ? 0.2 : 0.08;
    shoot(g, {
      x: en.x + Math.cos(en.angle) * en.radius,
      y: en.y + Math.sin(en.angle) * en.radius,
      angle: a + rand(spread, -spread),
      dmg: en.dmg, ammo: en.ammo, kind: en.kind, fromPlayer: false,
      homing: en.kind === 'missile', life: 2600
    });
    Fx.muzzle(en.x + Math.cos(en.angle) * en.radius, en.y + Math.sin(en.angle) * en.radius, en.angle, fx.hostile, .7);
    Audio.sfx(fx.sfx, { vol: .35, pan: clamp((en.x - g.camera.x - viewW() / 2) / 700, -1, 1) });
  }

  en.ammoLeft--;
  en.cooldown = en.fireRate;
  if (en.ammoLeft <= 0){ en.reloading = true; en.reloadTimer = en.reloadTime; }
}

/* ---------------------------------------------------------
   BOSSFASER
   Varje boss har tre faser. Vid 66 % liv kallar den på
   förstärkning, vid 33 % går den bärsärk: snabbare, tätare
   eld och dubbla specialattacker. Övergången är en kort
   paus med en tryckvåg — en tydlig signal att något ändras.
   --------------------------------------------------------- */
const BOSS_PHASES = [
  null,
  null,
  { at: 0.66, title: 'FAS 2 — FÖRSTÄRKNING', text: 'Bossen kallar in förstärkning. Rensa undan dem innan de omringar dig.' },
  { at: 0.33, title: 'FAS 3 — BÄRSÄRK', text: 'Bossen är skadad och går bärsärk: snabbare, tätare eld, dubbla specialattacker.' }
];

function checkBossPhase(g, en){
  if (en.training && en.phase >= 2) return;          // träningsbossen går aldrig bärsärk
  const next = BOSS_PHASES[en.phase + 1];
  if (!next || en.hp / en.maxHp > next.at) return;
  en.phase++;
  en.staggerLeft = 900;
  en.tellLeft = 0;
  Fx.shake(18); Fx.screenFlash(0.5);
  Fx.explosion(en.x, en.y, 1.6, en.color);
  Audio.sfx('alarm', { vol: .8 });
  // Tryckvåg: knuffar bort spelaren om den står för nära
  const p = g.player, d = dist(p.x, p.y, en.x, en.y);
  if (d < 260 && d > 0){ p.x += (p.x - en.x) / d * 90; p.y += (p.y - en.y) / d * 90; }

  if (en.phase === 2){
    const sc = waveScaling(g.globalWave);
    const n = en.training ? 2 : en.isFinale ? 4 : 3;
    for (let i = 0; i < n; i++){
      const a = TAU * i / n;
      g.enemies.push(tuneEnemy(g, makeEnemy(pick(enemyPoolFor(g.globalWave)),
        en.x + Math.cos(a) * 140, en.y + Math.sin(a) * 140, sc.hp * 0.7, sc.dmg)));
    }
    en.specialCooldown *= 0.85;
  } else if (en.phase === 3){
    en.enraged = true;
    en.speed = en.baseSpeed * 1.35;
    en.fireRate *= 0.7;
    en.specialCooldown *= 0.7;
  }
  story(g, next.title, next.text);
  bus.emit('boss:phase', { phase: en.phase, boss: en });
}

function updateBoss(g, en, dt, d, toPlayer){
  checkBossPhase(g, en);
  if (en.staggerLeft > 0){ en.staggerLeft -= dt; return; }
  // Pulssköld som slås på och av
  if (en.shield?.type === 'purple'){
    const s = en.shield;
    if (s.active){
      s.activeLeft -= dt;
      if (s.activeLeft <= 0){ s.active = false; s.cdLeft = s.cooldown; }
    } else {
      s.cdLeft -= dt;
      if (s.cdLeft <= 0){ s.active = true; s.activeLeft = s.duration; }
    }
  }

  // Varning pågår: bossen laddar upp och kan inte göra något annat
  if (en.tellLeft > 0){
    en.tellLeft -= dt;
    if (en.tellLeft <= 0){
      bossSpecial(g, en, toPlayer);
      // Bärsärk: en andra salva, lite förskjuten
      if (en.enraged) bossSpecial(g, en, toPlayer + 0.18);
    }
    return;
  }

  en.specialTimer -= dt;
  if (en.specialTimer <= 0){
    en.specialTimer = en.specialCooldown;
    en.tellLeft = en.tellTotal;
    Audio.sfx('alarm', { vol: .5 });
    return;
  }

  // Vanlig eldgivning mellan specialattackerna
  if (en.reloading){
    en.reloadTimer -= dt;
    if (en.reloadTimer <= 0){ en.reloading = false; en.ammoLeft = en.magSize; }
    return;
  }
  en.cooldown -= dt;
  if (d < en.range && en.cooldown <= 0) enemyFire(g, en, toPlayer, d, g.allies ? nearestActor(g, en.x, en.y) : g.player);
}

function bossSpecial(g, en, toPlayer){
  const fx = AMMO_FX[en.kind];
  Fx.shake(9);
  Audio.sfx('explosion', { vol: .7 });

  if (en.archetype === 'sentinel'){
    for (let i = 0; i < 16; i++){
      const a = TAU * (i / 16);
      shoot(g, { x: en.x, y: en.y, angle: a, dmg: en.dmg * 0.6, ammo: 'special', kind: 'slug', fromPlayer: false, speed: 8, life: 1600 });
    }
  } else if (en.archetype === 'warlord'){
    for (let i = 0; i < 5; i++){
      const a = toPlayer + (i - 2) * 0.22;
      shoot(g, { x: en.x, y: en.y, angle: a, dmg: en.dmg * 0.8, ammo: 'special', kind: 'shell', fromPlayer: false, speed: 9, life: 1500, explode: 1 });
    }
  } else if (en.archetype === 'reaper'){
    for (let i = 0; i < 11; i++){
      const a = toPlayer + (i - 5) * 0.13;
      shoot(g, { x: en.x, y: en.y, angle: a, dmg: en.dmg * 0.42, ammo: 'special', kind: 'laser', fromPlayer: false, speed: 15, life: 1200 });
    }
  } else {
    for (let i = 0; i < 5; i++){
      const a = toPlayer + (i - 2) * 0.3;
      shoot(g, { x: en.x, y: en.y, angle: a, dmg: en.dmg * 0.5, ammo: 'special', kind: 'missile', fromPlayer: false, homing: true, life: 3000 });
    }
  }
}

function nearestActor(g, x, y){
  let best = null, bd = Infinity;
  for (const a of actors(g)){
    if (a.hp <= 0) continue;
    const d = dist(x, y, a.x, a.y);
    if (d < bd){ bd = d; best = a; }
  }
  return best;
}

function nearestEnemy(g, x, y, exclude){
  let best = null, bd = Infinity;
  for (const en of g.enemies){
    if (en.hp <= 0 || en === exclude) continue;
    const d = dist(x, y, en.x, en.y);
    if (d < bd){ bd = d; best = en; }
  }
  return best;
}

/* ---------------------------------------------------------
   UPPLOCKBART
   --------------------------------------------------------- */
function dropPickup(g, x, y, kind){
  if (kind === 'repair' && g.mods?.noRepair) return;
  g.pickups.push({ x, y, kind, life: 25000 });
}

function breakCrate(g, crate){
  Fx.explosion(crate.x + crate.w / 2, crate.y + crate.h / 2, 0.7, '#c9a25e');
  Fx.debris(crate.x + crate.w / 2, crate.y + crate.h / 2, '#5a4326', 8);
  Audio.sfx('explosion', { vol: .4 });
  const r = Math.random();
  if (r < 0.45) dropPickup(g, crate.x + crate.w / 2, crate.y + crate.h / 2, 'ammo');
  else if (r < 0.7) dropPickup(g, crate.x + crate.w / 2, crate.y + crate.h / 2, 'repair');
}

function updatePickups(g, dt){
  for (let i = g.pickups.length - 1; i >= 0; i--){
    const pu = g.pickups[i];
    pu.life -= dt;
    if (pu.life <= 0){ g.pickups.splice(i, 1); continue; }
    const p = g.allies ? nearestActor(g, pu.x, pu.y) : g.player;
    if (!p || p.hp <= 0) continue;
    const reach = 42 * p.mods.pickupRange;

    const d = dist(pu.x, pu.y, p.x, p.y);
    if (d < reach * 3 && d > p.radius){
      // Dras mot spelaren när den är nära nog
      const a = Math.atan2(p.y - pu.y, p.x - pu.x);
      const pull = clamp((reach * 3 - d) / (reach * 3), 0, 1) * 3.4;
      pu.x += Math.cos(a) * pull; pu.y += Math.sin(a) * pull;
    }
    if (d < p.radius + 14){
      applyPickup(g, pu.kind, p);
      g.pickups.splice(i, 1);
    }
  }
}

function applyPickup(g, kind, target){
  const p = target || g.player;
  if (p !== g.player){
    // Lagkamrat plockade upp: effekten utan ljud och notis på din skärm
    if (kind === 'repair') healPlayer(g, p.maxHp * 0.22, p);
    else if (kind === 'ammo') for (const grp of p.weaponGroups){ grp.ammoLeft = grp.magSize; grp.reloading = false; }
    else if (kind === 'shield'){ if (p.shield && p.shield.type !== 'purple') p.shield.current = p.shield.capacity; else p.invuln = 3000; }
    return;
  }
  Audio.sfx('pickup');
  bus.emit('pickup', kind);
  if (kind === 'repair'){
    const heal = p.maxHp * 0.22;
    healPlayer(g, heal);
    Fx.number(p.x, p.y - 30, `+${Math.round(heal)}`, '#58c98a');
    bus.emit('toast', { text: 'Skrov reparerat', kind: 'good' });
  } else if (kind === 'ammo'){
    for (const grp of p.weaponGroups){ grp.ammoLeft = grp.magSize; grp.reloading = false; grp.freshMag = true; }
    bus.emit('toast', { text: 'Ammunition påfylld', kind: 'good' });
  } else if (kind === 'shield'){
    if (p.shield && p.shield.type !== 'purple'){
      p.shield.current = p.shield.capacity;
      bus.emit('toast', { text: 'Sköld återställd', kind: 'good' });
    } else {
      p.invuln = 3000;
      bus.emit('toast', { text: 'Nödsköld aktiv', kind: 'good' });
    }
  }
}

function updateMarkers(g, dt){
  for (let i = g.markers.length - 1; i >= 0; i--){
    g.markers[i].left -= dt;
    if (g.markers[i].left <= 0) g.markers.splice(i, 1);
  }
}

/* ---------------------------------------------------------
   VÅGOR
   --------------------------------------------------------- */
function spawnWave(g){
  const sc = waveScaling(g.globalWave);
  const isBossWave = g.waveInSector % (g.mods?.bossEvery || 5) === 0;
  const isFinale = g.waveInSector === g.waveTotal;
  const mm = g.mods || {};
  sc.hp *= mm.enemyHp || 1;
  sc.count = Math.round(sc.count * (mm.enemyCount || 1));
  // Co-op: fler fiender per extra spelare, och tåligare bossar
  const crew = g.coop ? g.coop.players.length : 1;
  if (crew > 1) sc.count = Math.round(sc.count * (1 + 0.55 * (crew - 1)));

  g.enemies.length = 0;
  g.markers.length = 0;

  if (isBossWave || isFinale){
    const pos = spawnPoint(g, 900, 60);
    const boss = makeBoss(g.sector, g.waveInSector, isFinale, pos.x, pos.y);
    if (crew > 1){ boss.maxHp *= 1 + 0.7 * (crew - 1); boss.hp = boss.maxHp; }
    if (isTraining(g)) trainBoss(boss);
    g.enemies.push(boss);
    // Livvakter
    const guards = isFinale ? 5 : 3;
    for (let i = 0; i < guards; i++){
      const p2 = spawnPoint(g, 620, 20);
      g.enemies.push(tuneEnemy(g, makeEnemy(pick(enemyPoolFor(g.globalWave)), p2.x, p2.y, sc.hp * 0.8, sc.dmg)));
    }
    Audio.setIntensity(1);
    bus.emit('boss:start', boss);
    g.bossHurt = false;
    if (g.tut) tutFlash(g, 'boss');
  } else {
    const pool = enemyPoolFor(g.globalWave);
    for (let i = 0; i < sc.count; i++){
      const pos = spawnPoint(g, 560, 20);
      g.enemies.push(makeElite(g, tuneEnemy(g, makeEnemy(pick(pool), pos.x, pos.y, sc.hp, sc.dmg))));
    }
    // Miniboss på våg 7, 12, 17 … (aldrig i träningen)
    if (!isTraining(g) && g.waveInSector >= 7 && g.waveInSector % 5 === 2) spawnMiniboss(g, sc);
    Audio.setIntensity(clamp(g.waveInSector / g.waveTotal, .15, .5));
    bus.emit('boss:end');
  }

  // Storykapitel har en bestämd händelse på en bestämd våg. Annars
  // startar händelser var femte våg från våg 3, aldrig på bossvågor.
  if (g.chapter){
    if (g.chapter.event && g.waveInSector === g.chapter.eventWave && EVENTS[g.chapter.event])
      startEvent(g, g.chapter.event);
  } else if (!g.weekly && !g.coop && !isBossWave && !isFinale && g.waveInSector >= 3 && (g.waveInSector - 3) % 5 === 0){
    startEvent(g, pick(Object.keys(EVENTS)));
  }

  bus.emit('wave:start', g);
}

function spawnPoint(g, minDist, radius){
  for (let i = 0; i < 60; i++){
    const a = Math.random() * TAU;
    const d = minDist + Math.random() * 700;
    const x = clamp(g.player.x + Math.cos(a) * d, 160, WORLD.w - 160);
    const y = clamp(g.player.y + Math.sin(a) * d, 160, WORLD.h - 160);
    if (!hitsObstacle(g.arena.obstacles, x, y, radius + 26)) return { x, y };
  }
  return { x: clamp(g.player.x + 700, 200, WORLD.w - 200), y: g.player.y };
}

function updateWave(g, dt){
  if (g.tut && g.tut.hold) return;
  if (g.phase !== 'fight') {
    if (g.phase === 'cleared'){
      g.waveBreak -= dt;
      if (g.waveBreak <= 0) nextWave(g);
    }
    return;
  }
  if (g.enemies.length > 0) return;

  // Vågen är klar
  g.phase = 'cleared';
  g.waveBreak = 1400;
  const p = g.player;

  if (p.mods.hpPerWave > 0){
    healPlayer(g, p.maxHp * p.mods.hpPerWave);
    Fx.number(p.x, p.y - 34, `+${Math.round(p.maxHp * p.mods.hpPerWave)}`, '#58c98a');
  }
  if (g.event) resolveEvent(g, false, true);

  g.score += Math.round(500 * g.waveInSector * p.mods.scoreMult);
  Audio.sfx('uiBig', { vol: .5 });
  bus.emit('wave:cleared', g);
}

function nextWave(g){
  const p = g.player;

  if (g.waveInSector >= g.waveTotal){ finish(g, 'sector'); return; }

  g.waveInSector++;
  g.globalWave++;

  if (g.coop) reviveFallen(g);

  // Var tredje våg får man välja en fältuppgradering (inte i co-op — ingen kan pausa åt alla)
  if (!g.coop && g.waveInSector % 3 === 1 && g.waveInSector > 1){
    g.phase = 'draft';
    const choices = rollPerks(g.perksTaken, 3);
    Battle.pause();
    bus.emit('draft:open', {
      choices,
      pick: id => {
        const perk = perkById(id);
        if (perk){
          perk.apply(p.mods, p);
          g.perksTaken.push(id);
          Audio.sfx('uiBig');
        }
        g.phase = 'fight';
        spawnWave(g);
        storyBeat(g);
        Battle.resume();
      }
    });
    return;
  }

  g.phase = 'fight';
  spawnWave(g);
  storyBeat(g);
}

/** Berättelserad när en ny våg börjar: kapitlets egna repliker i story,
    sektorns lägesrapport var fjärde våg annars. */
function storyBeat(g){
  if (g.chapter){
    const line = g.chapter.lines?.[g.waveInSector];
    if (line) story(g, `VÅG ${g.waveInSector} / ${g.waveTotal}`, line);
    return;
  }
  if (g.tut) return;
  if (g.waveInSector % 4 === 0) story(g, `VÅG ${g.waveInSector}`, sectorIntro(g.sector));
}

/* ---------------------------------------------------------
   HÄNDELSER
   --------------------------------------------------------- */
function startEvent(g, type){
  const def = EVENTS[type];
  const objects = [];
  const n = type === 'supply' ? 3 : 3;
  for (let i = 0; i < n; i++){
    const pos = spawnPoint(g, 420, 26);
    objects.push({ x: pos.x, y: pos.y, hp: type === 'supply' ? 1 : 700, maxHp: 700, radius: 22, taken: false });
  }
  g.event = { type, def, left: def.time, objects };

  if (type === 'supply') objects.forEach(o => dropPickup(g, o.x, o.y, 'repair'));
  Audio.sfx('alarm');
  bus.emit('event:start', g.event);
  if (g.tut) tutFlash(g, 'event');
}

function updateEvent(g, dt){
  const ev = g.event;
  if (!ev) return;
  ev.left -= dt;

  if (ev.type === 'supply'){
    // Klarad när alla kapslar hämtats
    const left = g.pickups.filter(p => p.kind === 'repair').length;
    if (left === 0){ resolveEvent(g, true); return; }
  } else {
    for (const o of ev.objects){
      if (o.hp <= 0) continue;
      // Spelarens skott skadar objekten
      for (let i = g.projectiles.length - 1; i >= 0; i--){
        const pr = g.projectiles[i];
        if (!pr.fromPlayer) continue;
        if (dist(pr.x, pr.y, o.x, o.y) < o.radius + pr.size){
          o.hp -= pr.dmg;
          Fx.spark(pr.x, pr.y, '#ff8a3c', 5, 3);
          g.projectiles.splice(i, 1);
          if (o.hp <= 0){ Fx.explosion(o.x, o.y, 1.4); Audio.sfx('explosion'); }
        }
      }
    }
    if (ev.objects.every(o => o.hp <= 0)){ resolveEvent(g, true); return; }
  }

  if (ev.left <= 0) resolveEvent(g, false);
  bus.emit('event:tick', ev);
}

function resolveEvent(g, success, silent){
  const ev = g.event;
  if (!ev) return;
  g.event = null;

  if (success){
    g.score += 1500;
    grant({ ag: 350 });
    bus.emit('toast', { text: `${ev.def.name} avvärjt · +350 Ag`, kind: 'good' });
    Audio.sfx('uiBig');
  } else if (!silent){
    if (ev.type === 'bomb'){
      ev.objects.filter(o => o.hp > 0).forEach(o => explode(g, o.x, o.y, 220, 340, false));
    }
    bus.emit('toast', { text: ev.def.fail, kind: 'bad' });
  }
  bus.emit('event:end', { success, type: ev.type });
}

/* ---------------------------------------------------------
   KAMERA
   --------------------------------------------------------- */
function updateCamera(g, dt){
  const p = g.player.hp > 0 || !g.allies ? g.player : (living(g)[0] || g.player);
  const cam = g.camera;
  const vw = viewW(), vh = viewH();

  // Kameran tittar en bit åt det håll man siktar — man ser fienden
  // innan den ser en, och siktet hamnar inte i kanten av bilden.
  const look = 130;
  const tx = p.x + Math.cos(p.angle) * look - vw / 2;
  const ty = p.y + Math.sin(p.angle) * look - vh / 2;

  const k = 1 - Math.pow(0.001, dt / 1000);
  cam.x = lerp(cam.x, tx, k * 3.5);
  cam.y = lerp(cam.y, ty, k * 3.5);
  cam.x = clamp(cam.x, 0, Math.max(0, WORLD.w - vw));
  cam.y = clamp(cam.y, 0, Math.max(0, WORLD.h - vh));
}

/* ---------------------------------------------------------
   BERÄTTELSE OCH AVSLUT
   --------------------------------------------------------- */
function story(g, title, text){
  if (g.coop?.role === 'host') g.coop.fx.push(['s', title, text]);
  g.bannerTimer = 6000;
  bus.emit('story:show', { title, text });
}

function finish(g, reason){
  if (!Battle.running) return;
  Battle.stop();

  const p = g.player;
  const diff = DIFFICULTIES[state.settings.difficulty] || DIFFICULTIES.soldat;
  const won = reason === 'sector';
  const ch = g.chapter;
  const firstClear = !!(won && ch && !state.story.done.includes(ch.id));
  const wk = g.weekly;
  if (g.coop) coopFinish(g, reason);
  if (wk && state.weekly.id !== wk.id) state.weekly = { id: wk.id, done: false, best: 0 };
  const weeklyFirst = !!(won && wk && !state.weekly.done);

  // Belöningar
  const ag = Math.round((ECONOMY.agPerWave * g.waveInSector * (g.waveInSector + 1) / 2 / 3
            + g.kills * ECONOMY.agPerKill) * diff.reward);
  const bosses = Math.floor(g.waveInSector / 5);
  let au = bosses * ECONOMY.auPerBoss;
  let pl = 0;
  if (won){
    au += ECONOMY.auPerSector;
    pl += ECONOMY.plPerSectorFinale;
  }
  // Story: kapitlets egen belöning första gången, en fjärdedel vid omspel.
  // Sektorbonusen (Au/Pl för rensad sektor) gäller bara sektorläget.
  let bonusAg = 0;
  if (ch){
    au -= won ? ECONOMY.auPerSector : 0;
    pl = 0;
    if (won){
      bonusAg = firstClear ? ch.reward.ag : Math.round(ch.reward.ag * 0.25);
      if (firstClear){ au += ch.reward.au; pl += ch.reward.pl; }
    }
  }
  if (g.trial){ au -= won ? ECONOMY.auPerSector : 0; pl = 0; }
  // Veckans utmaning: ingen sektorbonus, men en fast belöning första vinsten i veckan
  if (wk){
    au -= won ? ECONOMY.auPerSector : 0;
    pl = 0;
    if (weeklyFirst){ au += WEEKLY_REWARD.au; pl += WEEKLY_REWARD.pl; }
  }
  const payout = { ag: Math.round((ag + bonusAg) * (g.mods?.agMult || 1)), au: Math.round(au * diff.reward), pl };
  if (reason !== 'abandon') grant(payout);

  // Karriärstatistik
  state.career.runs++;
  state.career.kills += g.kills;
  state.career.waves += g.waveInSector;
  state.career.bosses += bosses;
  state.career.damage += Math.round(p.stats.damage);
  state.career.ms += Math.round(g.elapsed);
  state.bestWave = Math.max(state.bestWave, g.globalWave);
  state.bestScore = Math.max(state.bestScore, g.score);

  if (g.mode === 'sectors' && won && g.sector >= state.sector) state.sector = g.sector + 1;
  if (firstClear) state.story.done.push(ch.id);
  if (wk){
    state.weekly.best = Math.max(state.weekly.best, g.waveInSector);
    if (won) state.weekly.done = true;
  }
  // Rekord per läge — visas i statistiken
  state.records = state.records || {};
  const prevSurvival = state.records.survival?.wave || 0;
  const rk = g.trial ? 'trial_' + g.trial.id : g.mode === 'story' ? 'story' : g.mode;
  // Arenans rekord: bästa tid (bara vinster) eller bästa poäng
  if (g.trial){
    const r = state.records[rk] || {};
    if (g.trial.rank === 'time' && won && (!r.time || g.elapsed < r.time)) r.time = Math.round(g.elapsed);
    if (g.trial.rank === 'score' && (!r.day || r.day !== g.trial.daily?.id || g.score > (r.score || 0))){ r.score = Math.round(g.score); r.day = g.trial.daily?.id; }
    r.wave = Math.max(r.wave || 0, g.waveInSector);
    state.records[rk] = r;
  }
  if (!g.trial){
    const rec = state.records[rk] || { score: 0, wave: 0 };
    state.records[rk] = { score: Math.max(rec.score, Math.round(g.score)), wave: Math.max(rec.wave, g.waveInSector),
                          sector: g.mode === 'sectors' ? Math.max(rec.sector || 0, g.sector) : undefined };
  }
  // Nivå och XP. Träningen ger nivå 2 direkt; allt annat ger XP.
  // Vinst ger mest, förlust hälften av grunden, att lämna ger inget.
  const training = isTraining(g);
  const lvlBefore = levelProgress();
  let xpGained = 0, levelUp = null;
  if (training){
    if (won) levelUp = completeTraining();
  } else {
    const res = addXp(runXp({
      reason, won, mode: g.mode, sector: g.sector, firstClear,
      waves: won ? g.waveInSector : Math.max(0, g.waveInSector - 1),
      kills: g.kills, bosses
    }));
    xpGained = res.gained; levelUp = res.up;
  }
  const lvlAfter = levelProgress();

  // Träningen räknas som genomförd när grunderna är avklarade eller sektorn vunnen
  if (g.tut && (won || g.tut.basicDone)) state.flags.battleTutDone = true;
  if (g.tut) bus.emit('coach:hide');

  // Order
  if (!p.tookDamage && g.waveInSector >= 5 && !state.quests.noDamage5){
    state.quests.noDamage5 = true; grant({ pl: 1 });
  }
  if (g.globalWave >= 10 && !state.quests.wave10){
    state.quests.wave10 = true; grant({ pl: 1 });
  }
  if (won && g.mode === 'sectors' && g.sector >= 2 && !state.quests.sector2){
    state.quests.sector2 = true; grant({ au: 30 });
  }
  save(true);

  bus.emit('battle:finished', {
    reason, won, payout, game: g,
    stats: {
      wave: g.waveInSector, waveTotal: g.waveTotal, sector: g.sector, kills: g.kills, score: g.score,
      mode: g.mode, chapter: ch ? ch.id : null, firstClear, tutorial: !!g.tut,
      weekly: wk ? wk.week : null, weeklyFirst,
      xp: xpGained, lvlBefore, lvlAfter, levelUp, prevSurvival,
      trial: g.trial ? g.trial.id : null, trialDay: g.trial?.daily?.id || null, elapsed: Math.round(g.elapsed),
      accuracy: p.stats.shots ? Math.round(p.stats.hits / p.stats.shots * 100) : 0,
      damage: Math.round(p.stats.damage), taken: Math.round(p.stats.taken),
      time: g.elapsed, perks: g.perksTaken.slice()
    }
  });
}

/* ---------------------------------------------------------
   TRÄNINGEN — instruktör i strid
   Grunderna tas en i taget. Varje steg klaras av att man
   faktiskt gör saken, inte av att man trycker "nästa".
   Första vågen släpps på först när man kan gå, skjuta och
   ladda om. Efter det dyker korta tips upp när något nytt
   händer (första händelsen, första bossen).
   --------------------------------------------------------- */
const TUT_STEPS = [
  { id: 'move', title: 'RÖR DIG',
    text: 'Håll in W A S D (eller piltangenterna) för att gå. Gå en bit åt valfritt håll.',
    keys: ['W', 'A', 'S', 'D'], done: g => g.tut.moved > 320 },
  { id: 'shoot', title: 'SIKTA OCH SKJUT',
    text: 'Roboten siktar dit musen pekar. Håll inne vänster musknapp för att skjuta.',
    keys: ['MUS', 'VÄNSTERKLICK'], done: g => g.player.stats.shots >= 10 },
  { id: 'reload', title: 'LADDA OM',
    text: 'Skotten i magasinet syns nere till höger. Tryck R för att ladda om i lugnt läge — då slipper du stå tom mitt i en strid.',
    keys: ['R'], done: g => g.tut.reloaded },
  { id: 'ability', title: 'FÖRMÅGA',
    text: 'Din robot har en specialförmåga. Tryck Shift eller Q för att använda den. Mätaren nere till vänster visar när den är laddad.',
    keys: ['SHIFT', 'Q'], skip: g => !abilityInfo(g.player), done: g => g.tut.usedAbility },
  { id: 'fight', title: 'FIENDER PÅ VÄG',
    text: 'Röda prickar på sensorn nere till höger är fiender. Skjut ned alla för att klara vågen. Håll dig i rörelse!',
    keys: [], enter: g => { g.tut.hold = false; spawnWave(g); }, done: g => g.waveInSector > 1 || g.phase !== 'fight' },
  { id: 'loot', title: 'VÅGEN KLAR',
    text: 'Bra! Fiender och lådor tappar ibland gröna föremål — reparation och ammo. Gå över dem för att plocka upp. Vågmätaren högst upp visar hur långt du kommit.',
    keys: [], done: g => g.tut.t > 8000 }
];

const TUT_FLASH = {
  event: { title: 'HÄNDELSE', text: 'Ett uppdrag mitt i striden! Läs rutan till höger och klara det innan tiden rinner ut. Målen syns på sensorn.', keys: [], time: 9000 },
  boss:  { title: 'BOSS', text: 'Bossen har en egen mätare högst upp. Håll avstånd, rör dig hela tiden och ladda om bakom skydd.', keys: [], time: 9000 }
};

function startTutorial(g){
  const t = g.tut;
  t.i = -1;
  tutNext(g);
}

function tutNext(g){
  const t = g.tut;
  t.i++;
  while (t.i < TUT_STEPS.length && TUT_STEPS[t.i].skip?.(g)) t.i++;
  t.t = 0;
  if (t.i >= TUT_STEPS.length){
    t.basicDone = true;
    t.hold = false;
    if (!t.flash) bus.emit('coach:hide');
    return;
  }
  const s = TUT_STEPS[t.i];
  s.enter?.(g);
  if (s.id === 'fight') t.basicDone = true;   // grunderna sitter — räcker för att inte visa träningen igen
  if (!t.flash) tutShow(g);
}

function tutShow(g){
  const t = g.tut, s = TUT_STEPS[t.i];
  const visible = TUT_STEPS.filter(x => !x.skip?.(g));
  bus.emit('coach:show', {
    title: s.title, text: s.text, keys: s.keys,
    step: visible.indexOf(s) + 1, total: visible.length
  });
}

function tutFlash(g, key){
  const t = g.tut;
  if (t.seen[key]) return;
  t.seen[key] = true;
  const f = TUT_FLASH[key];
  t.flash = { left: f.time };
  bus.emit('coach:show', { title: f.title, text: f.text, keys: f.keys, tip: true });
}

function updateTutorial(g, dt){
  const t = g.tut, p = g.player;
  t.moved += Math.hypot(p.x - t.lx, p.y - t.ly);
  t.lx = p.x; t.ly = p.y;

  if (t.flash){
    t.flash.left -= dt;
    if (t.flash.left <= 0){
      t.flash = null;
      if (t.i < TUT_STEPS.length) tutShow(g); else bus.emit('coach:hide');
    }
  }
  if (t.i >= TUT_STEPS.length) return;
  t.t += dt;
  const s = TUT_STEPS[t.i];
  // Kort minsta visningstid så att ingen ruta blinkar förbi oläst
  if (t.t > 900 && s.done(g)){
    bus.emit('coach:check');
    Audio.sfx('uiBig', { vol: .35 });
    tutNext(g);
  }
}

/* =========================================================
   CO-OP
   Värden (host) räknar ut hela striden precis som vanligt,
   med lagkamraternas robotar som extra "spelare" som styrs av
   inmatning över nätet. Tjugo gånger i sekunden skickar värden
   en ögonblicksbild av läget. Gästerna räknar inte ut något —
   de ritar värdens bild och skickar sin egen inmatning.
   Enkelt, svårt att få osynkat, och fungerar bra på samma
   nätverk. Över internet märks fördröjningen mer.
   ========================================================= */
const SNAP_MS = 50;      // ögonblicksbild var 50:e ms (20/s)
const INPUT_MS = 33;     // gästens inmatning ~30/s

function buildAlly(g, pl, i){
  const slot = pl.slot && pl.slot.tpl ? pl.slot : makeSlot('recon');
  const a = buildPlayer(slot);
  a.isAlly = true;
  a.netId = pl.id;
  a.tag = String(pl.name || 'Spelare');
  a.rank = titleFor(pl.level || 1);
  a.net = { mx: 0, my: 0, aim: 0, fire: false, hits: new Set() };
  const ang = TAU * (i + 1) / 4;
  a.x = g.arena.spawn.x + Math.cos(ang) * 70;
  a.y = g.arena.spawn.y + Math.sin(ang) * 70;
  return a;
}

function setupCoop(g, coop, slot){
  g.coop = { role: coop.role, me: coop.me, host: coop.host, players: coop.players,
             fx: [], snapT: 0, inT: 0, pendingHits: new Set(), offs: [], seenBoss: null, lastAmmo: null, uid: 0 };
  g.allies = coop.players.filter(pl => pl.id !== coop.me).map((pl, i) => buildAlly(g, pl, i));
  g.player.netId = coop.me;

  if (coop.role === 'host'){
    g.coop.offs.push(onNet('relay', m => {
      const d = m.data;
      if (d && d.k === 'ping'){
        const al = g.allies.find(a => a.netId === m.from);
        if (al) placePing(g, al, { x: +d.x || 0, y: +d.y || 0 });
        return;
      }
      if (!d || d.k !== 'in') return;
      const al = g.allies.find(a => a.netId === m.from);
      if (!al) return;
      al.net.mx = clamp(+d.mx || 0, -1, 1); al.net.my = clamp(+d.my || 0, -1, 1);
      al.net.aim = +d.aim || 0; al.net.fire = !!d.fire;
      for (const h of d.hits || []) if (h === 'reload' || h === 'ability') al.net.hits.add(h);
    }));
  } else {
    g.phase = 'fight';
    g.coop.offs.push(onNet('relay', m => {
      const d = m.data;
      if (!d) return;
      if (d.k === 's') applySnapshot(g, d);
      else if (d.k === 'end' && Battle.running && Battle.game === g){
        g.waveInSector = d.wave;
        g.kills = Math.round((d.kills || 0) / Math.max(1, g.coop.players.length));
        g.score = d.score || 0;
        finish(g, d.reason);
      }
    }));
    const lost = () => {
      if (!Battle.running || Battle.game !== g) return;
      bus.emit('toast', { text: 'Värden lämnade — matchen avbröts', kind: 'bad' });
      finish(g, 'abandon');
    };
    g.coop.offs.push(onNet('closed', lost), onNet('down', lost));
  }
  // Någon lämnade: deras robot försvinner ur striden
  g.coop.offs.push(onNet('left', m => {
    const i = g.allies.findIndex(a => a.netId === m.id);
    if (i >= 0) g.allies.splice(i, 1);
    g.coop.players = g.coop.players.filter(pl => pl.id !== m.id);
    bus.emit('toast', { text: `${m.name || 'En spelare'} lämnade matchen`, kind: 'bad' });
    if (g.coop.role === 'host' && !living(g).length) finish(g, 'dead');
  }));
}

function teardownCoop(g){
  if (!g?.coop) return;
  for (const off of g.coop.offs) off();
  g.coop.offs = [];
}

/** Fallna lagkamrater kommer tillbaka med halva livet när en ny våg börjar. */
function reviveFallen(g){
  const anchor = living(g)[0];
  if (!anchor) return;
  for (const a of actors(g)){
    if (a.hp > 0) continue;
    a.hp = Math.round(a.maxHp * 0.5);
    a.x = anchor.x + rand(60, -60); a.y = anchor.y + rand(60, -60);
    a.invuln = 2000;
    for (const grp of a.weaponGroups){ grp.ammoLeft = grp.magSize; grp.reloading = false; }
    if (a === g.player) bus.emit('toast', { text: 'Du är tillbaka i striden', kind: 'good' });
    if (g.coop.role === 'host') g.coop.fx.push(['r', a.netId]);
  }
}

/* ---------- Värd: ögonblicksbilder ---------- */
const r1 = v => Math.round(v * 10) / 10;
const r3 = v => Math.round(v * 1000) / 1000;
const shieldOf = s => s ? [s.type, Math.round(s.current || 0), Math.round(s.capacity || 0), s.active ? 1 : 0] : 0;

function abilityPct(a){
  if (a.scan) return a.scan.active ? [1, a.scan.activeLeft / a.scan.duration] : [0, 1 - a.scan.cdLeft / a.scan.cooldown];
  if (a.special) return a.special.active ? [1, a.special.activeLeft / Math.max(1, a.special.duration)] : [0, 1 - a.special.cdLeft / a.special.cooldown];
  if (a.overdrive) return a.overdrive.active ? [1, a.overdrive.activeLeft / a.overdrive.duration] : [0, 1 - a.overdrive.cdLeft / a.overdrive.cooldown];
  if (a.dash) return [a.dash.active ? 1 : 0, 1 - a.dash.cdLeft / a.dash.cooldown];
  if (a.shield?.type === 'purple') return a.shield.active ? [1, a.shield.activeLeft / a.shield.duration] : [0, 1 - a.shield.cdLeft / a.shield.cooldown];
  return [0, 1];
}

function buildSnapshot(g){
  const c = g.coop;
  for (const e of g.enemies) if (!e.uid) e.uid = ++c.uid;
  const deadObs = [];
  g.arena.obstacles.forEach((o, i) => { if (o.hp <= 0) deadObs.push(i); });
  const snap = {
    k: 's', w: g.waveInSector, wt: g.waveTotal, ph: g.phase, sc: Math.round(g.score), ki: g.kills,
    P: actors(g).map(a => [a.netId, r1(a.x), r1(a.y), r3(a.angle), r3(a.moveAngle || 0), r3(a.walk || 0),
      Math.round(a.hp), Math.round(a.maxHp), shieldOf(a.shield),
      a.weaponGroups.map(gr => [gr.ammoLeft, gr.reloading ? 1 : 0, Math.round(gr.reloadTimer)]),
      abilityPct(a).map(r3), a.invuln > 0 ? 1 : 0, Math.round(a.reviveT || 0)]),
    E: g.enemies.map(e => [e.uid, e.key, r1(e.x), r1(e.y), r3(e.angle), r3(e.moveAngle || 0), r3(e.walk || 0),
      Math.round(e.hp), Math.round(e.maxHp), shieldOf(e.shield), Math.round(e.tellLeft || 0),
      e.isBoss ? [e.name, e.typeLabel, e.isFinale ? 1 : 0, e.tellTotal || 1200, e.phase || 1, e.radius, e.color] : 0, e.elite || 0,
      e.cloak ? 1 : 0, e.miniboss ? [e.name, e.radius] : 0]),
    R: g.projectiles.map(p => [r1(p.x), r1(p.y), r1(p.vx), r1(p.vy), p.color, p.size, p.trail ? 1 : 0]),
    U: g.pickups.map(u => [r1(u.x), r1(u.y), u.kind]),
    M: g.markers.map(m => [r1(m.x), r1(m.y), m.r, Math.round(m.left), m.total]),
    O: deadObs,
    X: c.fx
  };
  c.fx = [];
  return snap;
}

function coopHostTick(g, dt){
  if (g.coop.role !== 'host') return;
  g.coop.snapT -= dt;
  if (g.coop.snapT > 0) return;
  g.coop.snapT = SNAP_MS;
  relay(buildSnapshot(g));
}

/* ---------- Gäst: visa värdens bild ---------- */
function applySnapshot(g, s){
  const c = g.coop;
  // Våg och fas — HUD:en får samma händelser som i ett vanligt spel
  if (s.w !== g.waveInSector){ g.waveInSector = s.w; g.waveTotal = s.wt; bus.emit('wave:start', g); }
  if (s.ph !== g.phase){ if (s.ph === 'cleared') bus.emit('wave:cleared', g); g.phase = s.ph; }
  g.score = s.sc; g.kills = s.ki;

  // Spelarrobotar
  for (const row of s.P){
    const [id, x, y, ang, mAng, walk, hp, maxHp, sh, ammo, ab, inv, rev] = row;
    const a = id === c.me ? g.player : g.allies.find(al => al.netId === id);
    if (!a) continue;
    if (a._tx === undefined || Math.hypot(a.x - x, a.y - y) > 300){ a.x = x; a.y = y; }
    a._tx = x; a._ty = y;
    if (a !== g.player) a.angle = ang;
    a.moveAngle = mAng; a.walk = walk;
    if (a === g.player && hp < a.hp && hp > 0) bus.emit('player:hurt', clamp((a.hp - hp) / (maxHp * 0.22), 0.15, 1));
    a.hp = hp; a.maxHp = maxHp; a.invuln = inv ? 1 : 0; a.reviveT = rev || 0;
    if (sh && a.shield){ a.shield.current = sh[1]; a.shield.capacity = sh[2] || a.shield.capacity; a.shield.active = !!sh[3]; }
    ammo.forEach((m, i) => {
      const gr = a.weaponGroups[i];
      if (!gr) return;
      if (a === g.player && m[0] < gr.ammoLeft && !m[1]){
        const fx = AMMO_FX[gr.kind];
        Audio.sfx(fx.sfx, { vol: .8 });
      }
      gr.ammoLeft = m[0]; gr.reloading = !!m[1]; gr.reloadTimer = m[2];
    });
    // Förmågemätaren i HUD:en läser samma fält som i ett vanligt spel
    const [act, pct] = ab;
    const setAb = (o, dur, cd) => { if (!o) return; o.active = !!act;
      if (act) o.activeLeft = pct * o[dur]; else o.cdLeft = (1 - pct) * o[cd]; };
    setAb(a.scan, 'duration', 'cooldown');
    setAb(a.overdrive, 'duration', 'cooldown');
    setAb(a.special, 'duration', 'cooldown');
    if (a.dash){ a.dash.active = !!act; a.dash.cdLeft = (1 - pct) * a.dash.cooldown; }
    if (a.shield?.type === 'purple') setAb(a.shield, 'duration', 'cooldown');
  }

  // Fiender: återanvänd objekt med samma id så att de glider istället för att hoppa
  const byId = new Map(g.enemies.map(e => [e.uid, e]));
  const next = [];
  for (const row of s.E){
    const [uid, key, x, y, ang, mAng, walk, hp, maxHp, sh, tell, boss, elite, cloak, mini] = row;
    let e = byId.get(uid);
    if (!e){
      if (boss){
        const [name, typeLabel, fin, tellTotal, phase, radius, color] = boss;
        e = { isBoss: true, key: 'boss', name, typeLabel, isFinale: !!fin, tellTotal, phase, radius, color,
              frame: 'heavy', shield: null, shieldHits: [], x, y, angle: ang,
              get hpPct(){ return this.hp / this.maxHp; } };
      } else {
        e = makeEnemy(key, x, y);
      }
      e.uid = uid;
      e.x = x; e.y = y;
      if (elite){ e.elite = elite; e.radius *= 1.2; }
      if (mini){ e.miniboss = true; e.name = mini[0]; e.radius = mini[1]; e.frame = 'heavy'; }
    }
    e.cloak = !!cloak;
    e._tx = x; e._ty = y; e.angle = ang; e.moveAngle = mAng; e.walk = walk;
    e.hp = hp; e.maxHp = maxHp; e.tellLeft = tell;
    if (sh){
      e.shield = e.shield || { type: sh[0], current: 0, capacity: 1 };
      e.shield.type = sh[0]; e.shield.current = sh[1]; e.shield.capacity = sh[2] || 1; e.shield.active = !!sh[3];
    }
    if (boss){
      if (c.seenBoss !== uid){ c.seenBoss = uid; bus.emit('boss:start', e); }
      if (boss[4] !== e.phase){ e.phase = boss[4]; bus.emit('boss:phase', { phase: e.phase, boss: e }); }
    }
    next.push(e);
  }
  if (c.seenBoss && !next.some(e => e.isBoss)){ c.seenBoss = null; bus.emit('boss:end'); }
  g.enemies = next;

  g.projectiles = s.R.map(([x, y, vx, vy, color, size, trail]) => ({ x, y, vx, vy, color, size, trail: !!trail }));
  g.pickups = s.U.map(([x, y, kind]) => ({ x, y, kind, life: 1 }));
  g.markers = s.M.map(([x, y, r, left, total]) => ({ x, y, r, left, total }));
  for (const i of s.O){ const o = g.arena.obstacles[i]; if (o) o.hp = 0; }

  for (const fx of s.X){
    if (fx[0] === 'x'){
      const [, x, y, big, color, name, killer, elite] = fx;
      // Gästens egna fällningar räknas för uppdrag och prestationer
      if (killer === c.me) bus.emit('enemy:killed', { boss: !!big, elite: elite || null, mine: true, noDamageBoss: false, mode: 'coop' });
      Fx.explosion(x, y, big ? 3.2 : 1, color);
      Audio.sfx(big ? 'explosion' : 'kill', { vol: big ? 1 : .5 });
      if (big){ Fx.shake(20); Fx.screenFlash(0.6); }
      bus.emit('killfeed', { name, boss: !!big });
    } else if (fx[0] === 's'){
      g.bannerTimer = 6000;
      bus.emit('story:show', { title: fx[1], text: fx[2] });
    } else if (fx[0] === 'p'){
      addPing(g, { x: fx[1], y: fx[2], label: fx[3], who: fx[4], color: fx[5] });
    } else if (fx[0] === 'r' && fx[1] === c.me){
      bus.emit('toast', { text: 'Du är tillbaka i striden', kind: 'good' });
    }
  }
}

function updateGuest(g, dt){
  const c = g.coop, p = g.player, f = dt / 16.67;
  g.elapsed += dt;
  Input.poll();
  pollPadEdges();
  if (Input.hit('pause')) Battle.pause();

  // Siktet räknas lokalt så att det känns direkt, resten skickas till värden
  if (p.hp > 0) p.angle = Input.aim(p.x, p.y, g.camera);
  if (Input.hit('reload')) c.pendingHits.add('reload');
  if (Input.hit('ability')) c.pendingHits.add('ability');
  c.inT -= dt;
  if (c.inT <= 0){
    c.inT = INPUT_MS;
    const mv = Input.move();
    relay({ k: 'in', mx: r3(mv.x), my: r3(mv.y), aim: r3(p.angle), fire: !Battle.paused && Input.down('fire'),
            hits: [...c.pendingHits] });
    c.pendingHits.clear();
  }

  // Mjuk rörelse mellan ögonblicksbilderna
  const k = 1 - Math.pow(0.0005, dt / 1000);
  for (const a of [p, ...g.allies, ...g.enemies]){
    if (a._tx === undefined) continue;
    a.x = lerp(a.x, a._tx, clamp(k * 6, 0, 1));
    a.y = lerp(a.y, a._ty, clamp(k * 6, 0, 1));
  }
  for (const pr of g.projectiles){ pr.x += pr.vx * f; pr.y += pr.vy * f; }

  if (g.bannerTimer > 0){
    g.bannerTimer -= dt;
    if (g.bannerTimer <= 0) bus.emit('story:hide');
  }
  updateCamera(g, dt);
  Fx.update(dt);
  tickMarks(g, dt);
  if (Input.hit('ping')){
    const w = { x: Input.mouse.x + g.camera.x, y: Input.mouse.y + g.camera.y };
    relay({ k: 'ping', x: Math.round(w.x), y: Math.round(w.y) });
  }
}

/* ---------- Slut ---------- */
function coopFinish(g, reason){
  const c = g.coop;
  if (c.role === 'host'){
    const result = { reason, wave: g.waveInSector, kills: g.kills, score: Math.round(g.score) };
    relay({ k: 'end', ...result });
    endMatch(result);
  }
  teardownCoop(g);
}

/* ---------------------------------------------------------
   TRÄNING OCH FIENDERNAS NIVÅ
   --------------------------------------------------------- */
/** Träningen: sektor 1 i sektorläget. */
function isTraining(g){ return g.mode === 'sectors' && g.sector === 1; }

/** Gör en fiende "dum" i träningen: svagare, långsammare, sämre sikt. */
function tuneEnemy(g, en){
  if (!isTraining(g)) return en;
  en.dumb = true;
  en.hp *= TRAINING_ENEMY.hp; en.maxHp = en.hp;
  en.dmg *= TRAINING_ENEMY.dmg;
  en.fireRate *= TRAINING_ENEMY.fireRate;
  en.speed *= TRAINING_ENEMY.speed; en.baseSpeed = en.speed;
  en.shield = null;
  en.telegraph = en.telegraph ? en.telegraph * 1.5 : en.telegraph;
  return en;
}

/** Träningsbossen: ingen sköld, mindre liv, lugnare specialattacker. */
function trainBoss(b){
  b.training = true;
  b.shield = null;
  b.maxHp = TRAINING_BOSS.hp; b.hp = b.maxHp;
  b.dmg *= TRAINING_BOSS.dmg;
  b.specialCooldown = TRAINING_BOSS.specialCooldown;
  b.specialTimer = 6000;
  b.fireRate *= 1.6;
  return b;
}

/* =========================================================
   ELITFIENDER
   Från sektor 2 blir ibland en vanlig fiende "elit" med en
   extra egenskap. De är större, har en guldring och ett namn
   över sig, och ger mer Argentum och poäng när de fälls.
   ========================================================= */
const ELITES = {
  snabb:    en => { en.speed *= 1.55; en.baseSpeed = en.speed; en.fireRate *= 0.8; },
  tålig:    en => { en.hp *= 2.6; en.maxHp = en.hp; },
  sköldad:  en => { en.shield = { type: 'gold', current: en.maxHp * 0.8, capacity: en.maxHp * 0.8 }; },
  explosiv: en => { en.hp *= 1.4; en.maxHp = en.hp; }      // exploderar när den dör (se killEnemy)
};
function makeElite(g, en){
  if (isTraining(g) || en.isBoss) return en;
  const chance = Math.min(0.2, 0.05 + (g.sector - 2) * 0.015 + g.waveInSector * 0.002);
  if (Math.random() > chance) return en;
  const kind = pick(Object.keys(ELITES));
  ELITES[kind](en);
  en.elite = kind;
  en.radius *= 1.2;
  en.dmg *= 1.25;
  return en;
}

/* =========================================================
   MARKERINGAR (ping) OCH SKADEINDIKATOR
   G sätter en markering där muspekaren är. Ligger den på en
   fiende, boss eller ett föremål får den rätt text. I co-op
   ser hela laget den, med namnet på den som satte den.
   ========================================================= */
function pingLabel(g, x, y){
  const near = (list, r) => list.find(o => o.hp !== 0 && dist(x, y, o.x, o.y) < (o.radius || 20) + r);
  const boss = g.enemies.find(e => e.isBoss && dist(x, y, e.x, e.y) < e.radius + 40);
  if (boss) return ['FOKUSERA BOSSEN', '#ff5a1e'];
  if (near(g.enemies, 30)) return ['FIENDE HÄR', '#ff4a5e'];
  if (g.event?.objects && near(g.event.objects, 40)) return ['FÖRSTÖR DEN HÄR', '#ff9a3c'];
  const pu = g.pickups.find(p => dist(x, y, p.x, p.y) < 50);
  if (pu) return [pu.kind === 'repair' ? 'REPARATION HÄR' : pu.kind === 'ammo' ? 'AMMO HÄR' : 'SKÖLD HÄR', '#58c98a'];
  return ['HIT!', '#5fb3d4'];
}
function addPing(g, p){
  g.pings = (g.pings || []).filter(q => q.who !== p.who);   // en markering per spelare åt gången
  g.pings.push({ ...p, t: 4500 });
  Audio.sfx('ui', { vol: .7, pitch: 1.4 });
}
function placePing(g, owner, at){
  const pos = at || { x: Input.mouse.x + g.camera.x, y: Input.mouse.y + g.camera.y };
  const [label, color] = pingLabel(g, pos.x, pos.y);
  const who = owner.tag || 'DU';
  addPing(g, { x: pos.x, y: pos.y, label, who, color });
  if (g.coop?.role === 'host') g.coop.fx.push(['p', Math.round(pos.x), Math.round(pos.y), label, who, color]);
  if (g.coop?.role === 'guest') relay({ k: 'ping', x: Math.round(pos.x), y: Math.round(pos.y) });
}
function tickMarks(g, dt){
  if (g.pings) g.pings = g.pings.filter(p => (p.t -= dt) > 0);
  if (g.hitMarks) g.hitMarks = g.hitMarks.filter(m => (m.t -= dt) > 0);
}

/* =========================================================
   ROBOTFÖRMÅGOR (special)
   Förmågor med varaktighet (spärreld, jaktläge, reparation,
   bastion) verkar via p.special.active på andra ställen i
   koden. Direkta förmågor (sköldpuls, stampa, missilsvärm)
   gör allt här och går sedan in i nedkylning direkt.
   ========================================================= */
function useSpecial(g, p, sp){
  const local = p === g.player;
  const pw = sp.power || 1;
  if (sp.duration > 0){
    sp.active = true;
    sp.activeLeft = sp.duration;
  } else {
    sp.cdLeft = sp.cooldown;
  }
  switch (sp.kind){
    case 'barrage':
      Audio.sfx('ability', { pitch: .9 });
      Fx.light(p.x, p.y, 160, '#ffb347', 400);
      break;
    case 'hunt':
      Audio.sfx('ability', { pitch: 1.3 });
      Fx.light(p.x, p.y, 150, '#6fd39a', 400);
      break;
    case 'repair':
      Audio.sfx('ability', { pitch: 1.1 });
      Fx.light(p.x, p.y, sp.radius, '#58c98a', 700);
      break;
    case 'bastion':
      Audio.sfx('ability', { pitch: .7 });
      Fx.light(p.x, p.y, 180, '#ffd35a', 600);
      break;
    case 'pulse': {
      if (p.shield && p.shield.type !== 'purple') p.shield.current = p.shield.capacity;
      for (const en of g.enemies){
        if (en.hp <= 0) continue;
        const d = dist(p.x, p.y, en.x, en.y);
        if (d > sp.radius + en.radius) continue;
        const k = en.isBoss ? 30 : 140;
        en.x += (en.x - p.x) / (d || 1) * k; en.y += (en.y - p.y) / (d || 1) * k;
        en.lastHitBy = p;
        damageEnemy(g, en, sp.dmg * pw, 'special', false);
      }
      g.scanWave = { x: p.x, y: p.y, r: 0 };
      Audio.sfx('ability', { pitch: 1.2 });
      if (local) Fx.shake(8);
      break;
    }
    case 'stomp': {
      for (const en of g.enemies){
        if (en.hp <= 0) continue;
        const d = dist(p.x, p.y, en.x, en.y);
        if (d > sp.radius + en.radius) continue;
        en.slowLeft = 2200;
        en.lastHitBy = p;
        damageEnemy(g, en, sp.dmg * pw * (1 - 0.5 * d / sp.radius), 'special', false);
      }
      Fx.explosion(p.x, p.y, 1.8, '#c9a23a');
      Audio.sfx('explosion', { vol: .8, pitch: .7 });
      if (local){ Fx.shake(18); Fx.hitStop(60); }
      break;
    }
    case 'swarm': {
      const targets = g.enemies.filter(e => e.hp > 0).sort((a, b) => dist(p.x, p.y, a.x, a.y) - dist(p.x, p.y, b.x, b.y));
      for (let i = 0; i < sp.count; i++){
        const t = targets[i % Math.max(1, targets.length)];
        const a = t ? Math.atan2(t.y - p.y, t.x - p.x) + rand(0.6, -0.6) : p.angle + rand(0.8, -0.8);
        shoot(g, { x: p.x, y: p.y, angle: a, dmg: sp.dmg * pw * p.mods.dmg, ammo: 'special', kind: 'missile',
                   fromPlayer: true, homing: true, life: 2600, owner: p, mods: p.mods });
      }
      Audio.sfx('ability', { pitch: 1 });
      break;
    }
  }
}

/* =========================================================
   FIENDERNAS EGENSKAPER
   Fältmekaniker reparerar andra fiender i närheten.
   Smygare syns knappt förrän de är nära eller blir träffade
   (sensorpulsen avslöjar dem).
   Barriärbärare ger fiender runt sig en blå sköld.
   ========================================================= */
function enemyTraits(g, en, dt, p){
  en.traitTimer -= dt;
  en.sinceHit += dt;
  if (en.stealth){
    const d = dist(en.x, en.y, p.x, p.y);
    const scanned = actors(g).some(a => a.scan?.active);
    en.cloak = !scanned && d > 280 && en.sinceHit > 1500;
  }
  if (en.traitTimer > 0) return;
  if (en.healer){
    en.traitTimer = 1600;
    let healed = 0;
    for (const o of g.enemies){
      if (o === en || o.hp <= 0 || o.hp >= o.maxHp) continue;
      if (dist(en.x, en.y, o.x, o.y) > 280) continue;
      o.hp = Math.min(o.maxHp, o.hp + o.maxHp * (o.isBoss ? 0.015 : 0.07));
      Fx.spark(o.x, o.y, '#58c98a', 6, 2);
      if (++healed >= 3) break;
    }
    if (healed) Fx.light(en.x, en.y, 90, '#58c98a', 300);
  }
  if (en.caster){
    en.traitTimer = 5200;
    const near = g.enemies.filter(o => o !== en && o.hp > 0 && !o.isBoss && !o.shield && dist(en.x, en.y, o.x, o.y) < 300)
      .sort((a, b) => dist(en.x, en.y, a.x, a.y) - dist(en.x, en.y, b.x, b.y)).slice(0, 3);
    for (const o of near){
      o.shield = { type: 'blue', capacity: o.maxHp * 0.4, current: o.maxHp * 0.4, regenDelay: 99999, regenRate: 0, sinceHit: 0 };
      Fx.spark(o.x, o.y, '#5fb3d4', 8, 2.5);
    }
    if (near.length) Fx.light(en.x, en.y, 120, '#5fb3d4', 400);
  }
}

/* =========================================================
   MINIBOSS
   Mitt i vissa vågor (våg 3, 8, 13 …) dyker en löjtnant upp:
   en förstärkt tung fiende med egen mätare över sig.
   ========================================================= */
function spawnMiniboss(g, sc){
  const pos = spawnPoint(g, 600, 30);
  const key = g.globalWave >= 9 ? pick(['guardian', 'brute', 'caster']) : 'brute';
  const en = makeEnemy(key, pos.x, pos.y, sc.hp * 5, sc.dmg * 1.4);
  en.miniboss = true;
  en.name = 'Löjtnant ' + en.name.toLowerCase();
  en.radius *= 1.6;
  en.frame = 'heavy';
  en.score *= 8;
  en.speed *= 0.9; en.baseSpeed = en.speed;
  g.enemies.push(en);
  story(g, 'LÖJTNANT', `En ${en.name.toLowerCase()} har anslutit till vågen. Den tål mycket — och ger bra betalt.`);
  return en;
}
