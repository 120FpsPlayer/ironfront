/* =========================================================
   IRONFRONT — rendering
   Två principer styr allt här:
   1. En enda ljuskälla (LIGHT) — samma skuggriktning överallt
      gör att scenen hänger ihop istället för att se klippt ut.
   2. Det som inte ändras ritas en gång till en egen canvas.
      Mechar, terräng och hinder är förrenderade; bara rörelse,
      ljus och partiklar räknas om varje bildruta.
   ========================================================= */
import { LIGHT, WORLD } from './arena.js';
import { Fx, drawParticles, drawNumbers, drawScorches, drawLights } from './fx.js';
import { TAU, clamp, rgba, shade, mix } from './util.js';

let ctx = null, canvas = null, dpr = 1;
const spriteCache = new Map();

export function initRender(cv){
  canvas = cv;
  ctx = cv.getContext('2d', { alpha: false });
  resize();
  addEventListener('resize', resize);
  return ctx;
}

export function resize(){
  if (!canvas) return;
  dpr = Math.min(devicePixelRatio || 1, 2);
  const w = canvas.clientWidth || innerWidth;
  const h = canvas.clientHeight || innerHeight;
  canvas.width = Math.floor(w * dpr);
  canvas.height = Math.floor(h * dpr);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.imageSmoothingEnabled = true;
}
export const viewW = () => (canvas ? canvas.width / dpr : 1280);
export const viewH = () => (canvas ? canvas.height / dpr : 720);

/* =========================================================
   MECH-SPRITES
   Varje robot ritas en gång i full detalj till en egen canvas
   och roteras sedan som en bild. Det gör att vi har råd med
   panelfogar, kantljus och nitar utan att tappa bildrutor.
   ========================================================= */
function torsoSprite(kind, color, r, frame){
  const key = `t|${kind}|${color}|${r}|${frame}`;
  if (spriteCache.has(key)) return spriteCache.get(key);

  const S = Math.ceil(r * 4.2);
  const c = document.createElement('canvas');
  c.width = c.height = S;
  const g = c.getContext('2d');
  g.translate(S / 2, S / 2);

  const dark = shade(color, -0.55);
  const mid  = shade(color, -0.28);
  const lit  = shade(color, 0.22);
  const hot  = shade(color, 0.5);

  // --- Axelpartier, bakom bålen ---
  const shoulderW = frame === 'heavy' ? r * 0.92 : frame === 'light' ? r * 0.66 : r * 0.78;
  [-1, 1].forEach(side => {
    g.save();
    g.translate(-r * 0.05, side * r * 0.72);
    const grd = g.createLinearGradient(0, -shoulderW / 2, 0, shoulderW / 2);
    grd.addColorStop(0, side < 0 ? lit : mid);
    grd.addColorStop(1, side < 0 ? mid : dark);
    g.fillStyle = grd;
    poly(g, [
      [-r * 0.52, -shoulderW * 0.42], [r * 0.46, -shoulderW * 0.34],
      [r * 0.58, shoulderW * 0.30],  [-r * 0.46, shoulderW * 0.42]
    ]);
    g.fill();
    g.strokeStyle = 'rgba(0,0,0,.55)'; g.lineWidth = 1.4; g.stroke();
    // Ventilgaller
    g.strokeStyle = 'rgba(0,0,0,.4)'; g.lineWidth = 1;
    for (let i = -1; i <= 1; i++){
      g.beginPath();
      g.moveTo(-r * 0.3, i * shoulderW * 0.2);
      g.lineTo(r * 0.34, i * shoulderW * 0.2);
      g.stroke();
    }
    g.restore();
  });

  // --- Bål ---
  const bw = r * (frame === 'heavy' ? 1.30 : frame === 'light' ? 1.02 : 1.16);
  const bh = r * (frame === 'heavy' ? 1.08 : frame === 'light' ? 0.86 : 0.96);
  const body = [
    [-bw * 0.52, -bh * 0.54], [bw * 0.30, -bh * 0.62], [bw * 0.62, -bh * 0.26],
    [bw * 0.62,  bh * 0.26], [bw * 0.30,  bh * 0.62], [-bw * 0.52, bh * 0.54],
    [-bw * 0.66, 0]
  ];
  const bodyGrd = g.createLinearGradient(0, -bh * 0.7, 0, bh * 0.7);
  bodyGrd.addColorStop(0, lit);
  bodyGrd.addColorStop(0.42, mid);
  bodyGrd.addColorStop(1, dark);
  g.fillStyle = bodyGrd;
  poly(g, body); g.fill();
  g.strokeStyle = 'rgba(0,0,0,.6)'; g.lineWidth = 1.6; g.stroke();

  // Kantljus på den sida solen träffar
  g.save();
  poly(g, body); g.clip();
  g.strokeStyle = rgba('#ffffff', 0.30); g.lineWidth = 2.4;
  g.beginPath();
  g.moveTo(-bw * 0.52 + LIGHT.x * 3, -bh * 0.54 + LIGHT.y * 3);
  g.lineTo(bw * 0.30 + LIGHT.x * 3, -bh * 0.62 + LIGHT.y * 3);
  g.lineTo(bw * 0.62 + LIGHT.x * 3, -bh * 0.26 + LIGHT.y * 3);
  g.stroke();
  g.restore();

  // Panelfogar
  g.strokeStyle = 'rgba(0,0,0,.42)'; g.lineWidth = 1.1;
  g.beginPath();
  g.moveTo(-bw * 0.1, -bh * 0.58); g.lineTo(-bw * 0.1, bh * 0.58);
  g.moveTo(bw * 0.26, -bh * 0.6);  g.lineTo(bw * 0.26, bh * 0.6);
  g.stroke();

  // Nitar längs framkanten
  g.fillStyle = 'rgba(0,0,0,.35)';
  for (let i = -2; i <= 2; i++){
    g.beginPath(); g.arc(bw * 0.46, i * bh * 0.18, 1.3, 0, TAU); g.fill();
  }

  // --- Sensorhuvud med glödande springa ---
  const headR = r * 0.34;
  g.fillStyle = shade(color, -0.42);
  poly(g, [
    [bw * 0.12, -headR], [bw * 0.12 + headR * 1.5, -headR * 0.7],
    [bw * 0.12 + headR * 1.5, headR * 0.7], [bw * 0.12, headR]
  ]);
  g.fill();
  g.strokeStyle = 'rgba(0,0,0,.6)'; g.lineWidth = 1.2; g.stroke();
  g.fillStyle = hot;
  g.shadowColor = color; g.shadowBlur = 10;
  g.fillRect(bw * 0.12 + headR * 0.95, -headR * 0.46, headR * 0.5, headR * 0.92);
  g.shadowBlur = 0;

  spriteCache.set(key, { canvas: c, off: S / 2 });
  return spriteCache.get(key);
}

function legSprite(color, r, frame){
  const key = `l|${color}|${r}|${frame}`;
  if (spriteCache.has(key)) return spriteCache.get(key);
  const S = Math.ceil(r * 2.2);
  const c = document.createElement('canvas');
  c.width = c.height = S;
  const g = c.getContext('2d');
  g.translate(S / 2, S / 2);

  const w = r * (frame === 'heavy' ? 0.46 : 0.34);
  const l = r * (frame === 'heavy' ? 0.92 : 1.02);
  const grd = g.createLinearGradient(0, -w, 0, w);
  grd.addColorStop(0, shade(color, -0.18));
  grd.addColorStop(1, shade(color, -0.62));
  g.fillStyle = grd;
  poly(g, [[-l * 0.5, -w * 0.5], [l * 0.34, -w * 0.62], [l * 0.5, w * 0.2], [-l * 0.42, w * 0.6]]);
  g.fill();
  g.strokeStyle = 'rgba(0,0,0,.55)'; g.lineWidth = 1.2; g.stroke();
  // Fotplatta
  g.fillStyle = shade(color, -0.7);
  g.fillRect(l * 0.28, -w * 0.7, w * 0.9, w * 1.4);
  g.strokeRect(l * 0.28, -w * 0.7, w * 0.9, w * 1.4);

  spriteCache.set(key, { canvas: c, off: S / 2 });
  return spriteCache.get(key);
}

function poly(g, pts){
  g.beginPath();
  pts.forEach((p, i) => i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1]));
  g.closePath();
}

/**
 * Ritar en mech.
 * @param {object} m {x,y,angle,moveAngle,r,color,frame,walk,hpPct,shield,shieldHits,barrels}
 */
export function drawMech(g, m){
  const { x, y } = m, r = m.radius;
  const frame = m.frame || 'medium';

  // Markskugga — förskjuten mot ljuset, mjuk kant
  g.save();
  g.globalAlpha = 0.45;
  g.fillStyle = '#000';
  g.beginPath();
  g.ellipse(x - LIGHT.x * r * 0.42, y - LIGHT.y * r * 0.42 + r * 0.3, r * 0.94, r * 0.5, 0, 0, TAU);
  g.fill();
  g.restore();

  // Ben: följer färdriktningen, inte sikteriktningen
  const legAngle = m.moveAngle ?? m.angle;
  const leg = legSprite(m.color, r, frame);
  const stride = Math.sin(m.walk || 0) * r * 0.26;
  [-1, 1].forEach((side, i) => {
    const ofs = i === 0 ? stride : -stride;
    g.save();
    g.translate(x, y);
    g.rotate(legAngle);
    g.translate(ofs * 0.6, side * r * 0.52);
    g.drawImage(leg.canvas, -leg.off, -leg.off);
    g.restore();
  });

  // Bål
  const torso = torsoSprite(m.kind || 'mech', m.color, r, frame);
  g.save();
  g.translate(x, y);
  g.rotate(m.angle);
  // Liten gungning i takt med steg — roboten känns tung
  const bob = Math.sin((m.walk || 0) * 2) * r * 0.035;
  g.translate(bob, 0);

  // Vapenpipor ritas före bålen så att de sticker ut under axlarna
  if (m.barrels) for (const b of m.barrels){
    const off = b.offset || 0;
    g.save();
    g.translate(0, off);
    if (b.spread) g.rotate(0);
    const len = r * (b.heavy ? 1.34 : 1.12);
    const th  = r * (b.heavy ? 0.26 : 0.17);
    g.fillStyle = shade(m.color, -0.62);
    g.fillRect(r * 0.3, -th / 2, len, th);
    g.strokeStyle = 'rgba(0,0,0,.6)'; g.lineWidth = 1.1;
    g.strokeRect(r * 0.3, -th / 2, len, th);
    // Mynningsbroms
    g.fillStyle = shade(m.color, -0.34);
    g.fillRect(r * 0.3 + len - th * 0.8, -th * 0.78, th * 0.8, th * 1.56);
    g.restore();
  }

  g.drawImage(torso.canvas, -torso.off, -torso.off);

  // Skadeindikation: sotad plåt när skrovet är illa däran
  if (m.hpPct != null && m.hpPct < 0.55){
    g.globalAlpha = (0.55 - m.hpPct) * 0.9;
    g.fillStyle = '#0a0806';
    g.beginPath(); g.arc(0, 0, r * 0.9, 0, TAU); g.fill();
    g.globalAlpha = 1;
  }
  g.restore();

  // Sköldar
  if (m.shield) drawShield(g, m);
}

function drawShield(g, m){
  const s = m.shield, { x, y } = m, r = m.radius;
  if (s.type === 'purple' && s.active){
    const t = performance.now() / 1000;
    const pulse = 1 + Math.sin(t * 9) * 0.03;
    g.save();
    g.translate(x, y);
    g.beginPath(); g.arc(0, 0, (r + 14) * pulse, 0, TAU);
    g.fillStyle = rgba('#b07af0', 0.12); g.fill();
    g.strokeStyle = rgba('#d9b8ff', 0.9); g.lineWidth = 2.5;
    g.shadowColor = '#b07af0'; g.shadowBlur = 20; g.stroke();
    // Hexmönster som roterar långsamt
    g.rotate(t * 0.4);
    g.strokeStyle = rgba('#b07af0', 0.4); g.lineWidth = 1; g.shadowBlur = 0;
    for (let i = 0; i < 6; i++){
      const a = TAU * (i / 6);
      g.beginPath();
      g.moveTo(Math.cos(a) * (r + 4), Math.sin(a) * (r + 4));
      g.lineTo(Math.cos(a) * (r + 14), Math.sin(a) * (r + 14));
      g.stroke();
    }
    g.restore();
    return;
  }
  // Blå och gyllene sköldar är osynliga tills de träffas — bara
  // den träffade sektorn lyser upp, som ett riktigt fältskydd.
  if ((s.type === 'blue' || s.type === 'gold') && s.current > 0 && m.shieldHits?.length){
    const col = s.type === 'gold' ? '#f0a830' : '#5fd0f0';
    for (const hit of m.shieldHits){
      const t = clamp(hit.life / hit.max, 0, 1);
      const arc = 0.95;
      g.save();
      g.globalAlpha = t * 0.92;
      g.strokeStyle = col; g.lineWidth = 4.5;
      g.shadowColor = col; g.shadowBlur = 18 * t;
      g.beginPath();
      g.arc(x, y, r + 10, hit.angle - arc / 2, hit.angle + arc / 2);
      g.stroke();
      g.shadowBlur = 0;
      g.globalAlpha = t * 0.20;
      g.fillStyle = col;
      g.beginPath();
      g.arc(x, y, r + 10, hit.angle - arc / 2, hit.angle + arc / 2);
      g.arc(x, y, r + 2, hit.angle + arc / 2, hit.angle - arc / 2, true);
      g.closePath(); g.fill();
      g.restore();
    }
  }
}

/* =========================================================
   BOSS
   Större, tyngre silhuett med eget pansarlager och ringar
   som visar vilken arketyp det är.
   ========================================================= */
export function drawBoss(g, en){
  const { x, y } = en, r = en.radius;
  const t = performance.now() / 1000;

  g.save();
  g.globalAlpha = 0.5; g.fillStyle = '#000';
  g.beginPath();
  g.ellipse(x - LIGHT.x * r * 0.4, y - LIGHT.y * r * 0.4 + r * 0.25, r * 1.05, r * 0.6, 0, 0, TAU);
  g.fill();
  g.restore();

  g.save();
  g.translate(x, y);

  // Yttre pansarring, roterar mot bålen
  g.rotate(-t * 0.25);
  g.strokeStyle = rgba(en.color, 0.55); g.lineWidth = 3;
  for (let i = 0; i < 3; i++){
    g.beginPath();
    g.arc(0, 0, r * 1.14, TAU * (i / 3) + 0.2, TAU * (i / 3) + 1.4);
    g.stroke();
  }
  g.rotate(t * 0.25);

  // Bålen
  g.rotate(en.angle);
  const grd = g.createLinearGradient(0, -r, 0, r);
  grd.addColorStop(0, shade(en.color, 0.2));
  grd.addColorStop(0.45, shade(en.color, -0.25));
  grd.addColorStop(1, shade(en.color, -0.65));
  g.fillStyle = grd;
  g.beginPath();
  for (let i = 0; i < 8; i++){
    const a = TAU * (i / 8);
    const rr = r * (i % 2 ? 0.82 : 1.0);
    i ? g.lineTo(Math.cos(a) * rr, Math.sin(a) * rr) : g.moveTo(Math.cos(a) * rr, Math.sin(a) * rr);
  }
  g.closePath(); g.fill();
  g.strokeStyle = 'rgba(0,0,0,.7)'; g.lineWidth = 2.5; g.stroke();

  // Kärna som pulserar snabbare ju mer skadad bossen är
  const hurt = 1 - en.hp / en.maxHp;
  const pulse = 0.55 + Math.sin(t * (3 + hurt * 7)) * 0.3;
  g.fillStyle = rgba(en.color, 0.35 + pulse * 0.5);
  g.shadowColor = en.color; g.shadowBlur = 26 * pulse;
  g.beginPath(); g.arc(0, 0, r * 0.34, 0, TAU); g.fill();
  g.shadowBlur = 0;

  // Dubbla pipor
  [-1, 1].forEach(s => {
    g.fillStyle = shade(en.color, -0.7);
    g.fillRect(r * 0.5, s * r * 0.34 - r * 0.09, r * 0.85, r * 0.18);
  });

  // Varning innan specialattack — spelaren ska hinna reagera
  if (en.tellLeft > 0){
    const k = 1 - en.tellLeft / en.tellTotal;
    g.rotate(-en.angle);
    g.strokeStyle = rgba('#ff3b2f', 0.35 + k * 0.5);
    g.lineWidth = 3 + k * 4;
    g.beginPath(); g.arc(0, 0, r * (1.35 + k * 0.5), 0, TAU * k);
    g.stroke();
  }
  g.restore();
}

/* =========================================================
   HINDER
   ========================================================= */
export function drawObstacleShadow(g, o){
  g.fillStyle = 'rgba(0,0,0,.42)';
  const dx = -LIGHT.x * 16, dy = -LIGHT.y * 16;
  g.fillRect(o.x + dx, o.y + dy, o.w, o.h);
}

export function drawObstacle(g, o, map){
  if (o.hp <= 0) return;
  const base = map.rock;

  if (o.type === 'rock' && o.poly){
    g.save();
    g.translate(o.x + o.w / 2, o.y + o.h / 2);
    const grd = g.createLinearGradient(0, -o.h / 2, 0, o.h / 2);
    grd.addColorStop(0, shade(base, 0.22));
    grd.addColorStop(0.5, base);
    grd.addColorStop(1, shade(base, -0.45));
    g.fillStyle = grd;
    g.beginPath();
    o.poly.forEach((p, i) => i ? g.lineTo(p.x, p.y) : g.moveTo(p.x, p.y));
    g.closePath(); g.fill();
    g.strokeStyle = 'rgba(0,0,0,.5)'; g.lineWidth = 2; g.stroke();
    // Ett par facetter så stenen får volym
    g.strokeStyle = rgba('#ffffff', 0.10); g.lineWidth = 1.5;
    g.beginPath();
    g.moveTo(o.poly[0].x, o.poly[0].y);
    g.lineTo(0, -o.h * 0.1);
    g.lineTo(o.poly[2].x, o.poly[2].y);
    g.stroke();
    g.restore();
    return;
  }

  if (o.type === 'crate'){
    const hurt = 1 - o.hp / o.maxHp;
    g.fillStyle = mix('#5a4326', '#2a1d10', hurt);
    g.fillRect(o.x, o.y, o.w, o.h);
    g.strokeStyle = '#1a1208'; g.lineWidth = 2;
    g.strokeRect(o.x + 1, o.y + 1, o.w - 2, o.h - 2);
    g.strokeStyle = rgba('#ffffff', 0.13); g.lineWidth = 1.5;
    g.beginPath();
    g.moveTo(o.x + 3, o.y + 3); g.lineTo(o.x + o.w - 3, o.y + 3);
    g.moveTo(o.x + 3, o.y + 3); g.lineTo(o.x + 3, o.y + o.h - 3);
    g.stroke();
    // Korsband + varningsstreck
    g.strokeStyle = rgba('#ff8a3c', 0.55); g.lineWidth = 2;
    g.beginPath();
    g.moveTo(o.x + 4, o.y + o.h / 2); g.lineTo(o.x + o.w - 4, o.y + o.h / 2);
    g.stroke();
    if (hurt > 0.3){
      g.strokeStyle = rgba('#000000', 0.5); g.lineWidth = 1;
      g.beginPath();
      g.moveTo(o.x + o.w * 0.2, o.y); g.lineTo(o.x + o.w * 0.55, o.y + o.h);
      g.stroke();
    }
    return;
  }

  if (o.type === 'pylon'){
    const t = performance.now() / 700;
    g.fillStyle = shade(base, -0.4);
    g.fillRect(o.x, o.y, o.w, o.h);
    g.strokeStyle = 'rgba(0,0,0,.6)'; g.lineWidth = 2;
    g.strokeRect(o.x, o.y, o.w, o.h);
    const glow = 0.4 + Math.sin(t) * 0.3;
    g.fillStyle = rgba(map.accent, glow);
    g.shadowColor = map.accent; g.shadowBlur = 16 * glow;
    g.fillRect(o.x + o.w * 0.3, o.y + o.h * 0.15, o.w * 0.4, o.h * 0.7);
    g.shadowBlur = 0;
    return;
  }

  // Murar, ruiner och värn
  const grd = g.createLinearGradient(o.x, o.y, o.x, o.y + o.h);
  grd.addColorStop(0, shade(base, 0.16));
  grd.addColorStop(0.35, base);
  grd.addColorStop(1, shade(base, -0.5));
  g.fillStyle = grd;
  g.fillRect(o.x, o.y, o.w, o.h);

  // Överkant fångar ljuset
  g.fillStyle = rgba('#ffffff', 0.09);
  g.fillRect(o.x, o.y, o.w, 3);
  g.strokeStyle = 'rgba(0,0,0,.55)'; g.lineWidth = 2;
  g.strokeRect(o.x, o.y, o.w, o.h);

  // Betongfogar — mängden beror på ytans storlek, aldrig slumpad per bildruta
  g.strokeStyle = 'rgba(0,0,0,.28)'; g.lineWidth = 1;
  const step = 46;
  g.beginPath();
  if (o.w > o.h){
    for (let x = o.x + step; x < o.x + o.w; x += step){ g.moveTo(x, o.y + 3); g.lineTo(x, o.y + o.h - 3); }
  } else {
    for (let y = o.y + step; y < o.y + o.h; y += step){ g.moveTo(o.x + 3, y); g.lineTo(o.x + o.w - 3, y); }
  }
  g.stroke();

  if (o.type === 'barrier'){
    // Gula fältmarkeringar på försvarsvärnen
    g.save();
    g.beginPath(); g.rect(o.x, o.y, o.w, o.h); g.clip();
    g.strokeStyle = rgba('#e8a53e', 0.28); g.lineWidth = 7;
    for (let i = -o.h; i < o.w + o.h; i += 22){
      g.beginPath(); g.moveTo(o.x + i, o.y + o.h); g.lineTo(o.x + i + o.h, o.y); g.stroke();
    }
    g.restore();
  }
}

/* =========================================================
   PROJEKTILER
   ========================================================= */
export function drawProjectiles(g, list){
  for (const p of list){
    const sp = Math.hypot(p.vx, p.vy) || 1;
    const len = p.trail || 10;
    const bx = p.x - (p.vx / sp) * len, by = p.y - (p.vy / sp) * len;

    const grd = g.createLinearGradient(bx, by, p.x, p.y);
    grd.addColorStop(0, rgba(p.color, 0));
    grd.addColorStop(1, p.color);
    g.strokeStyle = grd;
    g.lineWidth = (p.size || 3) * 0.8;
    g.lineCap = 'round';
    g.beginPath(); g.moveTo(bx, by); g.lineTo(p.x, p.y); g.stroke();

    g.fillStyle = '#fff';
    g.beginPath(); g.arc(p.x, p.y, (p.size || 3) * 0.45, 0, TAU); g.fill();
    g.fillStyle = p.color;
    g.globalAlpha = 0.7;
    g.beginPath(); g.arc(p.x, p.y, p.size || 3, 0, TAU); g.fill();
    g.globalAlpha = 1;
  }
}

/* =========================================================
   MARKMARKÖRER — varningar innan nedslag
   ========================================================= */
export function drawMarkers(g, markers){
  for (const m of markers){
    const k = 1 - m.left / m.total;
    g.save();
    g.translate(m.x, m.y);
    g.strokeStyle = rgba('#ff3b2f', 0.35 + k * 0.5);
    g.lineWidth = 2;
    g.beginPath(); g.arc(0, 0, m.r, 0, TAU); g.stroke();
    g.fillStyle = rgba('#ff3b2f', 0.10 + k * 0.16);
    g.beginPath(); g.arc(0, 0, m.r * k, 0, TAU); g.fill();
    g.strokeStyle = rgba('#ff3b2f', 0.6);
    g.beginPath();
    g.moveTo(-m.r * 0.5, 0); g.lineTo(m.r * 0.5, 0);
    g.moveTo(0, -m.r * 0.5); g.lineTo(0, m.r * 0.5);
    g.stroke();
    g.restore();
  }
}

/* =========================================================
   UPPLOCKBART
   ========================================================= */
const PICKUP_COLOR = { repair: '#58c98a', ammo: '#e8b33c', shield: '#5fb3d4', crate: '#ff8a3c' };
export function drawPickups(g, list){
  const t = performance.now() / 1000;
  for (const p of list){
    const bob = Math.sin(t * 3 + p.x * 0.01) * 3;
    const col = PICKUP_COLOR[p.kind] || '#fff';
    g.save();
    g.translate(p.x, p.y + bob);
    g.globalAlpha = 0.35;
    g.fillStyle = '#000';
    g.beginPath(); g.ellipse(0, 10 - bob, 11, 5, 0, 0, TAU); g.fill();
    g.globalAlpha = 1;
    g.rotate(t * 0.8);
    g.fillStyle = shade(col, -0.5);
    g.fillRect(-8, -8, 16, 16);
    g.strokeStyle = col; g.lineWidth = 2;
    g.shadowColor = col; g.shadowBlur = 12;
    g.strokeRect(-8, -8, 16, 16);
    g.shadowBlur = 0;
    g.fillStyle = col;
    g.fillRect(-3, -3, 6, 6);
    g.restore();
  }
}

/* =========================================================
   HELA SCENEN
   ========================================================= */
export function renderScene(game){
  const g = ctx, cam = game.camera, map = game.arena.map;
  const vw = viewW(), vh = viewH();

  g.fillStyle = map.sky;
  g.fillRect(0, 0, vw, vh);

  g.save();
  g.translate(-cam.x + Fx.shakeX, -cam.y + Fx.shakeY);

  const x0 = cam.x - 60, y0 = cam.y - 60, x1 = cam.x + vw + 60, y1 = cam.y + vh + 60;

  /* --- Mark --- */
  if (!game._pattern) game._pattern = g.createPattern(game.arena.tile, 'repeat');
  g.fillStyle = game._pattern;
  g.fillRect(x0, y0, x1 - x0, y1 - y0);

  // Storskalig ljussättning över marken — mjuka fläckar av ljus och mörker
  const lg = g.createRadialGradient(
    WORLD.w * 0.32, WORLD.h * 0.22, 0,
    WORLD.w * 0.32, WORLD.h * 0.22, WORLD.w * 0.62);
  lg.addColorStop(0, rgba('#ffffff', 0.05));
  lg.addColorStop(1, 'rgba(0,0,0,0)');
  g.fillStyle = lg;
  g.fillRect(x0, y0, x1 - x0, y1 - y0);
  g.fillStyle = rgba(map.deep, 0.38);
  const dg = g.createRadialGradient(
    WORLD.w * 0.5, WORLD.h * 0.5, WORLD.w * 0.28,
    WORLD.w * 0.5, WORLD.h * 0.5, WORLD.w * 0.72);
  dg.addColorStop(0, 'rgba(0,0,0,0)');
  dg.addColorStop(1, rgba(map.deep, 0.75));
  g.fillStyle = dg;
  g.fillRect(x0, y0, x1 - x0, y1 - y0);

  /* --- Dekaler --- */
  for (const d of game.arena.decals){
    if (d.x + d.r < x0 || d.x - d.r > x1 || d.y + d.r < y0 || d.y - d.r > y1) continue;
    g.save();
    g.translate(d.x, d.y); g.rotate(d.rot);
    g.globalAlpha = d.a;
    if (d.kind === 'scorch'){
      const rg = g.createRadialGradient(0, 0, 0, 0, 0, d.r);
      rg.addColorStop(0, 'rgba(12,9,7,.9)');
      rg.addColorStop(1, 'rgba(0,0,0,0)');
      g.fillStyle = rg;
      g.beginPath(); g.ellipse(0, 0, d.r, d.r * 0.7, 0, 0, TAU); g.fill();
    } else if (d.kind === 'plate'){
      g.strokeStyle = rgba(map.rock, 0.6); g.lineWidth = 2;
      g.strokeRect(-d.r / 2, -d.r / 3, d.r, d.r * 0.66);
      g.fillStyle = rgba(map.rock, 0.16);
      g.fillRect(-d.r / 2, -d.r / 3, d.r, d.r * 0.66);
    } else if (d.kind === 'mark'){
      g.strokeStyle = rgba(map.accent, 0.5); g.lineWidth = 3;
      g.beginPath();
      g.moveTo(-d.r / 2, -d.r / 4); g.lineTo(-d.r / 2, d.r / 4);
      g.moveTo(d.r / 2, -d.r / 4);  g.lineTo(d.r / 2, d.r / 4);
      g.stroke();
    } else {
      g.strokeStyle = 'rgba(0,0,0,.5)'; g.lineWidth = 1.4;
      g.beginPath();
      g.moveTo(-d.r / 2, 0);
      g.lineTo(-d.r / 6, d.r * 0.1);
      g.lineTo(d.r / 5, -d.r * 0.08);
      g.lineTo(d.r / 2, d.r * 0.04);
      g.stroke();
    }
    g.restore();
  }
  g.globalAlpha = 1;

  drawScorches(g);

  /* --- Hinder: alla skuggor först, sedan alla kroppar --- */
  const vis = game.arena.obstacles.filter(o =>
    o.hp > 0 && o.x < x1 && o.x + o.w > x0 && o.y < y1 && o.y + o.h > y0);
  for (const o of vis) if (o.type !== 'rock') drawObstacleShadow(g, o);
  vis.sort((a, b) => a.y - b.y);
  for (const o of vis) drawObstacle(g, o, map);

  /* --- Markvarningar under allt rörligt --- */
  drawMarkers(g, game.markers);
  drawPickups(g, game.pickups);

  /* --- Rök bakom robotarna --- */
  drawParticles(g);

  /* --- Händelsemål: laddningar och störsändare ---
     De fanns bara på radarn tidigare — nu syns de i världen. */
  if (game.event?.objects && game.event.type !== 'supply') drawEventObjects(g, game.event);

  /* --- Sensorpuls: ringen som sveper ut, och märkta fiender --- */
  const scanning = game.player.scan?.active;
  if (game.scanWave){
    const w = game.scanWave;
    const a = Math.max(0, 1 - w.r / 2400);
    g.strokeStyle = rgba('#8fd3e6', 0.55 * a); g.lineWidth = 4;
    g.beginPath(); g.arc(w.x, w.y, w.r, 0, TAU); g.stroke();
    g.strokeStyle = rgba('#8fd3e6', 0.18 * a); g.lineWidth = 18;
    g.beginPath(); g.arc(w.x, w.y, w.r - 10, 0, TAU); g.stroke();
  }

  /* --- Fiender, lagkamrater och spelare, sorterade i djupled --- */
  const actors = [...game.enemies];
  if (game.allies) for (const al of game.allies) if (al.hp > 0) actors.push(al);
  if (game.player.hp > 0) actors.push(game.player);
  actors.sort((a, b) => a.y - b.y);
  for (const a of actors){
    if (!Number.isFinite(a.x) || !Number.isFinite(a.y)) continue;   // en trasig position får inte krascha ritningen
    if (a.cloak){ g.globalAlpha = 0.12; drawMech(g, a); g.globalAlpha = 1; continue; }   // smygare: nästan osynlig
    if (a.isBoss) drawBoss(g, a);
    else drawMech(g, a);
    if (a.isAlly){ drawAllyTag(g, a); drawNameTag(g, a, a.y - a.radius - 30); }
    else if (a === game.player) drawNameTag(g, a, a.y - a.radius - 16);
    else { drawEnemyBars(g, a); if (a.elite) drawEliteTag(g, a); if (a.miniboss) drawMinibossTag(g, a); }
    if (scanning && !a.isPlayer && !a.isAlly) drawScanMark(g, a);
  }

  /* --- Utslagna lagkamrater: vrak och återupplivningsring --- */
  if (game.coop) for (const a of [game.player, ...(game.allies || [])]) if (a.hp <= 0) drawDowned(g, a);

  /* --- Markeringar (ping) --- */
  if (game.pings?.length) drawPings(g, game.pings);

  /* --- Projektiler och ljus --- */
  drawProjectiles(g, game.projectiles);
  drawLights(g, game.projectiles);
  drawNumbers(g);

  g.restore();

  // Skadeindikator: röda bågar mot skärmkanten åt det håll skotten kom ifrån
  if (game.hitMarks?.length) drawHitMarks(g, game, vw, vh);
  // Markeringar utanför bild får en pil i sin färg
  if (game.pings?.length) drawPingArrows(g, game.pings, cam, vw, vh);

  // Pilar vid skärmkanten mot händelsemål som ligger utanför bild
  if (game.event?.objects && game.event.type !== 'supply') drawEventArrows(g, game.event, cam, vw, vh);

  // Blixt vid stora explosioner
  if (Fx.flash > 0.01){
    g.fillStyle = rgba('#ffd3a8', Fx.flash * 0.35);
    g.fillRect(0, 0, vw, vh);
  }
}

/* ---------------------------------------------------------
   HÄNDELSEMÅL
   Laddning (sabotage): en låda med blinkande lampa och en
   ring som tickar ned med tiden som är kvar.
   Störsändare: en mast med pulserande vågor.
   Båda har livmätare och en etikett så att man ser vad
   som ska skjutas sönder.
   --------------------------------------------------------- */
function drawEventObjects(g, ev){
  const t = performance.now();
  const color = ev.def.color;
  const frac = Math.max(0, ev.left / ev.def.time);
  for (const o of ev.objects){
    if (o.hp <= 0) continue;
    const { x, y } = o;
    // Markering på marken
    const pulse = 0.5 + 0.5 * Math.sin(t / 220 + x);
    g.strokeStyle = rgba(color, 0.25 + 0.35 * pulse); g.lineWidth = 2;
    g.beginPath(); g.arc(x, y, o.radius + 16 + pulse * 6, 0, TAU); g.stroke();

    if (ev.type === 'bomb'){
      // Tidsring: krymper när tiden rinner ut
      g.strokeStyle = rgba(color, 0.9); g.lineWidth = 4;
      g.beginPath(); g.arc(x, y, o.radius + 8, -Math.PI / 2, -Math.PI / 2 + TAU * frac); g.stroke();
      // Själva laddningen
      g.fillStyle = 'rgba(0,0,0,.45)'; g.fillRect(x - 16, y - 10, 34, 26);
      g.fillStyle = '#3a3f46'; g.fillRect(x - 18, y - 13, 36, 26);
      g.fillStyle = '#2a2e33'; g.fillRect(x - 18, y + 5, 36, 8);
      g.fillStyle = '#c9a23a';
      for (let i = -12; i <= 8; i += 10) g.fillRect(x + i, y - 13, 4, 26);   // tejp/band
      // Blinkande lampa — snabbare ju mindre tid som är kvar
      const blink = Math.sin(t / (60 + 240 * frac)) > 0;
      g.fillStyle = blink ? '#ff3b2f' : '#5a1510';
      g.beginPath(); g.arc(x, y - 1, 4, 0, TAU); g.fill();
      if (blink){ g.fillStyle = 'rgba(255,59,47,.35)'; g.beginPath(); g.arc(x, y - 1, 11, 0, TAU); g.fill(); }
    } else {
      // Störsändare: fot, mast och vågor
      for (let k = 0; k < 3; k++){
        const r = ((t / 18 + k * 40) % 120);
        g.strokeStyle = rgba(color, 0.5 * (1 - r / 120)); g.lineWidth = 2;
        g.beginPath(); g.arc(x, y - 20, 8 + r, 0, TAU); g.stroke();
      }
      g.fillStyle = 'rgba(0,0,0,.45)'; g.beginPath(); g.ellipse(x + 3, y + 6, 20, 9, 0, 0, TAU); g.fill();
      g.fillStyle = '#34303d'; g.fillRect(x - 16, y - 6, 32, 14);
      g.fillStyle = '#4b4459'; g.fillRect(x - 4, y - 30, 8, 26);
      g.strokeStyle = '#6b6180'; g.lineWidth = 2;
      g.beginPath(); g.moveTo(x - 12, y - 24); g.lineTo(x + 12, y - 24); g.moveTo(x - 8, y - 30); g.lineTo(x + 8, y - 30); g.stroke();
      g.fillStyle = Math.sin(t / 120) > 0 ? color : shade(color, -0.5);
      g.beginPath(); g.arc(x, y - 33, 4, 0, TAU); g.fill();
    }

    // Livmätare och etikett
    const w = 48, by = y - o.radius - 26;
    g.fillStyle = 'rgba(0,0,0,.6)'; g.fillRect(x - w / 2, by, w, 5);
    g.fillStyle = color; g.fillRect(x - w / 2, by, w * Math.max(0, o.hp / o.maxHp), 5);
    g.font = '700 10px Oxanium, sans-serif'; g.textAlign = 'center';
    g.fillStyle = 'rgba(0,0,0,.7)'; g.fillText(ev.type === 'bomb' ? 'LADDNING' : 'STÖRSÄNDARE', x + 1, by - 5);
    g.fillStyle = color; g.fillText(ev.type === 'bomb' ? 'LADDNING' : 'STÖRSÄNDARE', x, by - 6);
    g.textAlign = 'left';
  }
}

/** Elitfiende: guldring och namnet på egenskapen. */
function drawEliteTag(g, en){
  const t = performance.now();
  g.strokeStyle = `rgba(255,211,90,${0.45 + 0.3 * Math.sin(t / 200 + en.x)})`; g.lineWidth = 2.5;
  g.beginPath(); g.arc(en.x, en.y, en.radius + 7, 0, TAU); g.stroke();
  g.font = '700 10px Oxanium, sans-serif'; g.textAlign = 'center';
  const y = en.y - en.radius - 20;
  g.fillStyle = 'rgba(0,0,0,.7)'; g.fillText('ELIT · ' + en.elite.toUpperCase(), en.x + 1, y + 1);
  g.fillStyle = '#ffd35a'; g.fillText('ELIT · ' + en.elite.toUpperCase(), en.x, y);
  g.textAlign = 'left';
}

/** Utslagen robot i co-op: grå, med en ring som fylls när någon återupplivar. */
function drawDowned(g, a){
  g.globalAlpha = 0.45; drawMech(g, a); g.globalAlpha = 1;
  const t = performance.now();
  const pct = Math.min(1, (a.reviveT || 0) / 3000);
  g.strokeStyle = 'rgba(88,201,138,.25)'; g.lineWidth = 4;
  g.beginPath(); g.arc(a.x, a.y, 44, 0, TAU); g.stroke();
  if (pct > 0){
    g.strokeStyle = '#58c98a'; g.lineWidth = 5;
    g.beginPath(); g.arc(a.x, a.y, 44, -Math.PI / 2, -Math.PI / 2 + TAU * pct); g.stroke();
  }
  g.font = '800 11px Oxanium, sans-serif'; g.textAlign = 'center';
  const txt = pct > 0 ? 'ÅTERUPPLIVAR…' : 'UTSLAGEN — STÅ HÄR FÖR ATT HJÄLPA';
  g.fillStyle = 'rgba(0,0,0,.7)'; g.fillText(txt, a.x + 1, a.y - 53);
  g.fillStyle = pct > 0 ? '#58c98a' : `rgba(255,120,110,${0.7 + 0.3 * Math.sin(t / 200)})`; g.fillText(txt, a.x, a.y - 54);
  if (a.tag){ g.fillStyle = '#fff'; g.font = '700 12px Oxanium, sans-serif'; g.fillText(a.tag, a.x, a.y - 68); }
  g.textAlign = 'left';
}

/** Miniboss: namn och en bredare livmätare. */
function drawMinibossTag(g, en){
  const w = 90, y = en.y - en.radius - 26;
  g.fillStyle = 'rgba(0,0,0,.65)'; g.fillRect(en.x - w / 2, y, w, 6);
  g.fillStyle = '#ff8a3c'; g.fillRect(en.x - w / 2, y, w * Math.max(0, en.hp / en.maxHp), 6);
  g.font = '800 11px Oxanium, sans-serif'; g.textAlign = 'center';
  g.fillStyle = 'rgba(0,0,0,.7)'; g.fillText(en.name.toUpperCase(), en.x + 1, y - 5);
  g.fillStyle = '#ff9a5c'; g.fillText(en.name.toUpperCase(), en.x, y - 6);
  g.textAlign = 'left';
}

/** Markering i världen: pulserande ring, en pinne och texten. */
function drawPings(g, pings){
  const t = performance.now();
  for (const p of pings){
    const a = Math.min(1, p.t / 600);
    const r = 16 + 6 * Math.sin(t / 140);
    g.strokeStyle = rgba(p.color, 0.9 * a); g.lineWidth = 3;
    g.beginPath(); g.arc(p.x, p.y, r, 0, TAU); g.stroke();
    g.strokeStyle = rgba(p.color, 0.35 * a); g.lineWidth = 2;
    g.beginPath(); g.arc(p.x, p.y, r + 12 + ((4500 - p.t) / 30) % 30, 0, TAU); g.stroke();
    g.fillStyle = rgba(p.color, a);
    g.beginPath(); g.moveTo(p.x, p.y - 8); g.lineTo(p.x - 7, p.y - 30); g.lineTo(p.x + 7, p.y - 30); g.closePath(); g.fill();
    g.font = '800 12px Oxanium, sans-serif'; g.textAlign = 'center';
    g.fillStyle = `rgba(0,0,0,${0.7 * a})`; g.fillText(p.label, p.x + 1, p.y - 37);
    g.fillStyle = rgba(p.color, a); g.fillText(p.label, p.x, p.y - 38);
    g.font = '600 10px Oxanium, sans-serif'; g.fillStyle = `rgba(232,240,246,${0.85 * a})`;
    g.fillText(p.who, p.x, p.y - 51);
    g.textAlign = 'left';
  }
}

function drawPingArrows(g, pings, cam, vw, vh){
  const mx = 60, top = 120, bottom = 170;
  const cx = vw / 2, cy = (top + vh - bottom) / 2, hw = vw / 2 - mx, hh = (vh - bottom - top) / 2;
  for (const p of pings){
    const sx = p.x - cam.x, sy = p.y - cam.y;
    if (sx > 0 && sx < vw && sy > 0 && sy < vh) continue;
    const a = Math.atan2(sy - cy, sx - cx);
    const k = Math.min(Math.abs(hw / Math.cos(a)), Math.abs(hh / Math.sin(a)));
    g.save(); g.translate(cx + Math.cos(a) * k, cy + Math.sin(a) * k); g.rotate(a);
    g.fillStyle = p.color; g.beginPath(); g.moveTo(14, 0); g.lineTo(-8, -9); g.lineTo(-8, 9); g.closePath(); g.fill();
    g.restore();
  }
}

function drawHitMarks(g, game, vw, vh){
  const p = game.player, cam = game.camera;
  const px = p.x - cam.x, py = p.y - cam.y;
  const R = Math.min(vw, vh) * 0.42;
  for (const m of game.hitMarks){
    const a = m.t / 900;
    g.strokeStyle = `rgba(255,60,50,${0.75 * a})`; g.lineWidth = 10;
    g.beginPath(); g.arc(px, py, R, m.a - 0.32, m.a + 0.32); g.stroke();
  }
}

/** Pilar längs skärmkanten som pekar mot mål utanför bild, med avstånd. */
function drawEventArrows(g, ev, cam, vw, vh){
  // Pilarna håller sig innanför en ruta som undviker HUD:en uppe och nere
  const mx = 60, top = 120, bottom = 170;
  const cx = vw / 2, cy = (top + vh - bottom) / 2;
  const hw = vw / 2 - mx, hh = (vh - bottom - top) / 2;
  for (const o of ev.objects){
    if (o.hp <= 0) continue;
    const sx = o.x - cam.x, sy = o.y - cam.y;
    if (sx > 0 && sx < vw && sy > 0 && sy < vh) continue;          // syns redan
    const a = Math.atan2(sy - cy, sx - cx);
    const k = Math.min(Math.abs(hw / Math.cos(a)), Math.abs(hh / Math.sin(a)));
    const ax = cx + Math.cos(a) * k, ay = cy + Math.sin(a) * k;
    g.save();
    g.translate(ax, ay); g.rotate(a);
    g.fillStyle = ev.def.color;
    g.shadowColor = 'rgba(0,0,0,.8)'; g.shadowBlur = 6;
    g.beginPath(); g.moveTo(14, 0); g.lineTo(-8, -10); g.lineTo(-3, 0); g.lineTo(-8, 10); g.closePath(); g.fill();
    g.restore();
    const d = Math.round(Math.hypot(sx - cx, sy - cy) / 10);
    g.font = '700 10px Oxanium, sans-serif'; g.textAlign = 'center';
    g.fillStyle = 'rgba(0,0,0,.7)'; g.fillText(d + ' m', ax - Math.cos(a) * 22 + 1, ay - Math.sin(a) * 22 + 5);
    g.fillStyle = '#fff'; g.fillText(d + ' m', ax - Math.cos(a) * 22, ay - Math.sin(a) * 22 + 4);
    g.textAlign = 'left';
  }
}

/** Märkning från sensorpulsen: fyra hörn runt fienden. */
function drawScanMark(g, en){
  const r = en.radius + 10, k = 8;
  g.strokeStyle = 'rgba(143,211,230,.85)'; g.lineWidth = 2;
  g.beginPath();
  for (const [sx, sy] of [[-1,-1],[1,-1],[1,1],[-1,1]]){
    g.moveTo(en.x + sx * r, en.y + sy * (r - k)); g.lineTo(en.x + sx * r, en.y + sy * r); g.lineTo(en.x + sx * (r - k), en.y + sy * r);
  }
  g.stroke();
}

/** Livmätare under namnet på en lagkamrat i co-op. */
function drawAllyTag(g, al){
  const w = 46, y = al.y - al.radius - 14;
  g.fillStyle = 'rgba(0,0,0,.6)'; g.fillRect(al.x - w / 2, y, w, 4);
  g.fillStyle = '#58c98a'; g.fillRect(al.x - w / 2, y, w * Math.max(0, al.hp / al.maxHp), 4);
}

/** Användarnamn med titeln under, över en spelarrobot. Den högsta
    titeln får en pulserande aura. */
export function drawNameTag(g, a, y, scale = 1){
  if (!a.tag) return;
  const rank = a.rank;
  g.save();
  g.textAlign = 'center';
  g.textBaseline = 'alphabetic';
  // Titel (närmast roboten)
  if (rank){
    g.font = `600 ${Math.round(10 * scale)}px Oxanium, sans-serif`;
    if (rank.aura){
      const pulse = 0.6 + 0.4 * Math.sin(performance.now() / 280);
      g.shadowColor = rank.color;
      g.shadowBlur = 10 + 8 * pulse;
    }
    g.fillStyle = 'rgba(0,0,0,.65)';
    g.fillText(rank.name.toUpperCase(), a.x + 1, y + 1);
    g.fillStyle = rank.color;
    g.fillText(rank.name.toUpperCase(), a.x, y);
    g.shadowBlur = 0;
  }
  // Namn (ovanför titeln)
  const ny = y - Math.round(13 * scale);
  g.font = `700 ${Math.round(13 * scale)}px Oxanium, sans-serif`;
  g.fillStyle = 'rgba(0,0,0,.7)';
  g.fillText(a.tag, a.x + 1, ny + 1);
  g.fillStyle = a.isAlly ? '#bff0d2' : '#ffffff';
  g.fillText(a.tag, a.x, ny);
  g.restore();
}

function drawEnemyBars(g, en){
  if (en.isBoss) return;                  // bossen har egen mätare i HUD:en
  const w = 38, x = en.x - w / 2, y = en.y - en.radius - 16;
  if (en.hp < en.maxHp){
    g.fillStyle = 'rgba(0,0,0,.7)';
    g.fillRect(x - 1, y - 1, w + 2, 5);
    g.fillStyle = en.hp / en.maxHp > 0.35 ? '#e24a44' : '#ff7a3c';
    g.fillRect(x, y, w * clamp(en.hp / en.maxHp, 0, 1), 3);
  }
  if (en.shield?.current > 0){
    g.fillStyle = 'rgba(0,0,0,.7)';
    g.fillRect(x - 1, y - 6, w + 2, 4);
    g.fillStyle = '#5fb3d4';
    g.fillRect(x, y - 5, w * clamp(en.shield.current / en.shield.capacity, 0, 1), 2);
  }
}

/* =========================================================
   HANGARVYN
   Samma ritrutiner används för den stora roboten i hangaren,
   så det man ser i menyn är exakt det man tar med i strid.
   ========================================================= */
export function drawHangarMech(g, opts){
  const { w, h, tpl, t, scale = 1 } = opts;
  g.clearRect(0, 0, w, h);

  const cx = w / 2, cy = h * 0.54;
  const r = Math.min(w, h) * 0.17 * scale;

  // Golvpöl av ljus under roboten
  const pool = g.createRadialGradient(cx, cy + r * 0.6, 0, cx, cy + r * 0.6, r * 3.4);
  pool.addColorStop(0, rgba(tpl.color, 0.16));
  pool.addColorStop(0.45, rgba('#2a4258', 0.10));
  pool.addColorStop(1, 'rgba(0,0,0,0)');
  g.fillStyle = pool;
  g.fillRect(0, 0, w, h);

  // Golvring med teknisk gradering
  g.save();
  g.translate(cx, cy + r * 0.9);
  g.scale(1, 0.34);
  g.strokeStyle = rgba('#4a6c8c', 0.4); g.lineWidth = 1.5;
  g.beginPath(); g.arc(0, 0, r * 2.4, 0, TAU); g.stroke();
  g.strokeStyle = rgba('#ff5a1e', 0.35); g.lineWidth = 2;
  g.beginPath(); g.arc(0, 0, r * 2.4, t * 0.4, t * 0.4 + 1.1); g.stroke();
  g.strokeStyle = rgba('#4a6c8c', 0.22); g.lineWidth = 1;
  for (let i = 0; i < 24; i++){
    const a = TAU * (i / 24);
    g.beginPath();
    g.moveTo(Math.cos(a) * r * 2.2, Math.sin(a) * r * 2.2);
    g.lineTo(Math.cos(a) * r * 2.5, Math.sin(a) * r * 2.5);
    g.stroke();
  }
  g.restore();

  // Roboten vänder sig långsamt så att man ser silhuetten
  const sway = Math.sin(t * 0.5) * 0.30;
  drawMech(g, {
    x: cx, y: cy, angle: -Math.PI / 2 + sway, moveAngle: -Math.PI / 2 + sway * 0.6,
    radius: r, color: tpl.color, frame: tpl.frame, walk: Math.sin(t * 1.2) * 0.4,
    kind: 'hangar-' + tpl.id, hpPct: 1,
    barrels: tpl.mounts.map(m => ({ offset: (m.offset || 0) * (r / 22), heavy: tpl.frame === 'heavy' }))
  });

  // Måttlinjer — visar att roboten är ett föremål med storlek
  g.strokeStyle = rgba('#4a6c8c', 0.35); g.lineWidth = 1;
  g.setLineDash([4, 5]);
  g.beginPath();
  g.moveTo(cx + r * 2.0, cy - r * 1.3); g.lineTo(cx + r * 3.0, cy - r * 1.3);
  g.moveTo(cx + r * 2.0, cy + r * 1.3); g.lineTo(cx + r * 3.0, cy + r * 1.3);
  g.moveTo(cx + r * 2.8, cy - r * 1.3); g.lineTo(cx + r * 2.8, cy + r * 1.3);
  g.stroke();
  g.setLineDash([]);
}

export const getCtx = () => ctx;
