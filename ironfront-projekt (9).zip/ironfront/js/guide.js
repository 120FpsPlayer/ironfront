/* =========================================================
   IRONFRONT — guide
   Steg-för-steg-genomgång ovanpå gränssnittet. Resten av
   skärmen tonas ned, det som ska användas lyses upp med en
   pulserande ram och en pratbubbla förklarar vad man gör.

   Ett steg ser ut så här:
     {
       target:  '#btnDeploy'  (selektor, funktion eller null = mitten)
       title:   'Skicka ut',
       text:    'Tryck här för att starta.',
       advance: 'next'           → knappen "Nästa" går vidare
              | 'click'          → ett klick på målet går vidare
              | 'signal:namn'    → Guide.signal('namn') går vidare
       skipIf:  () => bool       → hoppa över steget helt
       enter / leave: () => {}   → körs när steget börjar / slutar
       allow:   ['#modal .x']    → fler ställen man får klicka på
     }
   Medan guiden är aktiv går klick bara igenom till målet och
   bubblan — man kan inte råka klicka iväg sig.
   ========================================================= */
import { $, el, esc } from './util.js';
import * as Audio from './audio.js';

let steps = [], idx = -1, opts = {};
let mask, hole, bubble, raf = 0, boundEl = null, missingSince = 0;

export const Guide = {
  get active(){ return idx >= 0; },
  get step(){ return steps[idx] || null; },

  start(list, o = {}){
    ensureDom();
    steps = list; opts = o; idx = -1;
    mask.classList.add('on');
    bubble.classList.add('on');
    advance();
    loop();
  },

  /** Går vidare om det aktuella steget väntar på just den signalen. */
  signal(name){
    const s = this.step;
    if (s && s.advance === 'signal:' + name) queueMicrotask(advance);
  },

  next(){ if (this.active) advance(); },

  /** Avbryter guiden. `skipped` = spelaren valde att hoppa över. */
  stop(skipped = false){
    if (!this.active) return;
    const s = this.step;
    s?.leave?.();
    idx = -1; steps = [];
    unbind();
    cancelAnimationFrame(raf); raf = 0;
    mask.classList.remove('on');
    bubble.classList.remove('on');
    const done = opts.onDone; opts = {};
    done?.(skipped);
  }
};

/* ---------- stegväxling ---------- */
function advance(){
  const prev = steps[idx];
  prev?.leave?.();
  unbind();
  idx++;
  while (idx < steps.length && steps[idx].skipIf?.()) idx++;
  if (idx >= steps.length){ Guide.stop(false); return; }
  const s = steps[idx];
  missingSince = 0;
  s.enter?.();
  renderBubble(s);
  place();
  Audio.sfx('ui', { vol: .5 });
}

function countVisible(){
  // Stegräknaren hoppar inte över steg som redan filtrerats bort
  let n = 0, at = 0;
  steps.forEach((s, i) => { if (i < idx || !s.skipIf?.()){ n++; if (i <= idx) at = n; } });
  return { at, n };
}

function renderBubble(s){
  const { at, n } = countVisible();
  const action = s.advance === 'click' || s.advance?.startsWith('signal:');
  bubble.innerHTML = `
    <div class="g-top">
      <span class="g-count">${opts.label ? esc(opts.label) + ' · ' : ''}STEG ${at} / ${n}</span>
      <span class="g-bar"><i style="width:${Math.round(at / n * 100)}%"></i></span>
    </div>
    <h3 class="g-title">${esc(s.title)}</h3>
    <p class="g-text">${s.html || esc(s.text)}</p>
    ${action
      ? `<div class="g-do"><i class="g-dot"></i>${esc(s.doText || 'Tryck på det markerade')}</div>`
      : `<div class="g-foot"><button class="btn primary g-next" id="guideNext" type="button">${esc(s.nextLabel || (idx === steps.length - 1 ? 'Klar' : 'Nästa'))}</button></div>`}
    <i class="g-arrow"></i>`;
  const nx = bubble.querySelector('.g-next');
  if (nx) nx.addEventListener('click', () => Guide.next());
  bubble.dataset.step = String(idx);
}

/* ---------- målet ---------- */
function resolve(s){
  if (!s || !s.target) return null;
  const t = typeof s.target === 'function' ? s.target() : $(s.target);
  if (!t) return null;
  // Ett dolt element (display:none) har ingen yta att peka på
  const r = t.getBoundingClientRect?.();
  if (r && r.width === 0 && r.height === 0) return null;
  return t;
}

function onTargetClick(){
  const s = Guide.step;
  if (s && s.advance === 'click') queueMicrotask(advance);
}
function bind(node){
  if (node === boundEl) return;
  unbind();
  boundEl = node;
  if (node) node.addEventListener('click', onTargetClick);
}
function unbind(){
  if (boundEl) boundEl.removeEventListener('click', onTargetClick);
  boundEl = null;
}

/* ---------- placering ---------- */
function loop(){
  cancelAnimationFrame(raf);
  const step = () => { if (!Guide.active) return; place(); raf = requestAnimationFrame(step); };
  raf = requestAnimationFrame(step);
}

function place(){
  const s = Guide.step;
  if (!s) return;
  const t = resolve(s);
  bind(t);
  const W = innerWidth, H = innerHeight;

  // Nödutgång: syns bara om målet av någon anledning aldrig dyker upp,
  // så att ingen kan fastna i guiden. Annars finns ingen väg förbi den.
  if (!t && s.target){
    missingSince = missingSince || Date.now();
    if (Date.now() - missingSince > 8000 && !bubble.querySelector('.g-skip')){
      const b = document.createElement('button');
      b.className = 'g-skip';
      b.textContent = 'Något fastnade — hoppa över guiden';
      b.addEventListener('click', () => Guide.stop(true));
      bubble.appendChild(b);
    }
  } else missingSince = 0;

  if (!t){
    // Inget mål: bubblan i mitten, hela skärmen nedtonad
    hole.style.display = 'none';
    mask.classList.add('full');
    bubble.dataset.side = 'none';
    const bw = bubble.offsetWidth || 400, bh = bubble.offsetHeight || 200;
    bubble.style.left = Math.round((W - bw) / 2) + 'px';
    bubble.style.top  = Math.round((H - bh) / 2) + 'px';
    return;
  }

  mask.classList.remove('full');
  const pad = s.pad ?? 8;
  const r = t.getBoundingClientRect();
  const hx = Math.max(4, r.left - pad), hy = Math.max(4, r.top - pad);
  const hw = Math.min(W - 8, r.width + pad * 2), hh = Math.min(H - 8, r.height + pad * 2);
  hole.style.display = '';
  hole.style.left = hx + 'px'; hole.style.top = hy + 'px';
  hole.style.width = hw + 'px'; hole.style.height = hh + 'px';

  // Bubblan läggs på den sida där det finns mest plats, om inte steget säger annat
  const bw = bubble.offsetWidth || 380, bh = bubble.offsetHeight || 190, gap = 18;
  const room = { right: W - (hx + hw), left: hx, bottom: H - (hy + hh), top: hy };
  let side = s.side;
  if (!side || room[side] < (side === 'left' || side === 'right' ? bw : bh) + gap){
    side = ['right', 'left', 'bottom', 'top']
      .find(k => room[k] >= ((k === 'left' || k === 'right') ? bw : bh) + gap) || 'none';
  }
  let x, y;
  if (side === 'right'){ x = hx + hw + gap; y = hy + hh / 2 - bh / 2; }
  else if (side === 'left'){ x = hx - bw - gap; y = hy + hh / 2 - bh / 2; }
  else if (side === 'bottom'){ x = hx + hw / 2 - bw / 2; y = hy + hh + gap; }
  else if (side === 'top'){ x = hx + hw / 2 - bw / 2; y = hy - bh - gap; }
  else { x = (W - bw) / 2; y = H - bh - 24; }
  x = Math.max(12, Math.min(W - bw - 12, x));
  y = Math.max(12, Math.min(H - bh - 12, y));
  bubble.style.left = Math.round(x) + 'px';
  bubble.style.top = Math.round(y) + 'px';
  bubble.dataset.side = side;

  // Pilen pekar mot mitten av målet, längs bubblans kant
  const arrow = bubble.querySelector('.g-arrow');
  if (arrow){
    if (side === 'left' || side === 'right'){
      arrow.style.top = Math.max(16, Math.min(bh - 16, hy + hh / 2 - y)) + 'px';
      arrow.style.left = '';
    } else {
      arrow.style.left = Math.max(16, Math.min(bw - 16, hx + hw / 2 - x)) + 'px';
      arrow.style.top = '';
    }
  }
}

/* ---------- DOM och klickspärr ---------- */
function ensureDom(){
  if (mask) return;
  const app = $('#app');
  mask = el('div', 'guide-mask');
  mask.id = 'guideMask';
  hole = el('div', 'guide-hole');
  mask.appendChild(hole);
  bubble = el('div', 'guide-bubble');
  bubble.id = 'guideBubble';
  app.appendChild(mask);
  app.appendChild(bubble);

  // Fångar klick innan resten av gränssnittet ser dem. Allt som inte
  // är målet, bubblan eller något steget uttryckligen tillåter stoppas.
  const gate = e => {
    if (!Guide.active) return;
    const s = Guide.step;
    const t = e.target;
    if (!t || !t.closest) return;
    if (t.closest('#guideBubble')) return;
    const target = resolve(s);
    if (target && (target === t || target.contains?.(t))) return;
    if (s.allow && s.allow.some(sel => t.closest(sel))) return;
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'click') nudge();
  };
  if (typeof window !== 'undefined' && window.addEventListener){
    ['click', 'mousedown', 'pointerdown', 'touchstart'].forEach(type =>
      window.addEventListener(type, gate, true));
    window.addEventListener('keydown', e => {
      if (!Guide.active) return;
      if (e.code === 'Escape' || e.code === 'Tab'){ e.preventDefault(); e.stopPropagation(); }
    }, true);
  }
}

/** Liten skakning av bubblan när man klickar fel — visar var man ska titta. */
function nudge(){
  bubble.classList.remove('nudge');
  void bubble.offsetWidth;
  bubble.classList.add('nudge');
  hole.classList.remove('nudge');
  void hole.offsetWidth;
  hole.classList.add('nudge');
}
