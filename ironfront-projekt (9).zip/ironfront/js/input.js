/* =========================================================
   IRONFRONT — indata
   Tangentbord + mus, med handkontroll som jämbördigt alternativ
   (vänster spak går, höger spak siktar, avtryckare skjuter).
   ========================================================= */
import { clamp } from './util.js';

const BINDS = {
  up:      ['KeyW', 'ArrowUp'],
  down:    ['KeyS', 'ArrowDown'],
  left:    ['KeyA', 'ArrowLeft'],
  right:   ['KeyD', 'ArrowRight'],
  fire:    ['Space'],
  reload:  ['KeyR'],
  ability: ['ShiftLeft', 'ShiftRight', 'KeyQ'],
  pause:   ['Escape', 'KeyP'],
  ping:    ['KeyG', 'KeyF']          // markering i co-op (G eller F)
};

export const Input = {
  keys: Object.create(null),
  pressed: new Set(),          // kanttriggade: nollställs varje bildruta
  mouse: { x: 0, y: 0, down: false },
  padIndex: null,
  padAim: { x: 0, y: 0 },
  usingPad: false,

  bind(canvas){
    addEventListener('keydown', e => {
      if (e.repeat) return;
      // Mellanslag och piltangenter ska inte rulla sidan mitt i en strid.
      if (['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code)) e.preventDefault();
      this.keys[e.code] = true;
      this.pressed.add(e.code);
      this.usingPad = false;
    });
    addEventListener('keyup',   e => { this.keys[e.code] = false; });
    addEventListener('blur',    () => { this.keys = Object.create(null); this.mouse.down = false; });

    const track = e => {
      const r = canvas.getBoundingClientRect();
      this.mouse.x = e.clientX - r.left;
      this.mouse.y = e.clientY - r.top;
      this.usingPad = false;
    };
    canvas.addEventListener('mousemove', track);
    canvas.addEventListener('mousedown', e => { if (e.button === 0){ this.mouse.down = true; track(e); } });
    addEventListener('mouseup',   e => { if (e.button === 0) this.mouse.down = false; });
    canvas.addEventListener('contextmenu', e => e.preventDefault());

    // Pekskärm: håll för att gå och skjuta mot fingret.
    canvas.addEventListener('touchstart', e => {
      const t = e.touches[0], r = canvas.getBoundingClientRect();
      this.mouse.x = t.clientX - r.left; this.mouse.y = t.clientY - r.top;
      this.mouse.down = true; e.preventDefault();
    }, { passive: false });
    canvas.addEventListener('touchmove', e => {
      const t = e.touches[0], r = canvas.getBoundingClientRect();
      this.mouse.x = t.clientX - r.left; this.mouse.y = t.clientY - r.top;
      e.preventDefault();
    }, { passive: false });
    canvas.addEventListener('touchend', () => { this.mouse.down = false; });

    addEventListener('gamepadconnected',    e => { this.padIndex = e.gamepad.index; });
    addEventListener('gamepaddisconnected', () => { this.padIndex = null; this.usingPad = false; });
  },

  /** Läses en gång per bildruta innan uppdateringen. */
  poll(){
    this.pad = null;
    if (this.padIndex == null || !navigator.getGamepads) return;
    const gp = navigator.getGamepads()[this.padIndex];
    if (!gp) return;
    this.pad = gp;
    const ax = gp.axes[2] || 0, ay = gp.axes[3] || 0;
    if (Math.hypot(ax, ay) > 0.22){ this.padAim.x = ax; this.padAim.y = ay; this.usingPad = true; }
    if (Math.hypot(gp.axes[0] || 0, gp.axes[1] || 0) > 0.22) this.usingPad = true;
  },

  endFrame(){ this.pressed.clear(); },

  down(action){
    const codes = BINDS[action];
    if (codes && codes.some(c => this.keys[c])) return true;
    if (action === 'fire' && this.mouse.down) return true;
    const gp = this.pad;
    if (gp){
      if (action === 'fire'    && (gp.buttons[7]?.pressed || gp.buttons[5]?.pressed)) return true;
      if (action === 'ability' && (gp.buttons[6]?.pressed || gp.buttons[1]?.pressed)) return true;
      if (action === 'reload'  && gp.buttons[2]?.pressed) return true;
    }
    return false;
  },

  /** Sant exakt en bildruta när knappen trycks ned. */
  hit(action){
    const codes = BINDS[action];
    if (codes && codes.some(c => this.pressed.has(c))) return true;
    if (this.padHits && this.padHits.has(action)) return true;
    return false;
  },

  /** Rörelseriktning, normaliserad. */
  move(){
    let x = 0, y = 0;
    if (this.down('left'))  x -= 1;
    if (this.down('right')) x += 1;
    if (this.down('up'))    y -= 1;
    if (this.down('down'))  y += 1;
    const gp = this.pad;
    if (gp){
      const gx = gp.axes[0] || 0, gy = gp.axes[1] || 0;
      if (Math.hypot(gx, gy) > 0.18){ x = gx; y = gy; }
    }
    const len = Math.hypot(x, y);
    if (len > 1){ x /= len; y /= len; }
    return { x, y, len: clamp(len, 0, 1) };
  },

  /** Siktvinkel i världskoordinater. */
  aim(worldX, worldY, camera){
    if (this.usingPad && Math.hypot(this.padAim.x, this.padAim.y) > 0.22)
      return Math.atan2(this.padAim.y, this.padAim.x);
    return Math.atan2(this.mouse.y + camera.y - worldY, this.mouse.x + camera.x - worldX);
  }
};

/* Kantdetektering för handkontrollsknappar (de saknar egna händelser). */
let prevButtons = [];
export function pollPadEdges(){
  Input.padHits = new Set();
  const gp = Input.pad;
  if (!gp) { prevButtons = []; return; }
  const map = { 6: 'ability', 1: 'ability', 2: 'reload', 9: 'pause', 0: 'confirm' };
  gp.buttons.forEach((b, i) => {
    const now = b.pressed, was = prevButtons[i];
    if (now && !was && map[i]) Input.padHits.add(map[i]);
    prevButtons[i] = now;
  });
}
