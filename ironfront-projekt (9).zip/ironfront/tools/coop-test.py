"""
IRONFRONT — riktigt co-op-test.
Startar lobbyservern, öppnar spelet i två separata webbläsare
(värd och gäst), skapar en lobby, går med via koden, startar
matchen och kontrollerar att gästens inmatning styr gästens
robot hos värden och att gästen ser värdens strid.

Kör:  python3 tools/coop-test.py      (kräver node, playwright)
"""
import asyncio, os, subprocess, sys, time, pathlib
from playwright.async_api import async_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
URL = (ROOT / 'dist' / 'ironfront.html').as_uri()
SHOTS = os.environ.get('SHOTS', '/tmp/coop')
os.makedirs(SHOTS, exist_ok=True)

fails = []
def check(ok, msg):
    print(('  ✓ ' if ok else '  ✗ ') + msg)
    if not ok: fails.append(msg)

async def prepare(page, name, taken=None):
    await page.goto(URL); await page.wait_for_timeout(400)
    # Testet kör alltid mot den lokala servern, oavsett vad spelfilen pekar på
    await page.evaluate("() => { window.IRONFRONT.state.settings.server = 'ws://localhost:8787'; }")
    await page.click('#menuNav [data-act=new]'); await page.wait_for_timeout(500)
    await page.evaluate("() => { window.IRONFRONT.state.settings.server = 'ws://localhost:8787'; }")
    if taken:
        # Ett namn som någon annan redan har ska inte gå att ta
        await page.fill('#profileName', taken)
        await page.wait_for_function("document.querySelector('#profileStatus').classList.contains('bad')", timeout=5000)
        msg = await page.text_content('#profileStatus')
        check('taget' in msg, f'upptaget namn stoppas ({msg.strip()})')
    await page.fill('#profileName', name)
    await page.fill('#profilePass', 'hemligt123')
    await page.wait_for_function("!document.querySelector('#profileGo').disabled", timeout=5000)
    await page.click('#profileGo')
    await page.wait_for_selector('#screen-hangar.on', timeout=5000)
    await page.wait_for_function('window.IRONFRONT.Guide.active', timeout=5000)   # guiden startar en bildruta senare
    await page.evaluate("""() => { const I = window.IRONFRONT;
        I.Guide.stop(true); I.state.sector = 3; I.state.level = 2; I.state.flags.hangarTut2Done = true; }""")
    await page.click('#modeTabs [data-mode=multi]')
    await page.click('#btnDeploy'); await page.wait_for_timeout(300)

async def main():
    server = subprocess.Popen(['node', 'server.js'], cwd=ROOT / 'server',
                              stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    time.sleep(0.8)
    try:
        async with async_playwright() as p:
            b = await p.chromium.launch()
            host = await (await b.new_context(viewport={'width':1280,'height':760})).new_page()
            guest = await (await b.new_context(viewport={'width':1280,'height':760})).new_page()
            errs = []
            for pg, tag in ((host,'värd'),(guest,'gäst')):
                pg.on('pageerror', lambda e, t=tag: errs.append(f'{t}: {e}'))

            await prepare(host, 'Jakub')
            check(True, 'värden tog namnet Jakub')
            await prepare(guest, 'Vännen', taken='jakub')

            # Värden skapar lobbyn
            await host.click('#modalBody .lobby-card .btn.primary')
            await host.wait_for_selector('#modalBody .lobby-code b', timeout=5000)
            code = (await host.text_content('#modalBody .lobby-code b')).strip()
            check(len(code) == 6, f'lobbykod skapad ({code})')

            # Gästen går med och blir redo
            await guest.fill('#modalBody .code-input', code)
            await guest.click('#modalBody .lobby-card:nth-child(2) .btn')
            await guest.wait_for_selector('#modalBody .lobby-code b', timeout=5000)
            seats = await host.eval_on_selector_all('#modalBody .seat.filled', 'els => els.length')
            check(seats == 2, 'värden ser två spelare i lobbyn')
            await guest.click('#modalBody .modal-actions .btn.primary')   # Jag är redo
            await host.wait_for_function("document.querySelector('#modalBody .modal-actions .btn.primary') && !document.querySelector('#modalBody .modal-actions .btn.primary').disabled", timeout=5000)
            await host.screenshot(path=f'{SHOTS}/1_lobby_host.png')

            # Start
            await host.click('#modalBody .modal-actions .btn.primary')
            await host.wait_for_function('window.IRONFRONT.Battle.running', timeout=5000)
            await guest.wait_for_function('window.IRONFRONT.Battle.running', timeout=5000)
            check(True, 'båda är i strid')
            roles = await guest.evaluate('window.IRONFRONT.Battle.game.coop.role')
            check(roles == 'guest', 'gästen kör som gäst')
            tags = await guest.evaluate("(() => { const g = window.IRONFRONT.Battle.game; return [g.player.tag, g.allies[0].tag, g.allies[0].rank && g.allies[0].rank.name]; })()")
            check(tags == ['Vännen', 'Jakub', 'Rekryt'], f'namn och titlar över robotarna ({tags})')

            # Gästen går åt höger och skjuter
            g0 = await host.evaluate("(() => { const a = window.IRONFRONT.Battle.game.allies[0]; return [a.x, a.stats.shots]; })()")
            await guest.mouse.move(1100, 380)
            await guest.keyboard.down('KeyD'); await guest.mouse.down()
            await guest.wait_for_timeout(1500)
            await guest.keyboard.up('KeyD'); await guest.mouse.up()
            g1 = await host.evaluate("(() => { const a = window.IRONFRONT.Battle.game.allies[0]; return [a.x, a.stats.shots]; })()")
            check(g1[0] > g0[0] + 40, f'gästens robot rörde sig hos värden ({g0[0]:.0f} → {g1[0]:.0f})')
            check(g1[1] > g0[1], f'gästens robot sköt hos värden ({g1[1]} skott)')

            # Gästen ser värdens fiender och värdens robot
            en = await guest.evaluate('window.IRONFRONT.Battle.game.enemies.length')
            hen = await host.evaluate('window.IRONFRONT.Battle.game.enemies.length')
            check(en > 0 and abs(en - hen) <= 2, f'gästen ser fienderna ({en} hos gästen, {hen} hos värden)')
            gx = await guest.evaluate('window.IRONFRONT.Battle.game.player.x')
            check(abs(gx - g1[0]) < 60, 'gästens egen robot står där värden säger')

            # Markering: gästen trycker G — värden ska se den med gästens namn
            await guest.mouse.move(700, 300)
            await guest.keyboard.press('KeyG')
            await host.wait_for_function("(window.IRONFRONT.Battle.game.pings || []).length > 0", timeout=4000)
            who = await host.evaluate("window.IRONFRONT.Battle.game.pings[0].who")
            check(who == 'Vännen', f'gästens markering syns hos värden ({who})')
            await host.keyboard.press('KeyG')
            await guest.wait_for_function("(window.IRONFRONT.Battle.game.pings || []).some(p => p.who === 'Jakub')", timeout=4000)
            check(True, 'värdens markering syns hos gästen')

            # Återupplivning: gästens robot slås ut, värden ställer sig bredvid
            await host.evaluate("""() => { const g = window.IRONFRONT.Battle.game; const a = g.allies[0];
                a.hp = 0; g.player.x = a.x + 40; g.player.y = a.y; g.player.hp = g.player.maxHp = 1e6;
                for (const e of g.enemies){ e.x += 3000; e.speed = 0; e.baseSpeed = 0; } }""")
            await guest.wait_for_function("window.IRONFRONT.Battle.game.player.hp <= 0", timeout=3000)
            await host.wait_for_function("window.IRONFRONT.Battle.game.allies[0].hp > 0", timeout=6000)
            ghp = await guest.evaluate("new Promise(r => setTimeout(() => r(window.IRONFRONT.Battle.game.player.hp), 400))")
            check(ghp > 0, f'gästen återupplivades av värden ({ghp} liv)')

            await host.mouse.move(900, 300)
            await host.mouse.down(); await host.wait_for_timeout(1200); await host.mouse.up()
            await host.screenshot(path=f'{SHOTS}/2_battle_host.png')
            await guest.screenshot(path=f'{SHOTS}/3_battle_guest.png')

            # Värden avbryter — gästen ska hamna på resultatskärmen
            await host.evaluate('window.IRONFRONT.Battle.abandon()')
            await guest.wait_for_selector('#screen-result.on', timeout=5000)
            check(True, 'gästen fick matchslut från värden')
            await guest.click('#resBack'); await guest.wait_for_timeout(500)
            back = await guest.evaluate("document.querySelector('#modal').dataset.kind")
            check(back == 'lobby', 'gästen är tillbaka i lobbyn efter matchen')
            await guest.screenshot(path=f'{SHOTS}/4_after.png')

            check(not errs, 'inga JavaScript-fel' + ('' if not errs else ': ' + '; '.join(errs[:3])))
            await b.close()
    finally:
        server.terminate()
        import shutil
        for f in ('names.json', 'banned.json'):
            try: os.remove(ROOT / 'server' / f)
            except OSError: pass
        for d in ('data', 'logs'):
            shutil.rmtree(ROOT / 'server' / d, ignore_errors=True)
    print(('\n✓ Co-op fungerar' if not fails else f'\n✗ {len(fails)} fel'))
    sys.exit(1 if fails else 0)

asyncio.run(main())
