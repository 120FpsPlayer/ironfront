"""
IRONFRONT — test av konton, molnsparning, topplistor och adminsidan.
Startar servern med ett adminlösenord och kör två "datorer" (separata
webbläsarprofiler):
  1. Dator A skapar kontot "Kalle" med lösenord, spelar klart träningen
     (nivå 2) och molnsparar.
  2. Dator B loggar in som Kalle med lösenordet → får nivå 2 och robotarna.
  3. Topplistan visar Kalle.
  4. Adminsidan visar Kalle online; spärra namnet → Kalle kopplas ned.
Kör:  python3 tools/account-test.py
"""
import asyncio, os, subprocess, sys, time, pathlib, shutil, urllib.request
from playwright.async_api import async_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
URL = (ROOT / 'dist' / 'ironfront.html').as_uri()
KEY = 'testnyckel'
fails = []
def check(ok, msg):
    print(('  ✓ ' if ok else '  ✗ ') + msg)
    if not ok: fails.append(msg)

def clean():
    for f in ('names.json', 'banned.json'):
        try: os.remove(ROOT / 'server' / f)
        except OSError: pass
    for d in ('data', 'logs'): shutil.rmtree(ROOT / 'server' / d, ignore_errors=True)

async def local(page):
    await page.evaluate("() => { window.IRONFRONT.state.settings.server = 'ws://localhost:8787'; }")

async def main():
    clean()
    env = dict(os.environ, ADMIN_KEY=KEY)
    server = subprocess.Popen(['node', 'server.js'], cwd=ROOT / 'server', env=env, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
    time.sleep(0.8)
    try:
        async with async_playwright() as p:
            b = await p.chromium.launch()
            errs = []
            A = await (await b.new_context(viewport={'width':1280,'height':760})).new_page()
            A.on('pageerror', lambda e: errs.append('A: ' + str(e)))
            await A.goto(URL); await A.wait_for_timeout(300); await local(A)
            await A.click('#menuNav [data-act=new]'); await A.wait_for_timeout(300); await local(A)
            await A.fill('#profileName', 'Kalle')
            await A.wait_for_timeout(700)
            check(await A.eval_on_selector('#profileGo', 'b => b.disabled'), 'kontot kräver lösenord')
            await A.fill('#profilePass', 'hemligt123')
            await A.wait_for_function("!document.querySelector('#profileGo').disabled", timeout=5000)
            await A.click('#profileGo'); await A.wait_for_selector('#screen-hangar.on')
            await A.wait_for_function('window.IRONFRONT.Guide.active')
            await A.evaluate("() => { window.IRONFRONT.Guide.stop(true); window.IRONFRONT.state.flags.battleTutDone = true; }")
            # Klara träningen → nivå 2 → molnsparning efter striden
            await A.click('#btnDeploy'); await A.wait_for_timeout(1200)
            await A.evaluate("() => { const g = window.IRONFRONT.Battle.game; g.waveInSector = 5; g.enemies.length = 0; }")
            await A.wait_for_selector('#screen-result.on', timeout=6000)
            await A.wait_for_timeout(2500)
            saved = (ROOT / 'server' / 'data' / 'saves' / 'kalle.json').exists()
            check(saved, 'sparfilen hamnade på servern')

            # Dator B: logga in
            B = await (await b.new_context(viewport={'width':1280,'height':760})).new_page()
            B.on('pageerror', lambda e: errs.append('B: ' + str(e)))
            await B.goto(URL); await B.wait_for_timeout(300); await local(B)
            await B.click('#menuNav [data-act=new]'); await B.wait_for_timeout(300); await local(B)
            await B.click('#profileTabs [data-pmode=login]')
            await B.fill('#profileName', 'Kalle'); await B.fill('#profilePass', 'fel-losen')
            await B.wait_for_function("!document.querySelector('#profileGo').disabled")
            await B.click('#profileGo'); await B.wait_for_timeout(800)
            st = await B.text_content('#profileStatus')
            check('Fel namn eller lösenord' in st, f'fel lösenord nekas ({st.strip()})')
            await B.fill('#profilePass', 'hemligt123')
            await B.click('#profileGo'); await B.wait_for_selector('#screen-hangar.on', timeout=5000)
            lv = await B.evaluate("() => [window.IRONFRONT.state.level, window.IRONFRONT.state.profile.name, window.IRONFRONT.state.bays.filter(Boolean).length]")
            check(lv[0] == 2 and lv[1] == 'Kalle' and lv[2] >= 1, f'inloggning på ny dator hämtade framstegen (nivå {lv[0]}, {lv[1]}, {lv[2]} robot)')

            # Topplistan (guide 2 startar efter träningen — stäng den först)
            await B.wait_for_timeout(500)
            await B.evaluate("() => window.IRONFRONT.Guide.stop(true)")
            await B.click('#tabRail [data-tab=top]')
            await B.wait_for_selector('#specBody .top-row', timeout=5000)
            names = await B.eval_on_selector_all('#specBody .top-row .tr-name b', 'els => els.map(e => e.textContent)')
            check('Kalle' in names, f'topplistan visar Kalle ({names})')
            await B.screenshot(path='/tmp/shots2/70_top.png')

            # Adminsidan
            html = urllib.request.urlopen(f'http://localhost:8787/admin?key={KEY}').read().decode()
            check('Kalle' in html and 'adminpanel' in html, 'adminsidan visar Kalle online')
            try:
                urllib.request.urlopen('http://localhost:8787/admin?key=fel'); check(False, 'fel adminlösenord nekas')
            except urllib.error.HTTPError as e:
                check(e.code == 403, 'fel adminlösenord nekas')
            ap = await (await b.new_context(viewport={'width':1280,'height':900})).new_page()
            await ap.goto(f'http://localhost:8787/admin?key={KEY}'); await ap.screenshot(path='/tmp/shots2/71_admin.png', full_page=True)
            urllib.request.urlopen(f'http://localhost:8787/admin?key={KEY}&do=ban&name=Kalle').read()
            await B.wait_for_timeout(800)
            banned = 'kalle' in (ROOT / 'server' / 'banned.json').read_text() if (ROOT / 'server' / 'banned.json').exists() else False
            check(banned, 'spärren sparades')
            log = ''.join(p.read_text() for p in (ROOT / 'server' / 'logs').glob('*.log'))
            check('NAMN SPÄRRAT' in log and 'LOGGADE IN' in log and 'INLOGGNING NEKAD' in log, 'loggen har inloggningar och spärren')
            check(not errs, 'inga JavaScript-fel' + ('' if not errs else ': ' + '; '.join(errs[:3])))
            await b.close()
    finally:
        server.terminate(); time.sleep(0.3); clean()
    print('\n✓ Konton fungerar' if not fails else f'\n✗ {len(fails)} fel')
    sys.exit(1 if fails else 0)

asyncio.run(main())
