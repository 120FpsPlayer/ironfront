/* =========================================================
   IRONFRONT — kontroll av enfilsbygget
   Bygget är hopsatt av ett skript, så det måste testas som
   det ser ut efteråt: ladda HTML-filen, kör skriptet i
   låtsas-DOM:en och spela några hundra bildrutor.

   Kör:  node tools/verify-single.mjs [fil]
   ========================================================= */
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { runInThisContext } from 'node:vm';
import { installDom } from './stub-dom.mjs';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');
const FILE = process.argv[2] || join(ROOT, 'dist/ironfront.html');

const problems = [];
console.error = (...a) => problems.push(a.map(String).join(' '));
process.on('uncaughtException', e => problems.push('uncaught: ' + e.stack));

const html = readFileSync(FILE, 'utf8');

const script = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].sort((a, b) => b[1].length - a[1].length)[0];
if (!script) fail('ingen inbyggd <script> i filen');
if (/<link rel="stylesheet"/.test(html)) fail('CSS lämnades kvar som extern länk');
if (!/<style>/.test(html)) fail('ingen inbäddad <style>');
if (/type="module"/.test(html)) fail('modulskriptet byttes inte ut');

const dom = installDom(html);
runInThisContext(script[1], { filename: 'ironfront.html' });

check(dom.document.querySelector('#screen-menu').classList.contains('on'), 'titelskärmen visas');

dom.document.querySelector('#menuNav [data-act=new]').click();
dom.document.querySelectorAll('#modalBody .btn.primary')[0]?.click();
check(dom.document.querySelector('#screen-profile').classList.contains('on'), 'namnskärmen visas');
// Ingen server här: välj namn och fortsätt utan kontroll
dom.document.querySelector('#profileName').value = 'Testpilot';
dom.document.querySelector('#profileOffline').click();
check(dom.document.querySelector('#screen-hangar').classList.contains('on'), 'hangaren öppnas');
dom.pump(0);                                              // guiden startar i nästa bildruta
check(globalThis.IRONFRONT?.Guide?.active, 'guiden startar');
globalThis.IRONFRONT.Guide.stop(true);                    // hoppa över → får en gratis RECON
check(dom.document.querySelector('#bayName').textContent === 'RECON', 'roboten dockad');

dom.document.querySelector('#btnDeploy').click();
let t = 0;
for (let i = 0; i < 400; i++){ t += 16.7; dom.pump(t); }
const game = globalThis.IRONFRONT?.Battle?.game;
check(!!game, 'striden kör');
check(game && game.elapsed > 3000, 'tiden går i striden');
check(globalThis.localStorage.getItem('ironfront.save'), 'sparfilen skrivs');

if (problems.length){
  console.log(`\n✗ ${problems.length} fel i enfilsbygget:`);
  [...new Set(problems)].slice(0, 8).forEach(p => console.log('  ' + p.split('\n')[0]));
  process.exit(1);
}
console.log(`\n✓ Enfilsbygget fungerar (${(html.length / 1024).toFixed(0)} kB, ${400} bildrutor körda)\n`);

function check(cond, what){
  console.log(`  ${cond ? '✓' : '✗'} ${what}`);
  if (!cond) problems.push('misslyckades: ' + what);
}
function fail(msg){ console.log('  ✗ ' + msg); problems.push(msg); }
