/* =========================================================
   IRONFRONT — röktest
   Startar hela spelet i Node med en låtsas-DOM, klickar sig
   genom menyn, spelar ett antal bildrutor och rapporterar
   varje fel som dyker upp. Ersätter inte att spela i
   webbläsaren, men fångar de fel som annars bara syns i
   konsolen efter tjugo minuters manuellt klickande.

   Kör:  node tools/smoketest.mjs
         node tools/smoketest.mjs --frames 1800
   ========================================================= */
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { installDom, canvasIssues, resetCanvasIssues } from './stub-dom.mjs';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');
const FRAMES = Number(process.argv[process.argv.indexOf('--frames') + 1]) || 9000;

/* ---------- felrapportering ---------- */
const problems = [];
const origError = console.error;
const origWarn = console.warn;
console.error = (...a) => { problems.push(a.map(String).join(' ')); origError('  ⚠', ...a); };
console.warn  = (...a) => { origWarn('  ·', ...a); };
process.on('uncaughtException', e => { problems.push('uncaught: ' + e.stack); origError(e); });
process.on('unhandledRejection', e => { problems.push('rejection: ' + e); });

const steps = [];
function step(name, fn){
  try { fn(); steps.push(['ok', name]); }
  catch (e){ steps.push(['fel', name + ' — ' + e.message]); problems.push(`${name}: ${e.stack}`); }
}
async function stepAsync(name, fn){
  try { await fn(); steps.push(['ok', name]); }
  catch (e){ steps.push(['fel', name + ' — ' + e.message]); problems.push(`${name}: ${e.stack}`); }
}
const tick = () => new Promise(r => setTimeout(r, 0));
function expect(cond, msg){ if (!cond) throw new Error(msg); }

/* ---------- miljö ---------- */
/* Fast slumpfrö: samma körning varje gång, annars går testet inte att
   jämföra mellan två ändringar. */
let seed = 0x1f2e3d4c >>> 0;
Math.random = () => {
  seed = (seed + 0x6D2B79F5) >>> 0;
  let x = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  x = (x + Math.imul(x ^ (x >>> 7), 61 | x)) ^ x;
  return ((x ^ (x >>> 14)) >>> 0) / 4294967296;
};

const html = readFileSync(join(ROOT, 'index.html'), 'utf8');
const dom = installDom(html);

console.log('\nIRONFRONT — röktest');
console.log('─'.repeat(52));

step('index.html tolkad', () => {
  expect(dom.document.querySelector('#stage'), '#stage saknas');
  expect(dom.document.querySelector('#bayStage'), '#bayStage saknas');
  expect(dom.document.querySelectorAll('#menuNav button').length >= 5, 'menyknappar saknas');
});

/* ---------- start ---------- */
const S = await import('../js/state.js');   // namnrymd, inte destrukturering:
                                            // state byts ut när en kampanj nollställs
const { Battle } = await import('../js/battle.js');
const { Input } = await import('../js/input.js');
const { bus } = await import('../js/util.js');
const { Guide } = await import('../js/guide.js');
await import('../js/main.js');

const seen = new Set();
['battle:started','wave:start','wave:cleared','boss:start','boss:phase','draft:open','event:start','battle:finished']
  .forEach(ev => bus.on(ev, () => seen.add(ev)));

step('spelet startade', () => {
  expect(dom.document.querySelector('#screen-menu').classList.contains('on'), 'titelskärmen visas inte');
});

/* Klicka "Ny kampanj" → bekräfta → hangaren */
step('ny kampanj', () => {
  dom.document.querySelector('#menuNav [data-act=new]').click();
  const yes = dom.document.querySelectorAll('#modalBody .btn.primary')[0];
  if (yes) yes.click();
  expect(dom.document.querySelector('#screen-profile').classList.contains('on'), 'namnskärmen öppnades inte');
});

/* Användarnamn: röktestet har ingen server, så namnkontrollen misslyckas
   och "fortsätt ändå" ska dyka upp. Riktig kontroll testas i coop-test.py. */
await stepAsync('användarnamn', async () => {
  const input = dom.document.querySelector('#profileName');
  input.value = 'x';
  input.dispatchEvent({ type: 'input', target: input });
  expect(dom.document.querySelector('#profileGo').disabled, 'för kort namn ska inte godkännas');
  input.value = 'Testpilot';
  input.dispatchEvent({ type: 'input', target: input });
  for (let i = 0; i < 10; i++){ await new Promise(r => setTimeout(r, 60)); await tick(); }
  const off = dom.document.querySelector('#profileOffline');
  expect(!off.hidden, 'fortsätt-ändå-knappen syns inte när servern saknas');
  off.click();
  expect(S.state.profile.name === 'Testpilot', 'namnet sparades inte');
  expect(dom.document.querySelector('#screen-hangar').classList.contains('on'), 'hangaren öppnades inte');
});

/* Första guiden: klickar sig igenom varje steg som en spelare gör —
   "Nästa" där det finns, annars själva det markerade målet. Stannar
   vid sista steget (Skicka ut) så att hangaren kan testas först. */
await stepAsync('guide 1 — första roboten', async () => {
  dom.pump(0);                                  // guiden startar i nästa bildruta
  expect(Guide.active, 'guiden startade inte');
  expect(!S.state.bays.some(Boolean), 'ny spelare ska börja utan robot');
  let guard = 0;
  while (Guide.active && guard++ < 40){
    const s = Guide.step;
    if (s.target === '#btnDeploy') break;
    if (s.advance === 'next' || !s.advance){
      dom.document.querySelector('#guideNext').click();
    } else {
      const t = dom.document.querySelector(s.target);
      expect(t, `guidemålet ${s.target} saknas`);
      t.click();
    }
    await tick();
  }
  expect(Guide.active && Guide.step.target === '#btnDeploy', 'guiden nådde inte sista steget');
  expect(S.state.bays[0] && S.state.bays[0].tpl === 'recon', 'RECON köptes inte via guiden');
  Guide.stop(true);
  expect(S.state.flags.tutorialDone, 'guiden markerades inte som klar');
});

step('hangaren fylld', () => {
  expect(dom.document.querySelectorAll('#bays .bay-slot').length === 3, 'fel antal platser');
  expect(dom.document.querySelectorAll('#bays .bay-slot.locked').length === 2, 'plats 2 och 3 ska vara låsta');
  expect(dom.document.querySelectorAll('#modeTabs .mode.locked').length === 5, 'alla lägen utom träningen ska vara låsta');
  expect(dom.document.querySelector('#specBody').children.length > 0, 'spec-panelen är tom');
  expect(dom.document.querySelector('#bayName').textContent === 'RECON', 'fel robot vald');
});

/* Alla flikar ritas */
step('flikarna renderar', () => {
  ['quests','stats','arsenal','bay'].forEach(t => {
    dom.document.querySelector(`#tabRail [data-tab=${t}]`).click();
    expect(dom.document.querySelector('#specBody').children.length > 0, `fliken ${t} är tom`);
  });
});

/* Modaler öppnas utan att krascha */
step('uppgraderingsmodal', () => {
  dom.document.querySelector('#btnUpgrade').click();
  expect(dom.document.querySelector('#modal').classList.contains('on'), 'modalen öppnades inte');
  expect(dom.document.querySelectorAll('#modalBody .up-row').length >= 2, 'inga uppgraderingsrader');
  expect(!dom.document.querySelectorAll('#modalBody .wpn-row').length, 'vapen ska inte ligga i uppgraderingsmenyn');
  dom.document.querySelector('[data-dismiss]').click();
});

step('vapenmeny och bytesmeny är åtskilda', () => {
  dom.document.querySelector('#specBody .spec-weapons .mount').click();
  expect(dom.document.querySelectorAll('#modalBody .up-row').length === 4, 'vapnets uppgraderingar saknas');
  expect(!dom.document.querySelectorAll('#modalBody .wpn-row').length, 'vapenlistan ska ligga i en egen meny');
  dom.document.querySelector('#modalBody .btn-swap').click();
  expect(dom.document.querySelectorAll('#modalBody .wpn-row').length >= 10, 'vapenlistan saknas');
  expect(!dom.document.querySelectorAll('#modalBody .up-row').length, 'uppgraderingar ska inte ligga i bytesmenyn');
  dom.document.querySelector('[data-dismiss]').click();
});

step('inställningar', () => {
  dom.document.querySelector('#btnSettings').click();
  expect(dom.document.querySelectorAll('#modalBody .row').length >= 8, 'för få inställningsrader');
  dom.document.querySelector('[data-dismiss]').click();
});

step('ett köp går igenom', () => {
  const before = S.state.currency.ag;
  dom.document.querySelector('#btnUpgrade').click();
  dom.document.querySelectorAll('#modalBody .up-row .btn')[0].click();
  expect(S.state.currency.ag < before, 'valutan drogs inte');
  expect(S.state.bays[0].lvl.hp >= 1, 'nivån höjdes inte');
  dom.document.querySelector('[data-dismiss]').click();
});

/* ---------- strid ---------- */
step('utryckning', () => {
  resetCanvasIssues();                          // nollställ innan striden ritar något
  dom.document.querySelector('#btnDeploy').click();
  dom.pump(0);                                  // requestAnimationFrame → Battle.start
  expect(Battle.running, 'striden startade inte');
  expect(seen.has('battle:started'), 'battle:started uteblev');
  expect(Battle.game.tut, 'träningen i strid startade inte');
  expect(dom.document.querySelector('#coach').classList.contains('on'), 'instruktören visas inte');
});

/* Simulerad spelare: går i cirkel, siktar på närmaste fiende och skjuter.
   Skrovet och skadan skruvas upp så att testet hinner igenom hela sektorn
   — poängen är att köra igenom bossar, händelser och draft, inte att vinna
   på riktigt. */
Input.mouse.down = true;
const P = Battle.game.player;
P.maxHp = 1e7; P.hp = 1e7; P.mods.dmg = 60;
let t = 0, drafted = 0, frames = 0;
const draftPanel = dom.document.querySelector('#draft');

step(`${FRAMES} bildrutor`, () => {
  for (let i = 0; i < FRAMES; i++){
    const a = i * 0.035;
    Input.keys.KeyW = Math.sin(a) > 0;
    Input.keys.KeyS = Math.sin(a) <= 0;
    Input.keys.KeyA = Math.cos(a) > 0;
    Input.keys.KeyD = Math.cos(a) <= 0;
    const g = Battle.game;
    const target = g && (g.enemies.find(e => e.isBoss) || g.enemies[0]);
    if (target){
      Input.mouse.x = target.x - g.camera.x;
      Input.mouse.y = target.y - g.camera.y;
    } else {
      Input.mouse.x = 720 + Math.cos(a * 2) * 300;
      Input.mouse.y = 405 + Math.sin(a * 2) * 200;
    }
    if (i % 180 === 0) Input.pressed.add('KeyR');
    if (i % 240 === 0){ Input.keys.ShiftLeft = true; Input.pressed.add('ShiftLeft'); } else Input.keys.ShiftLeft = false;

    // Fältuppgraderingen väljs via kortet, precis som en spelare gör
    if (draftPanel.classList.contains('on')){
      const card = dom.document.querySelectorAll('#draftCards .perk')[0];
      if (card){ card.click(); drafted++; }
    }

    t += 16.7;
    frames += dom.pump(t);
    if (!Battle.running && !dom.pendingFrames()) break;
  }
  expect(frames > 100, `bara ${frames} bildrutor kördes`);
});

step('vågorna rullade', () => {
  expect(seen.has('wave:start'), 'ingen våg startade');
  const g = Battle.game;
  expect(g, 'spelobjektet saknas');
  expect(g.player.stats.shots > 0, 'ingen avfyrning registrerades');
  expect(g.enemies.length >= 0, 'fiendelistan trasig');
});

step('inga ogiltiga ritanrop', () => {
  // Riktiga webbläsare struntar tyst i NaN/Infinity i de flesta canvas-anrop,
  // vilket gömmer just den sortens bugg (fel fältnamn → odefinierat →
  // NaN-koordinat → osynlig robot). Stubben larmar istället för att gömma.
  if (canvasIssues.length){
    throw new Error(`${canvasIssues.length} anrop med NaN/Infinity, t.ex. ${canvasIssues[0]}`);
  }
});

/* ---------- paus, draft, resultat ---------- */
await stepAsync('paus fungerar', async () => {
  if (!Battle.running) return;
  Battle.pause();
  await tick();                                 // pausmenyn visas i en mikrouppgift
  expect(dom.document.querySelector('#pause').classList.contains('on'), 'pausmenyn visas inte');
  dom.document.querySelector('#pauseNav [data-act=resume]').click();
  expect(!dom.document.querySelector('#pause').classList.contains('on'), 'pausmenyn stängdes inte');
});

step('resultatskärmen', () => {
  if (Battle.running){
    Battle.abandon();
  }
  expect(seen.has('battle:finished'), 'battle:finished uteblev');
  expect(dom.document.querySelector('#screen-result').classList.contains('on'), 'resultatskärmen visas inte');
  expect(dom.document.querySelectorAll('#resStats .n').length === 8, 'fel antal statistikrutor');
  dom.document.querySelector('#resBack').click();
  expect(dom.document.querySelector('#screen-hangar').classList.contains('on'), 'kom inte tillbaka till hangaren');
});

/* Andra guiden: efter vunnen träning ska platser och spellägen öppnas */
await stepAsync('guide 2 — platser och spellägen', async () => {
  if (S.state.level < 2){
    // Röktestet vann inte träningen den här gången — ge nivå 2 som en vinst hade gjort
    S.completeTraining();
  }
  if (S.state.sector < 2){
    // Röktestet vann inte sektorn den här gången — tvinga fram läget så guiden testas ändå
    S.state.sector = 2;
    dom.document.querySelector('#btnMenu').click();
    dom.document.querySelector('#menuNav [data-act=continue]').click();
  }
  S.grant({ ag: 5000, au: 100 });
  dom.pump(0);
  expect(Guide.active, 'andra guiden startade inte');
  let guard = 0;
  while (Guide.active && guard++ < 40){
    const st = Guide.step;
    if (st.advance === 'next' || !st.advance) dom.document.querySelector('#guideNext').click();
    else {
      const t = dom.document.querySelector(st.target);
      expect(t, `guidemålet ${st.target} saknas`);
      t.click();
    }
    await tick();
  }
  expect(!Guide.active, 'guiden tog aldrig slut');
  expect(S.state.slotsUnlocked === 2, `plats 2 köptes inte / plats 3 ska vara låst till nivå 15 (${S.state.slotsUnlocked})`);
  expect(S.state.level === 2, `ska vara nivå 2 efter träningen (${S.state.level})`);
  expect(S.state.flags.hangarTut2Done, 'guide 2 markerades inte som klar');
  expect(!dom.document.querySelectorAll('#modeTabs .mode.locked').length, 'spellägena låstes inte upp');
});

step('nivåer och XP', () => {
  const D = { ...S };
  expect(!S.levelAllows('robots', 'titan'), 'TITAN ska vara låst på nivå 2');
  expect(!S.buySlot(2), 'plats 3 ska inte gå att köpa före nivå 15');
  const r = S.addXp(40000);
  expect(r.up && r.up.to >= 15, `40 000 XP borde ge nivå 15+ (${S.state.level})`);
  expect(S.levelAllows('robots', 'titan'), 'TITAN ska vara upplåst');
  expect(r.up.unlocks.some(u => u.kind === 'slot'), 'plats 3 saknas i upplåsningarna');
  expect(S.buySlot(2), 'plats 3 ska gå att köpa på nivå 15');
});

step('story — kapitel 1', () => {
  dom.document.querySelector('#modeTabs [data-mode=story]').click();
  expect(S.state.mode === 'story', 'storyläget valdes inte');
  dom.document.querySelector('#btnDeploy').click();
  const ch = dom.document.querySelector('#modalBody .chapter[data-chapter="1"]');
  expect(ch, 'kapitellistan saknas');
  ch.click();
  dom.pump(t += 16.7);
  expect(Battle.running && Battle.game.chapter?.id === 1, 'kapitlet startade inte');
  const g = Battle.game;
  g.player.maxHp = 1e7; g.player.hp = 1e7; g.player.mods.dmg = 80;
  for (let i = 0; i < 6000 && Battle.running; i++){
    const target = g.enemies.find(e => e.isBoss) || g.enemies[0];
    if (target){ Input.mouse.x = target.x - g.camera.x; Input.mouse.y = target.y - g.camera.y; }
    if (dom.document.querySelector('#draft').classList.contains('on'))
      dom.document.querySelectorAll('#draftCards .perk')[0]?.click();
    t += 16.7; dom.pump(t);
  }
  const finished = !Battle.running;
  if (Battle.running) Battle.abandon();
  expect(dom.document.querySelector('#screen-result').classList.contains('on'), 'resultatskärmen visas inte efter kapitlet');
  if (finished) expect(S.state.story.done.includes(1), 'kapitel 1 bokfördes inte som klart');
  dom.document.querySelector('#resBack').click();
});

await stepAsync('multiplayer — lobby utan server', async () => {
  // Röktestet har ingen server: lobbyn ska visas och ett misslyckat
  // anslutningsförsök ska ge ett begripligt fel, inte krascha. Riktig
  // co-op testas med tools/coop-test.py (server + två webbläsare).
  dom.document.querySelector('#modeTabs [data-mode=multi]').click();
  dom.document.querySelector('#btnDeploy').click();
  expect(dom.document.querySelector('#modalBody .lobby-choice'), 'lobbyvalen saknas');
  expect(!dom.document.querySelector('#modalBody #lobbyServer'), 'serverfältet ska inte finnas — adressen är inbyggd');
  const create = [...dom.document.querySelectorAll('#modalBody .btn.primary')][0];
  create.click();
  for (let i = 0; i < 5; i++) await tick();
  expect(!dom.document.querySelector('#modalBody .lobby-code'), 'lobby skapades utan server?');
  dom.document.querySelector('[data-dismiss]').click();
});

step('sparfilen skrevs', () => {
  const raw = globalThis.localStorage.getItem('ironfront.save');
  expect(raw, 'ingen sparfil');
  const data = JSON.parse(raw);
  expect(data.career.runs >= 1, 'utryckningen bokfördes inte');
});

/* ---------- rapport ---------- */
console.log('─'.repeat(52));
let failed = 0;
for (const [status, name] of steps){
  if (status === 'ok') console.log(`  ✓ ${name}`);
  else { failed++; console.log(`  ✗ ${name}`); }
}
console.log('─'.repeat(52));
console.log(`  ${steps.length - failed}/${steps.length} steg klara · ${frames} bildrutor · ${drafted} fältuppgraderingar`);
const COVER = ['battle:started','wave:start','wave:cleared','boss:start','boss:phase','event:start','draft:open','battle:finished'];
console.log('  Passerad kod: ' + COVER.map(e => (seen.has(e) ? '✓' : '·') + ' ' + e).join('  '));
if (problems.length){
  console.log(`\n  ${problems.length} fel i konsolen:`);
  [...new Set(problems)].slice(0, 12).forEach(p => console.log('   ' + p.split('\n')[0]));
}
console.log('');
process.exit(failed || problems.length ? 1 : 0);
