#!/usr/bin/env python3
"""
IRONFRONT — enfilsbygge
=======================

Paketerar hela projektet till en enda HTML-fil som går att öppna
direkt med dubbelklick, utan server och utan internet. Praktiskt
för att skicka spelet vidare eller lägga upp det någonstans.

    python tools/build_single.py                 # → dist/ironfront.html
    python tools/build_single.py --out spel.html

Så här fungerar det: ES-moduler kräver http, så varje modul packas
in i en egen funktion och läggs i ett litet register. `import`
blir en uppslagning i registret och `export` blir en post i det
objekt modulen lämnar ifrån sig. Resultatet är vanlig JavaScript
som vilken webbläsare som helst kör från disk.
"""

from __future__ import annotations

import argparse
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
JS = ROOT / "js"
ENTRY = "main.js"

IMPORT_RE = re.compile(
    r"^[ \t]*import\s+(?:(?P<ns>\*\s+as\s+\w+)|(?P<named>\{[\s\S]*?\}))\s+from\s+"
    r"['\"]\./(?P<mod>[\w.-]+\.js)['\"];?[ \t]*\r?\n",
    re.M,
)
BARE_IMPORT_RE = re.compile(r"^[ \t]*import\s+['\"]\./(?P<mod>[\w.-]+\.js)['\"];?[ \t]*\r?\n", re.M)

EXPORT_DECL_RE = re.compile(
    r"^(?P<indent>[ \t]*)export\s+(?P<kind>const|let|var|class|function|async\s+function)\s+(?P<name>[A-Za-z_$][\w$]*)",
    re.M,
)


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def module_deps(src: str) -> list[str]:
    deps = [m.group("mod") for m in IMPORT_RE.finditer(src)]
    deps += [m.group("mod") for m in BARE_IMPORT_RE.finditer(src)]
    return deps


def topo_order(entry: str, sources: dict[str, str]) -> list[str]:
    """Djupet först: beroenden hamnar före den som använder dem."""
    order: list[str] = []
    state: dict[str, str] = {}

    def visit(name: str, trail: list[str]) -> None:
        if state.get(name) == "done":
            return
        if state.get(name) == "open":
            raise SystemExit("Cirkulärt beroende: " + " → ".join(trail + [name]))
        state[name] = "open"
        for dep in module_deps(sources[name]):
            if dep not in sources:
                raise SystemExit(f"{name} importerar {dep}, som inte finns i js/")
            visit(dep, trail + [name])
        state[name] = "done"
        order.append(name)

    visit(entry, [])
    return order


def transform(name: str, src: str) -> str:
    """Gör om en ES-modul till en funktionskropp med explicit retur."""
    exports: list[str] = []
    hoisted: list[str] = []

    def take_import(m: re.Match) -> str:
        mod = m.group("mod")
        if m.group("ns"):
            alias = m.group("ns").split("as")[-1].strip()
            hoisted.append(f'const {alias} = __M["{mod}"];')
        else:
            spec = m.group("named").strip()
            # { a, b as c }  →  { a, b: c }
            spec = re.sub(r"([A-Za-z_$][\w$]*)\s+as\s+([A-Za-z_$][\w$]*)", r"\1: \2", spec)
            hoisted.append(f'const {spec} = __M["{mod}"];')
        return ""

    src = IMPORT_RE.sub(take_import, src)
    src = BARE_IMPORT_RE.sub(lambda m: "", src)

    def take_export(m: re.Match) -> str:
        exports.append(m.group("name"))
        return f'{m.group("indent")}{m.group("kind")} {m.group("name")}'

    src = EXPORT_DECL_RE.sub(take_export, src)

    if re.search(r"^\s*export\b", src, re.M):
        leftover = re.search(r"^.*export\b.*$", src, re.M)
        raise SystemExit(f"{name}: okänd export-form → {leftover.group(0).strip()}")

    # Getters, så att en omtilldelad variabel fortfarande syns utifrån.
    ret = ", ".join(f"get {e}(){{ return {e}; }}" for e in sorted(set(exports)))
    body = "\n".join(hoisted) + "\n" + src
    return f'__M["{name}"] = (function(){{\n"use strict";\n{body}\nreturn {{ {ret} }};\n}})();'


def build() -> str:
    sources = {p.name: read(p) for p in sorted(JS.glob("*.js"))}
    order = topo_order(ENTRY, sources)
    bundle = "\n".join(transform(n, sources[n]) for n in order)

    html = read(ROOT / "index.html")

    # CSS rakt in i dokumentet
    css_parts = []
    for m in re.finditer(r'<link rel="stylesheet" href="(css/[\w.-]+)">\s*', html):
        css_parts.append(f"/* ---- {m.group(1)} ---- */\n" + read(ROOT / m.group(1)))
    html = re.sub(r'\s*<link rel="stylesheet" href="css/[\w.-]+">', "", html)
    style = "<style>\n" + "\n".join(css_parts) + "\n</style>"
    html = html.replace("</head>", style + "\n</head>")

    script = (
        "<script>\n"
        "/* IRONFRONT — enfilsbygge. Källkoden ligger som separata moduler\n"
        "   i projektet; det här är samma kod hopsatt till en fil. */\n"
        "const __M = {};\n" + bundle + "\n</script>"
    )
    html = html.replace('<script type="module" src="js/main.js"></script>', script)

    # Typsnitten hämtas från nätet; utan uppkoppling faller de tillbaka
    # på systemets egna, vilket CSS:en redan har stackar för.
    return html


def main() -> None:
    ap = argparse.ArgumentParser(description="Bygger IRONFRONT till en enda HTML-fil")
    ap.add_argument("--out", default="dist/ironfront.html")
    args = ap.parse_args()

    out = (ROOT / args.out).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    html = build()
    out.write_text(html, encoding="utf-8")
    print(f"Skrev {out}  ({len(html) / 1024:.0f} kB)")


if __name__ == "__main__":
    main()
