/* =========================================================
   IRONFRONT — testmiljö
   En mycket liten DOM, canvas och WebAudio för Node, så att
   hela spelet kan startas och köras utan webbläsare. Används
   bara av tools/smoketest.mjs — spelet självt rör aldrig den här filen.
   ========================================================= */

const VOID_TAGS = new Set([
  'area','base','br','col','embed','hr','img','input','link','meta','param',
  'source','track','wbr','path','circle','rect','line','polygon','polyline','ellipse','use','stop'
]);

/* ---------------------------------------------------------
   Mycket enkel HTML-tokenisering. Tillräcklig för vår egen
   markup (välformad, inga konstiga entiteter).
   --------------------------------------------------------- */
const TOKEN = /<!--[\s\S]*?-->|<!\[CDATA\[[\s\S]*?\]\]>|<!DOCTYPE[^>]*>|<\/([a-zA-Z0-9-]+)\s*>|<([a-zA-Z0-9-]+)((?:\s+[^\s=>/]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s">]+))?)*)\s*(\/?)>|([^<]+)/g;
const ATTR = /([^\s=]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s">]+)))?/g;

export class ClassList{
  constructor(node){ this.node = node; }
  get set(){ return new Set((this.node.getAttribute('class') || '').split(/\s+/).filter(Boolean)); }
  write(s){ this.node.setAttribute('class', [...s].join(' ')); }
  add(...c){ const s = this.set; c.forEach(x => s.add(x)); this.write(s); }
  remove(...c){ const s = this.set; c.forEach(x => s.delete(x)); this.write(s); }
  contains(c){ return this.set.has(c); }
  toggle(c, force){
    const s = this.set;
    const on = force === undefined ? !s.has(c) : !!force;
    if (on) s.add(c); else s.delete(c);
    this.write(s);
    return on;
  }
  get length(){ return this.set.size; }
  toString(){ return [...this.set].join(' '); }
}

export class Node2{
  constructor(tag){
    this.tagName = String(tag).toUpperCase();
    this.attrs = new Map();
    this.childNodes = [];
    this.parentNode = null;
    this.listeners = new Map();
    this.style = new Proxy({ cssText: '' }, { set(t, k, v){ t[k] = v; return true; } });
    this.classList = new ClassList(this);
    this._text = '';
    this.hidden = false;
    this.disabled = false;
    this.width = 300; this.height = 150;
  }

  /* ---- attribut ---- */
  getAttribute(n){ return this.attrs.has(n) ? this.attrs.get(n) : null; }
  setAttribute(n, v){ this.attrs.set(n, String(v)); }
  removeAttribute(n){ this.attrs.delete(n); }
  hasAttribute(n){ return this.attrs.has(n); }

  get id(){ return this.getAttribute('id') || ''; }
  set id(v){ this.setAttribute('id', v); }
  get className(){ return this.getAttribute('class') || ''; }
  set className(v){ this.setAttribute('class', v); }

  get dataset(){
    const self = this;
    return new Proxy({}, {
      get(_, k){ return self.getAttribute('data-' + camelToDash(k)) ?? undefined; },
      set(_, k, v){ self.setAttribute('data-' + camelToDash(k), v); return true; }
    });
  }

  /* ---- träd ---- */
  get children(){ return this.childNodes.filter(n => !n._isText); }
  get firstChild(){ return this.childNodes[0] || null; }
  get lastChild(){ return this.childNodes[this.childNodes.length - 1] || null; }

  appendChild(n){
    if (!n) return n;
    if (n.parentNode) n.parentNode.removeChild(n);
    n.parentNode = this;
    this.childNodes.push(n);
    return n;
  }
  append(...ns){ ns.forEach(n => this.appendChild(typeof n === 'string' ? textNode(n) : n)); }
  removeChild(n){
    const i = this.childNodes.indexOf(n);
    if (i >= 0){ this.childNodes.splice(i, 1); n.parentNode = null; }
    return n;
  }
  remove(){ if (this.parentNode) this.parentNode.removeChild(this); }

  insertAdjacentHTML(pos, html){
    const frag = parseHTML(html);
    if (pos === 'beforeend') frag.forEach(n => this.appendChild(n));
    else if (pos === 'afterbegin') frag.reverse().forEach(n => this.childNodes.unshift(Object.assign(n, { parentNode: this })));
    else frag.forEach(n => this.appendChild(n));
  }

  get innerHTML(){ return this.childNodes.map(serialize).join(''); }
  set innerHTML(html){
    this.childNodes.forEach(n => { n.parentNode = null; });
    this.childNodes = [];
    if (html) parseHTML(html).forEach(n => this.appendChild(n));
  }

  get textContent(){
    if (this._isText) return this._text;
    return this.childNodes.map(n => n.textContent).join('');
  }
  set textContent(v){
    this.childNodes = [];
    if (v !== '' && v != null) this.appendChild(textNode(String(v)));
  }

  /* ---- selektorer ---- */
  querySelector(sel){ return this.querySelectorAll(sel)[0] || null; }
  querySelectorAll(sel){
    const out = [];
    for (const part of String(sel).split(',')){
      matchDescendants(this, part.trim()).forEach(n => { if (!out.includes(n)) out.push(n); });
    }
    return out;
  }
  closest(sel){
    let n = this;
    while (n){ if (matchSimple(n, sel)) return n; n = n.parentNode; }
    return null;
  }
  matches(sel){ return matchSimple(this, sel); }

  /* ---- layout (fasta värden räcker i testet) ---- */
  get clientWidth(){ return this._w ?? 1440; }
  get clientHeight(){ return this._h ?? 810; }
  getBoundingClientRect(){ return { left: 0, top: 0, right: this.clientWidth, bottom: this.clientHeight, width: this.clientWidth, height: this.clientHeight, x: 0, y: 0 }; }

  /* ---- händelser ---- */
  addEventListener(type, fn){
    if (!this.listeners.has(type)) this.listeners.set(type, new Set());
    this.listeners.get(type).add(fn);
  }
  removeEventListener(type, fn){ this.listeners.get(type)?.delete(fn); }
  dispatchEvent(ev){
    ev.target = ev.target || this;
    ev.currentTarget = this;
    this.listeners.get(ev.type)?.forEach(fn => fn(ev));
    return true;
  }
  click(){ this.dispatchEvent({ type: 'click', target: this, button: 0, preventDefault(){}, stopPropagation(){} }); }
  focus(){}
  blur(){}

  /* ---- canvas ---- */
  getContext(){ if (!this._ctx) this._ctx = makeCtx(this); return this._ctx; }
  toDataURL(){ return 'data:,'; }
}

function camelToDash(k){ return String(k).replace(/[A-Z]/g, m => '-' + m.toLowerCase()); }

function textNode(text){
  const n = new Node2('#text');
  n._isText = true;
  n._text = text;
  n.tagName = '#TEXT';
  return n;
}

function serialize(n){
  if (n._isText) return n._text;
  const attrs = [...n.attrs].map(([k, v]) => ` ${k}="${v}"`).join('');
  const tag = n.tagName.toLowerCase();
  if (VOID_TAGS.has(tag)) return `<${tag}${attrs}>`;
  return `<${tag}${attrs}>${n.childNodes.map(serialize).join('')}</${tag}>`;
}

export function parseHTML(html){
  const roots = [];
  const stack = [];
  const top = () => stack[stack.length - 1];
  const put = n => { if (stack.length) top().appendChild(n); else roots.push(n); };

  TOKEN.lastIndex = 0;
  let m;
  while ((m = TOKEN.exec(html)) !== null){
    const [raw, closeTag, openTag, attrStr, selfClose, text] = m;
    if (closeTag){
      for (let i = stack.length - 1; i >= 0; i--){
        if (stack[i].tagName === closeTag.toUpperCase()){ stack.length = i; break; }
      }
    } else if (openTag){
      const node = new Node2(openTag);
      ATTR.lastIndex = 0;
      let a;
      while ((a = ATTR.exec(attrStr || '')) !== null){
        if (!a[1]) continue;
        node.setAttribute(a[1], a[2] ?? a[3] ?? a[4] ?? '');
      }
      put(node);
      if (!selfClose && !VOID_TAGS.has(openTag.toLowerCase())) stack.push(node);
    } else if (text){
      if (text.trim()) put(textNode(text));
    } else if (raw.startsWith('<!--') || raw.startsWith('<!DOCTYPE')){
      /* hoppa över */
    }
  }
  return roots;
}

/* ---------------------------------------------------------
   Selektormotor: tag, #id, .klass, [attr], [attr=värde]
   och efterkommande-kombinationer ("#menuNav button").
   --------------------------------------------------------- */
function matchSimple(node, sel){
  if (!sel || node._isText) return false;
  const parts = sel.match(/^[a-zA-Z0-9-]+|#[^.#\[\s]+|\.[^.#\[\s]+|\[[^\]]+\]/g);
  if (!parts) return false;
  for (const p of parts){
    if (p[0] === '#'){ if (node.id !== p.slice(1)) return false; }
    else if (p[0] === '.'){ if (!node.classList.contains(p.slice(1))) return false; }
    else if (p[0] === '['){
      const inner = p.slice(1, -1);
      const eq = inner.indexOf('=');
      if (eq < 0){ if (!node.hasAttribute(inner)) return false; }
      else {
        const k = inner.slice(0, eq);
        const v = inner.slice(eq + 1).replace(/^["']|["']$/g, '');
        if (node.getAttribute(k) !== v) return false;
      }
    }
    else if (node.tagName !== p.toUpperCase()) return false;
  }
  return true;
}

function walk(node, fn){
  for (const c of node.childNodes){
    if (c._isText) continue;
    fn(c);
    walk(c, fn);
  }
}

function matchDescendants(root, sel){
  const steps = sel.split(/\s+/).filter(Boolean);
  if (!steps.length) return [];
  let cur = [root];
  for (const step of steps){
    const next = [];
    cur.forEach(scope => walk(scope, n => { if (matchSimple(n, step) && !next.includes(n)) next.push(n); }));
    cur = next;
    if (!cur.length) break;
  }
  return cur;
}

/* ---------------------------------------------------------
   Canvas 2D — allt är no-op utom det som måste returnera något.
   --------------------------------------------------------- */
/* Verkliga webbläsare struntar tyst i NaN/Infinity i de flesta
   rit-anrop (canvas-specen säger "return utan att göra något").
   Det gömmer precis den sortens bugg som orsakade det här felet
   (ett fält som hette fel sak gav NaN som radie). Så: registrera
   varje sådant anrop här, och låt smoketestet fälla på det —
   hellre ett för känsligt test än en osynlig robot i produktion. */
export const canvasIssues = [];
export function resetCanvasIssues(){ canvasIssues.length = 0; }

function checkArgs(method, args){
  for (const a of args){
    if (typeof a === 'number' && !Number.isFinite(a)){
      canvasIssues.push(`${method}(${args.map(String).join(', ')})`);
      return false;
    }
  }
  return true;
}

function makeCtx(canvas){
  const gradient = { addColorStop(){}, };
  const base = {
    canvas,
    fillStyle: '#000', strokeStyle: '#000', lineWidth: 1, globalAlpha: 1,
    font: '10px sans-serif', textAlign: 'start', textBaseline: 'alphabetic',
    lineCap: 'butt', lineJoin: 'miter', globalCompositeOperation: 'source-over',
    shadowBlur: 0, shadowColor: '#000', imageSmoothingEnabled: true, filter: 'none',
    createLinearGradient: (...a) => { checkArgs('createLinearGradient', a); return gradient; },
    createRadialGradient: (...a) => { checkArgs('createRadialGradient', a); return gradient; },
    createConicGradient: (...a) => { checkArgs('createConicGradient', a); return gradient; },
    createPattern: () => ({ setTransform(){} }),
    measureText: t => ({ width: String(t).length * 6 }),
    getImageData: (x, y, w, h) => ({ data: new Uint8ClampedArray(Math.max(1, w * h * 4)), width: w, height: h }),
    putImageData(){},
    createImageData: (w, h) => ({ data: new Uint8ClampedArray(Math.max(1, w * h * 4)), width: w, height: h }),
    isPointInPath: () => false,
    getLineDash: () => []
  };
  return new Proxy(base, {
    get(t, k){
      if (k in t) return t[k];
      // Okänd metod: en kontrollerad no-op som ändå larmar på NaN/Infinity,
      // precis som en riktig webbläsare skulle rita "ingenting" men vi vill
      // veta att den bad om det.
      return (...args) => { checkArgs(String(k), args); };
    },
    set(t, k, v){ t[k] = v; return true; }
  });
}
const NOOP = () => {};

/* ---------------------------------------------------------
   WebAudio — spelar inget, men alla anrop måste gå igenom.
   --------------------------------------------------------- */
function param(v = 0){
  return {
    value: v,
    setValueAtTime(){ return this; },
    linearRampToValueAtTime(){ return this; },
    exponentialRampToValueAtTime(){ return this; },
    setTargetAtTime(){ return this; },
    cancelScheduledValues(){ return this; }
  };
}
function audioNode(extra = {}){
  return Object.assign({
    connect(n){ return n; }, disconnect(){},
    start(){}, stop(){},
    gain: param(1), frequency: param(440), detune: param(0), Q: param(1),
    pan: param(0), playbackRate: param(1),
    threshold: param(-24), knee: param(30), ratio: param(12),
    attack: param(0.003), release: param(0.25),
    type: 'sine', buffer: null, loop: false, onended: null
  }, extra);
}

class StubAudioContext{
  constructor(){
    this.state = 'running';
    this.sampleRate = 44100;
    this.destination = audioNode();
    this._t = 0;
  }
  get currentTime(){ return (this._t += 0.0005); }
  resume(){ this.state = 'running'; return Promise.resolve(); }
  close(){ this.state = 'closed'; return Promise.resolve(); }
  createGain(){ return audioNode(); }
  createOscillator(){ return audioNode(); }
  createBufferSource(){ return audioNode(); }
  createBiquadFilter(){ return audioNode(); }
  createStereoPanner(){ return audioNode(); }
  createDynamicsCompressor(){ return audioNode(); }
  createWaveShaper(){ return audioNode({ curve: null, oversample: 'none' }); }
  createDelay(){ return audioNode({ delayTime: param(0) }); }
  createConvolver(){ return audioNode(); }
  createBuffer(ch, len){
    const data = new Float32Array(len);
    return { length: len, numberOfChannels: ch, getChannelData: () => data };
  }
}

/* ---------------------------------------------------------
   Installation
   --------------------------------------------------------- */
export function installDom(html){
  const roots = parseHTML(html);
  const htmlEl = roots.find(n => n.tagName === 'HTML') || new Node2('html');
  let body = htmlEl.querySelector('body');
  if (!body){ body = new Node2('body'); htmlEl.appendChild(body); }
  let head = htmlEl.querySelector('head');
  if (!head){ head = new Node2('head'); htmlEl.appendChild(head); }

  const doc = {
    documentElement: htmlEl,
    body, head,
    readyState: 'complete',
    createElement: tag => new Node2(tag),
    createElementNS: (_ns, tag) => new Node2(tag),
    createTextNode: textNode,
    querySelector: sel => htmlEl.querySelector(sel),
    querySelectorAll: sel => htmlEl.querySelectorAll(sel),
    getElementById: id => htmlEl.querySelector('#' + id),
    addEventListener(type, fn){ globalThis.addEventListener(type, fn); },
    removeEventListener(type, fn){ globalThis.removeEventListener(type, fn); }
  };

  const store = new Map();
  const localStorage = {
    getItem: k => (store.has(k) ? store.get(k) : null),
    setItem: (k, v) => store.set(k, String(v)),
    removeItem: k => store.delete(k),
    clear: () => store.clear(),
    key: i => [...store.keys()][i] ?? null,
    get length(){ return store.size; }
  };

  const winListeners = new Map();
  const win = globalThis;
  win.document = doc;
  win.window = win;
  win.localStorage = localStorage;
  win.devicePixelRatio = 1;
  win.innerWidth = 1440;
  win.innerHeight = 810;
  try{
    win.navigator = { getGamepads: () => [], userAgent: 'node-smoketest', maxTouchPoints: 0 };
  }catch{
    Object.defineProperty(win, 'navigator', {
      configurable: true,
      value: { getGamepads: () => [], userAgent: 'node-smoketest', maxTouchPoints: 0 }
    });
  }
  win.AudioContext = StubAudioContext;
  win.Image = class { constructor(){ this.width = 0; this.height = 0; } };

  win.addEventListener = (type, fn) => {
    if (!winListeners.has(type)) winListeners.set(type, new Set());
    winListeners.get(type).add(fn);
  };
  win.removeEventListener = (type, fn) => winListeners.get(type)?.delete(fn);
  win.dispatchEvent = ev => { winListeners.get(ev.type)?.forEach(fn => fn(ev)); return true; };

  /* Styrd tidslinje: testet bestämmer när en bildruta ritas. */
  const frames = [];
  let frameId = 1;
  win.requestAnimationFrame = cb => { frames.push({ id: frameId, cb }); return frameId++; };
  win.cancelAnimationFrame = id => {
    const i = frames.findIndex(f => f.id === id);
    if (i >= 0) frames.splice(i, 1);
  };

  return {
    document: doc,
    window: win,
    localStorage,
    fireWindow: (type, ev = {}) => win.dispatchEvent({ type, ...ev }),
    /** Kör alla köade bildrutor med angiven tidsstämpel. */
    pump(now){
      const batch = frames.splice(0, frames.length);
      batch.forEach(f => f.cb(now));
      return batch.length;
    },
    pendingFrames: () => frames.length
  };
}
