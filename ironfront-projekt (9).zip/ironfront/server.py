#!/usr/bin/env python3
"""
IRONFRONT — utvecklingsserver
=============================

Spelet är byggt med ES-moduler (import/export). Webbläsare vägrar
ladda moduler över file://, så filerna måste serveras över http.
Den här servern gör bara det — inget byggsteg, inga beroenden.

Kör:
    python server.py               # startar på http://localhost:8000
    python server.py --port 5500   # egen port
    python server.py --no-open     # öppna inte webbläsaren

I VS Code: tryck F5 (konfigurationen ligger i .vscode/launch.json)
eller kör "Terminal → New Terminal" och kommandot ovan.
"""

from __future__ import annotations

import argparse
import http.server
import os
import socket
import socketserver
import sys
import threading
import time
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent

# MIME-typer som vissa Windows-installationer annars gissar fel på.
EXTRA_TYPES = {
    ".js": "text/javascript; charset=utf-8",
    ".mjs": "text/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".html": "text/html; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".svg": "image/svg+xml",
    ".woff2": "font/woff2",
}

ORANGE = "\033[38;5;208m"
DIM = "\033[2m"
RESET = "\033[0m"


class Handler(http.server.SimpleHTTPRequestHandler):
    """Serverar projektmappen utan cache, så en omladdning alltid ger ny kod."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def guess_type(self, path):
        ext = os.path.splitext(path)[1].lower()
        if ext in EXTRA_TYPES:
            return EXTRA_TYPES[ext]
        return super().guess_type(path)

    def end_headers(self):
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        super().end_headers()

    def log_message(self, fmt, *args):
        # Tyst om det gick bra; bara fel är värda att se i terminalen.
        status = str(args[1]) if len(args) > 1 else ""
        if status.startswith(("4", "5")):
            sys.stderr.write(f"{DIM}[{self.log_date_time_string()}]{RESET} {fmt % args}\n")


class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


def free_port(start: int, tries: int = 20) -> int:
    """Letar upp första lediga porten från `start` och uppåt."""
    for offset in range(tries):
        port = start + offset
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(("127.0.0.1", port)) != 0:
                return port
    raise SystemExit(f"Hittade ingen ledig port mellan {start} och {start + tries}.")


def check_project() -> None:
    """Snabbkoll så att servern startas från rätt mapp."""
    missing = [p for p in ("index.html", "js/main.js", "css/tokens.css") if not (ROOT / p).exists()]
    if missing:
        raise SystemExit(
            "Kunde inte hitta: " + ", ".join(missing) +
            f"\nKör servern från projektmappen ({ROOT})."
        )


def main() -> None:
    ap = argparse.ArgumentParser(description="Utvecklingsserver för IRONFRONT")
    ap.add_argument("--port", type=int, default=8000, help="port att lyssna på (standard 8000)")
    ap.add_argument("--host", default="127.0.0.1", help="adress att binda mot")
    ap.add_argument("--no-open", action="store_true", help="öppna inte webbläsaren automatiskt")
    args = ap.parse_args()

    check_project()
    port = free_port(args.port)
    url = f"http://{args.host}:{port}/"

    with Server((args.host, port), Handler) as httpd:
        print(f"\n{ORANGE}IRONFRONT{RESET} — utvecklingsserver")
        print(f"  Mapp    {ROOT}")
        print(f"  Adress  {ORANGE}{url}{RESET}")
        print(f"  {DIM}Ctrl+C avslutar.{RESET}\n")

        if not args.no_open:
            threading.Thread(
                target=lambda: (time.sleep(0.4), webbrowser.open(url)),
                daemon=True,
            ).start()

        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nServern stoppad.")


if __name__ == "__main__":
    main()
