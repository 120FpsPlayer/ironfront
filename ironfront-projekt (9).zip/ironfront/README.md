# IRONFRONT

Taktiskt mech-arenaspel. Du håller en front som sakta faller isär, sektor för
sektor, med en flotta på tre robotar och den utrustning du hinner köpa mellan
utryckningarna.

Allt ritas i realtid på canvas och allt ljud syntetiseras i webbläsaren — spelet
laddar inga bild- eller ljudfiler. Inga byggverktyg, inga npm-paket, inget
kompileringssteg — inte heller för multiplayer-servern.

---

## Kom igång

Du behöver Python 3.8 eller senare. Inget annat.

```bash
python server.py
```

Webbläsaren öppnas på `http://localhost:8000`. Klart.

**Varför en server?** Spelet är skrivet med ES-moduler (`import` / `export`).
Webbläsare vägrar ladda moduler över `file://` av säkerhetsskäl, så att
dubbelklicka på `index.html` ger en tom skärm. `server.py` löser det — den
serverar bara mappen, inget annat.

Vill du ändå ha en fil att dubbelklicka på:

```bash
python tools/build_single.py     # → dist/ironfront.html
```

### I Visual Studio Code

1. `File → Open Folder…` och välj den här mappen.
2. Tryck **F5**. Servern startar och webbläsaren öppnas.

Alternativt: `Ctrl+Shift+P` → *Tasks: Run Task* → **Starta spelet**.

Har du tillägget *Live Server* fungerar det också — högerklicka på
`index.html` → *Open with Live Server*.

---

## Multiplayer (co-op, upp till 4 spelare)

Multiplayer består av **två filer**:

| Fil | Vad den är | Var den ska ligga |
|-----|------------|-------------------|
| `dist/ironfront.html` | Själva spelet | Hos varje spelare |
| `server/server.js` | Lobbyservern — en fil, inga paket | På din server (t.ex. Wispbyte) |

Spelfilen har serveradressen inbyggd, så den kopplar upp sig mot servern
av sig själv — ingen behöver skriva in någon adress.

### Sätta upp servern (t.ex. Wispbyte)

1. Skapa en **Node.js**-server i panelen.
2. Ladda upp `server/server.js`. Inget mer — inga paket, inget `npm install`.
3. Sätt startfilen (*Main file* / *JS file*) till `server.js`.
4. Starta. Loggen visar `IRONFRONT-servern lyssnar på port …`.
   Servern tar själv porten panelen gett den.

Servern håller också **namnregistret**: varje användarnamn får bara finnas
en gång. Registret sparas i `names.json` bredvid `server.js` och skapas av
sig självt. Radera inte den filen om du vill att namnen ska finnas kvar.

### Konton, molnsparning och topplistor

- **Konto:** man väljer namn och lösenord första gången. Lösenordet sparas
  bara som ett saltat hash (scrypt) på servern, aldrig i klartext.
- **Molnsparning:** framstegen laddas upp några sekunder efter varje ändring
  och direkt efter varje utryckning, till `data/saves/<namn>.json`.
- **Logga in på en annan dator:** *Nytt spel* eller *Konto* → fliken
  *Logga in* → namn och lösenord. Framstegen hämtas från servern.
- **Topplistor:** fliken *Topplista* i hangaren — nivå, högsta sektor,
  bästa poäng och veckans utmaning. Data i `data/board.json`.
  Spelet räknas ut i webbläsaren, så topplistan litar på det spelarna
  skickar in. Räcker för en kompisserver, inte för tävlingar med priser.

### Adminsidan

Öppna `server.js` och byt raden

```js
const ADMIN_KEY = process.env.ADMIN_KEY || 'byt-mig';
```

till ett eget lösenord, till exempel `|| 'mitt-hemliga-ord'`. Starta om servern
och gå till `http://<serverns-ip>:<port>/admin`. Där ser du vem som är online
(namn, nivå, robot, IP, hur länge), pågående lobbyer, topp 10, de senaste
200 loggraderna — och kan **sparka ut**, **spärra namn** eller **spärra IP**.
Spärrar sparas i `banned.json`. Så länge lösenordet är `byt-mig` är sidan av.

### Meddelanden och backup (adminsidan)

- **Meddelande till alla:** skriv en text på adminsidan och tryck *Skicka* —
  den visas hos alla som är anslutna just då.
- **Backup:** en gång per dygn kopieras konton, sparfiler, topplistor och
  spärrar till `backups/<datum>/`. De sju senaste sparas. Knappen
  *Gör backup nu* gör en direkt.

### Filer servern skapar

| Fil | Innehåll |
|-----|----------|
| `names.json` | Registrerade namn, nycklar och lösenordshash |
| `data/saves/*.json` | Molnsparfiler, en per konto |
| `data/board.json` | Topplistorna |
| `banned.json` | Spärrade namn och IP-adresser |
| `logs/*.log` | Loggen, en fil per dag |
| `backups/<datum>/` | Daglig kopia av allt ovan (sju dagar) |

Radera dem inte om du vill behålla kontona. Byter du bara `server.js` finns allt kvar.

### Serverloggen

Servern loggar allt som händer — i konsolen (syns i Wispbyte-panelen) och i
en fil per dag i `logs/`, t.ex. `logs/2026-09-23.log`. Filer äldre än 30
dagar raderas automatiskt (ändra `LOG_DAYS` i `server.js`). Exempel:

```
[2026-09-23 15:12:03] ANSLUTEN         p4  ip 83.2.14.7 · webbläsare: Mozilla/5.0 … · 3 online
[2026-09-23 15:12:04] INLOGGAD         p4 "Jakub"  nivå 7 Soldat · robot TITAN · ip 83.2.14.7
[2026-09-23 15:12:10] SPELAR           p4 "Jakub"  Sektorer sektor 4 · robot TITAN
[2026-09-23 15:21:44] RESULTAT         p4 "Jakub"  VANN · sektor 4 · våg 40/40 · … · +1 840 XP · nivå 8
[2026-09-23 15:22:01] LOBBY SKAPAD     p4 "Jakub"  kod K7QX2M
[2026-09-23 15:22:30] GICK MED         p5 "Vännen"  lobby K7QX2M · 2/4 spelare
[2026-09-23 15:22:41] MATCH START      p4 "Jakub"  lobby K7QX2M · sektor 4 · spelare: …
```

Loggade händelser: anslutning (IP och webbläsare), nya namn, namnbyten,
försök att ta upptagna namn, inloggning (nivå, titel, robot), varje
utryckning som startas och hur den slutade (vinst/förlust/lämnade, våg,
XP), nivå upp, lobbyer (skapad, gick med, redo, fel kod, full), matcher
(start, slut, längd) och frånkopplingar (hur länge man var ansluten).

Loggen innehåller IP-adresser, som räknas som personuppgifter. Berätta för
dem som spelar att servern loggar, och spara inte loggarna längre än du
behöver.

### Koppla spelet till servern

Öppna `index.html` (eller `dist/ironfront.html`) i en texteditor. Högst
upp finns en rad:

```html
<script>window.IRONFRONT_SERVER = 'ws://localhost:8787';</script>
```

Byt adressen till din servers IP och port från panelen, till exempel
`'ws://123.45.67.89:25565'`. Spara. Skicka filen till dina vänner — klart.

Den här kopian pekar på Wispbyte-servern `ws://78.154.103.47:10715`. För att
testa lokalt: byt tillbaka till `'ws://localhost:8787'` och kör `node server/server.js`.

Öppna spelet som fil eller via `python server.py`. Ligger spelet på en
**https**-sida (t.ex. GitHub Pages) blockerar webbläsaren `ws://` — då krävs
`wss://`, alltså ett TLS-certifikat och en domän framför servern.

### Spela

1. Välj **Multiplayer** i hangaren och tryck **Öppna lobby**.
2. En spelare trycker **Skapa lobby** och får en sexställig kod.
3. De andra skriver in koden och trycker **Jag är redo**.
4. Värden trycker **Starta match**.

**Hur det fungerar:** värden räknar ut hela striden. Gästerna skickar bara sin
inmatning och ritar värdens bild, 20 gånger i sekunden. Det gör att ingen kan
hamna osynkad, men över internet märks fördröjningen mer än i samma nätverk.

**Test:** `python3 tools/coop-test.py` startar servern och kör en riktig match
mellan två webbläsare (kräver Playwright).

---

## Styrning

| Funktion   | Tangentbord                | Handkontroll   |
|------------|----------------------------|----------------|
| Rörelse    | `W A S D` / piltangenter   | Vänster spak   |
| Sikte      | Musen                      | Höger spak     |
| Eld        | Vänsterklick / `Mellanslag`| RT eller RB    |
| Ladda om   | `R`                        | X              |
| Förmåga    | `Shift` eller `Q`          | LT eller B     |
| Paus       | `Esc` eller `P`            | Start          |

Handkontroll upptäcks automatiskt så fort du rör en spak. På pekskärm: håll
fingret där du vill gå — roboten siktar och skjuter mot samma punkt.

---

## Projektstruktur

```
ironfront/
├── index.html              Skärmarnas markup — all struktur, ingen logik
├── server.py               Utvecklingsserver (inga beroenden)
├── css/
│   ├── tokens.css          Designsystemet: färger, typsnitt, avstånd, skuggor
│   ├── ui.css              Paneler, knappar, mätare, modaler, listmenyer
│   ├── hangar.css          Titelskärm och hangar
│   └── hud.css             Strids-HUD, perk-kort, paus, resultat
├── js/
│   ├── main.js             Start: kopplar ihop delarna i rätt ordning
│   ├── util.js             Matte, färg, DOM-hjälp, händelsebuss, objektpool
│   ├── data.js             ALLT INNEHÅLL: robotar, vapen, fiender, kartor, text
│   ├── state.js            Sparfil i localStorage, migrering, ekonomi
│   ├── perks.js            24 fältuppgraderingar i tre sällsynthetsgrader
│   ├── entities.js         Bygger spelare, fiender och bossar ur data
│   ├── arena.js            Världen: seedad bana, terräng, kollision, sikt
│   ├── input.js            Tangentbord, mus, pekskärm, handkontroll
│   ├── audio.js            Procedurellt ljud (WebAudio), musikbädd
│   ├── fx.js               Partiklar, ljus, skakning, skadesiffror, brännmärken
│   ├── render.js           All rendering, sprite-cache, hangarrobot
│   ├── battle.js           Spelloopen: rörelse, eld, AI, vågor, händelser
│   ├── hud.js              Strids-HUD och radar
│   └── ui.js               Menyer, hangar, butiker, inställningar, resultat
└── tools/
    ├── build_single.py     Packar hela projektet till en HTML-fil
    ├── smoketest.mjs       Kör spelet i Node och letar efter fel
    ├── verify-single.mjs   Kontrollerar att enfilsbygget fungerar
    └── stub-dom.mjs        Låtsas-DOM som testerna kör mot
```

### Hur delarna pratar med varandra

`data.js` längst ned — ren data, importerar ingenting. Systemen läser därifrån
men skriver aldrig tillbaka. Vill du lägga till ett vapen eller en robot räcker
det att fylla på tabellen där; resten av spelet plockar upp den automatiskt.

Ovanpå ligger systemen (`arena`, `entities`, `battle`, `render`, `audio`).
`battle.js` äger spelets tillstånd och är den enda som ändrar det. Rendering och
HUD *läser* bara — de är mätare, inte spakar.

Högst upp pratar allt via en händelsebuss (`bus` i `util.js`). Striden ropar
`bus.emit('wave:cleared', g)`, och HUD:en och gränssnittet lyssnar. Det gör att
`battle.js` och `ui.js` aldrig behöver importera varandra.

---

## Två principer i renderingen

**En ljuskälla.** `LIGHT` i `arena.js` sätter riktningen för varje skugga och
varje kantljus i spelet. Det är den enskilt största anledningen till att scenen
hänger ihop istället för att se ihopklippt ut.

**Rita en gång, rotera sedan.** Mech-bålar, ben och marktexturer förrenderas
till egna canvasar och används som bilder. Därför har spelet råd med
panelfogar, nitar och kantljus utan att tappa bildrutor. Samma ritrutin används
för roboten i hangaren — det du ser i menyn är exakt det du tar med i strid.

---

## Test

Spelet går att köra helt utan webbläsare. `tools/stub-dom.mjs` innehåller en
liten DOM, canvas och WebAudio för Node.

```bash
node tools/smoketest.mjs              # startar spelet, klickar igenom menyn,
                                      # spelar en hel sektor, rapporterar fel
node tools/smoketest.mjs --frames 20000
node tools/verify-single.mjs          # kontrollerar enfilsbygget
```

Röktestet har ett fast slumpfrö, så två körningar ger samma resultat. Det
fångar körfel — inte om spelet är roligt.

---

## Att bygga vidare på

**Nytt vapen:** lägg till en post i `WEAPONS` i `data.js` och ett id i
`WEAPON_ORDER`. Butiken, montagevalet och arsenalen plockar upp det direkt.

**Ny robot:** en post i `ROBOTS` plus id i `ROBOT_ORDER`. Har den `dash`,
`overdrive` eller `shield` får den automatiskt rätt förmåga i strid och rätt
rad i spec-panelen.

**Ny fiende:** en post i `ENEMIES` och en rad i `enemyPoolFor()` som bestämmer
från vilken våg den får dyka upp.

**Ny fältuppgradering:** en post i `PERKS` i `perks.js`. `apply(mods, player)`
får ändra vad som helst — resten sköter sig självt.

**Ny karta:** en post i `MAPS`. Paletten driver både terräng, hinder och
luftpartiklar.

**Balansering:** `ECONOMY` i `data.js` styr belöningar och priskurva.
`DIFFICULTIES` styr fiendernas skada och tålighet.

---

## Felsökning

**Tom svart sida** — du öppnade `index.html` direkt. Kör `python server.py`.

**Inget ljud** — webbläsare tillåter inte ljud innan användaren klickat.
Klicka någonstans, så startar det.

**Rutig bildfrekvens** — sänk *Partiklar* i inställningarna. På äldre datorer
hjälper det också att köra fönstret i mindre storlek.

**Sparfilen krånglar** — *Inställningar → Radera sparfil*. Gamla sparfiler
migreras automatiskt, men en handredigerad fil kan bli obegriplig.

I konsolen finns `IRONFRONT.state` och `IRONFRONT.Battle` för felsökning.
