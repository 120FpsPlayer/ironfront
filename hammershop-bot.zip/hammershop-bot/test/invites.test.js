'use strict';

const { db } = require('./helpers/setup');
const test = require('node:test');
const assert = require('node:assert/strict');
const { Collection } = require('discord.js');
const { FakeGuild, validateMessage } = require('./helpers/fakeDiscord');
const { createInteraction, lastResponse, textOf } = require('./helpers/fakeInteraction');
const { buildServer } = require('../src/builder/executor');
const handle = require('../src/handlers/interactions');
const loadCommands = require('../src/commands');
const config = require('../src/lib/config');
const hooks = require('../src/lib/hooks');
const promos = require('../src/features/promos');
const invites = require('../src/features/invites');

const commands = loadCommands();
const DAY = 86_400_000;

let n = 970000000000000000n;
const uid = () => String(++n);
const role = (guild, key) => db.roleId(guild.id, key);
const member = (guild, roles = ['member']) => guild.addMember(uid(), roles.map((k) => role(guild, k)));
const record = (guild, m) => invites.store(guild.id).members[m.id];

async function setup() {
  const guild = new FakeGuild();
  await buildServer({ guild, mode: 'add', invokerId: guild.ownerId });
  await invites.refresh(guild);
  return guild;
}

/** Someone joins (with this invite, if given) – Discord counts the use before the join event arrives. */
async function join(guild, code = null, { id = uid(), bot = false } = {}) {
  if (code) guild.useInvite(code);
  const m = guild.addMember(id, [], { bot });
  await hooks.emit('memberAdd', m);
  return m;
}

async function leave(guild, m) {
  guild.removeMember(m.id);
  await hooks.emit('memberRemove', m);
}

/** The real thing: Verify button → math question → Member role → hooks 'verified'. */
async function verify(guild, m) {
  const channel = guild.channels.cache.get(db.channelId(guild.id, 'verify'));
  const start = createInteraction({ guild, member: m, kind: 'button', customId: 'verify:start', channel });
  await handle(start, commands);
  const [, , a, b] = start.state.modals[0].custom_id.split(':');
  const answer = createInteraction({ guild, member: m, kind: 'modal', customId: start.state.modals[0].custom_id, fields: { answer: String(Number(a) + Number(b)) }, channel });
  await handle(answer, commands);
}

const command = async (guild, who, subcommand, options = {}) => {
  const i = createInteraction({ guild, member: who, kind: 'command', commandName: 'invites', subcommand, options });
  await handle(i, commands);
  return i;
};

async function withRewards(rewards, fn) {
  const prev = config.invites.rewards;
  config.invites.rewards = rewards;
  try {
    await fn();
  } finally {
    config.invites.rewards = prev;
  }
}

// ───────────── Attribution ─────────────

test('joins are attributed to the invite whose uses went up; vanity, unknown, bots and bot invites have no inviter', async () => {
  const guild = await setup();
  const alice = member(guild);
  const bob = member(guild);
  const a = guild.addInvite({ inviterId: alice.id, uses: 3 });
  const b = guild.addInvite({ inviterId: bob.id });
  await invites.refresh(guild);

  const viaA = await join(guild, a.code);
  assert.deepEqual(record(guild, viaA), { inviterId: alice.id, code: a.code, joinedAt: record(guild, viaA).joinedAt, verified: false, left: false });
  assert.ok(Math.abs(record(guild, viaA).joinedAt - Date.now()) < 5000);
  const viaB = await join(guild, b.code);
  assert.equal(record(guild, viaB).inviterId, bob.id);

  // A new invite (created while nobody was watching) that was used right away
  const fresh = guild.addInvite({ inviterId: bob.id });
  assert.equal(record(guild, await join(guild, fresh.code)).inviterId, bob.id);

  // inviteCreate keeps the cache current
  const announced = guild.addInvite({ inviterId: alice.id });
  await hooks.emit('inviteCreate', announced);
  assert.equal(record(guild, await join(guild, announced.code)).inviterId, alice.id);

  // A single-use invite is deleted the moment it's used – even if the delete event comes first
  const once = guild.addInvite({ inviterId: alice.id, maxUses: 1 });
  await invites.refresh(guild);
  guild.useInvite(once.code);
  await hooks.emit('inviteDelete', { code: once.code, guild });
  const viaOnce = await join(guild);
  assert.deepEqual([record(guild, viaOnce).inviterId, record(guild, viaOnce).code], [alice.id, once.code]);

  // Nothing changed → the vanity URL, or unknown
  guild.vanityURLCode = 'noxshop';
  const vanity = await join(guild);
  assert.deepEqual([record(guild, vanity).inviterId, record(guild, vanity).code], [null, 'noxshop']);
  guild.vanityURLCode = null;
  const unknown = await join(guild);
  assert.deepEqual([record(guild, unknown).inviterId, record(guild, unknown).code], [null, null]);

  // Bots are never recorded; invites created by a bot (e.g. the one /build made) have no inviter
  const bot = await join(guild, b.code, { bot: true });
  assert.equal(record(guild, bot), undefined);
  const botInvite = guild.addInvite({ inviterId: guild.client.user.id });
  botInvite.inviter = guild.client.user;
  await invites.refresh(guild);
  const viaBot = await join(guild, botInvite.code);
  assert.deepEqual([record(guild, viaBot).inviterId, record(guild, viaBot).code], [null, botInvite.code]);
});

test('two people joining at the same time are attributed one after another', async () => {
  const guild = await setup();
  const alice = member(guild);
  const bob = member(guild);
  const a = guild.addInvite({ inviterId: alice.id });
  const b = guild.addInvite({ inviterId: bob.id });
  await invites.refresh(guild);

  // The first fetch is slow: the second person joins while the first join is still being looked up.
  const fetch = guild.invites.fetch;
  let release;
  const gate = new Promise((resolve) => {
    release = resolve;
  });
  let calls = 0;
  guild.invites.fetch = async () => {
    const result = await fetch();
    calls += 1;
    if (calls === 1) await gate;
    return result;
  };
  const tick = () => new Promise((resolve) => setTimeout(resolve, 5));

  guild.useInvite(a.code);
  const first = guild.addMember(uid(), []);
  const firstJoin = hooks.emit('memberAdd', first);
  await tick();
  assert.equal(calls, 1, 'the first lookup is running');
  guild.useInvite(b.code);
  const second = guild.addMember(uid(), []);
  const secondJoin = hooks.emit('memberAdd', second);
  await tick();
  assert.equal(calls, 1, 'the second join waits for the first');
  release();
  await Promise.all([firstJoin, secondJoin]);
  assert.equal(record(guild, first).inviterId, alice.id);
  assert.equal(record(guild, second).inviterId, bob.id, 'compared with the counts after the first join, not before it');
});

// ───────────── Counting ─────────────

test('an invite counts only once the member verifies and while they stay; leave / rejoin and self-invites', async () => {
  const guild = await setup();
  const alice = member(guild);
  const bob = member(guild);
  const a = guild.addInvite({ inviterId: alice.id });
  const b = guild.addInvite({ inviterId: bob.id });
  await invites.refresh(guild);

  const first = await join(guild, a.code);
  const second = await join(guild, a.code);
  assert.deepEqual(invites.counts(guild.id, alice.id), { valid: 0, pending: 2, left: 0 }, 'pending until verified');

  await verify(guild, first);
  assert.ok(first.roles.cache.has(role(guild, 'member')), 'really verified');
  assert.equal(record(guild, first).verified, true);
  assert.ok(record(guild, first).verifiedAt);
  assert.deepEqual(invites.counts(guild.id, alice.id), { valid: 1, pending: 1, left: 0 });
  await hooks.emit('verified', first);
  assert.equal(invites.counts(guild.id, alice.id).valid, 1, 'counted once');

  await leave(guild, first);
  assert.deepEqual(invites.counts(guild.id, alice.id), { valid: 0, pending: 1, left: 1 }, 'leaving takes it off the count');
  assert.equal(record(guild, first).left, true);
  await hooks.emit('verified', first);
  assert.equal(invites.counts(guild.id, alice.id).valid, 0, "someone who left can't count");

  // Rejoining through Bob's invite: they already counted for Alice, so they never count for Bob
  const back = await join(guild, b.code, { id: first.id });
  assert.deepEqual(record(guild, back), { inviterId: bob.id, code: b.code, joinedAt: record(guild, back).joinedAt, verified: false, left: false, creditedTo: alice.id });
  assert.deepEqual(invites.counts(guild.id, bob.id), { valid: 0, pending: 0, left: 0 });
  assert.deepEqual(invites.counts(guild.id, alice.id), { valid: 0, pending: 1, left: 0 });
  await verify(guild, back);
  assert.deepEqual(invites.counts(guild.id, bob.id), { valid: 0, pending: 0, left: 0 });
  assert.equal(record(guild, back).creditedTo, alice.id, 'still credited to Alice');

  // Alice leaves and rejoins with her own invite: never counts
  await leave(guild, alice);
  const self = await join(guild, a.code, { id: alice.id });
  await verify(guild, self);
  assert.equal(record(guild, self).inviterId, alice.id);
  assert.deepEqual(invites.counts(guild.id, alice.id), { valid: 0, pending: 1, left: 0 });
  assert.ok(!invites.leaderboard(guild.id).some((c) => c.inviterId === alice.id));

  // Verifying without a join record (joined before tracking) does nothing
  const old = member(guild, []);
  await hooks.emit('verified', old);
  assert.equal(record(guild, old), undefined);
  void second;
});

test('on start: invites are cached and members who left while the bot was offline stop counting', async () => {
  const guild = await setup();
  const alice = member(guild);
  const a = guild.addInvite({ inviterId: alice.id });
  const store = invites.store(guild.id).members;
  store['111111111111111111'] = { inviterId: alice.id, code: a.code, joinedAt: Date.now() - DAY, verified: true, left: false };
  const stayed = member(guild);
  store[stayed.id] = { inviterId: alice.id, code: a.code, joinedAt: Date.now() - DAY, verified: true, left: false };

  await hooks.emit('ready', guild.client);
  assert.equal(store['111111111111111111'].left, true, 'left while offline');
  assert.equal(store[stayed.id].left, false);
  assert.deepEqual(invites.counts(guild.id, alice.id), { valid: 1, pending: 0, left: 1 });
  assert.equal(record(guild, await join(guild, a.code)).inviterId, alice.id, 'the cache from the start is used');
});

// ───────────── Rewards ─────────────

test('rewards: a personal INVITE code by DM once per level – leaving and rejoining cannot farm codes', async () => {
  await withRewards([{ invites: 3, percent: 15 }, { invites: 2, percent: 10 }], async () => {
    const guild = await setup();
    const alice = member(guild);
    const a = guild.addInvite({ inviterId: alice.id });
    await invites.refresh(guild);
    const codes = () => promos.list(guild.id).filter((p) => p.userId === alice.id);
    const dms = () => guild.dms.filter((d) => d.to === alice.id);

    const first = await join(guild, a.code);
    await verify(guild, first);
    assert.equal(codes().length, 0, 'one valid invite is not enough');
    const second = await join(guild, a.code);
    await verify(guild, second);

    assert.equal(codes().length, 1);
    const code = codes()[0];
    assert.match(code.code, /^ZAPROSZENIE-[0-9A-F]{6}$/);
    assert.equal(code.percent, 10);
    assert.equal(code.maxUses, 1);
    assert.equal(code.reason, '2 zaproszenia');
    assert.ok(Math.abs(code.expiresAt - (Date.now() + invites.REWARD_DAYS * DAY)) < 5000, 'valid for 30 days');
    assert.deepEqual(invites.store(guild.id).rewarded[alice.id][2], { code: code.code, percent: 10, at: invites.store(guild.id).rewarded[alice.id][2].at, delivered: true });

    assert.equal(dms().length, 1);
    const dm = dms()[0].payload;
    validateMessage(dm, guild);
    const out = textOf(dm);
    assert.ok(out.includes(code.code));
    assert.match(out, /Nagroda za zaproszenia odblokowana/);
    assert.match(out, /Zaproszone przez Ciebie osoby, które dołączyły i się zweryfikowały: \*\*2\*\*/);
    assert.match(out, /10% rabatu/);
    assert.match(out, /za \*\*3\*\* ważne zaproszenia dostaniesz \*\*15% rabatu\*\*/);
    assert.match(textOf(guild.channels.cache.get(db.channelId(guild.id, 'serverLogs')).messageList.at(-1).body), new RegExp(`Nagroda za zaproszenia[\\s\\S]*${code.code}`));

    // Leave + rejoin + verify again: back to 2, but level 2 was already rewarded
    await leave(guild, second);
    assert.equal(invites.counts(guild.id, alice.id).valid, 1);
    const back = await join(guild, a.code, { id: second.id });
    await verify(guild, back);
    assert.equal(invites.counts(guild.id, alice.id).valid, 2);
    assert.equal(codes().length, 1, 'no second code for the same level');
    assert.equal(dms().length, 1);

    // Third valid invite → the next level, once
    await verify(guild, await join(guild, a.code));
    assert.equal(codes().length, 2);
    assert.equal(codes()[1].percent, 15);
    assert.equal(codes()[1].reason, '3 zaproszenia');
    await verify(guild, await join(guild, a.code));
    assert.equal(codes().length, 2, 'every level is rewarded once');

    // The code works in the shop's promo check
    assert.equal(promos.check(guild.id, code.code, alice.id).error, null);
  });
});

test('rewards: closed DMs keep the code (shown in /invites stats); no rewards while promo codes are off', async () => {
  await withRewards([{ invites: 1, percent: 5 }], async () => {
    const guild = await setup();
    const shy = member(guild);
    guild.closedDms.add(shy.id);
    const s = guild.addInvite({ inviterId: shy.id });
    await invites.refresh(guild);
    await verify(guild, await join(guild, s.code));
    const [code] = promos.list(guild.id).filter((p) => p.userId === shy.id);
    assert.ok(code, 'the code is kept');
    assert.equal(invites.store(guild.id).rewarded[shy.id][1].delivered, false);
    assert.match(textOf(guild.channels.cache.get(db.channelId(guild.id, 'serverLogs')).messageList.at(-1).body), /zamknięte wiadomości prywatne/);
    const stats = await command(guild, shy, 'stats');
    assert.match(textOf(lastResponse(stats)), new RegExp(`Twoje kody z nagród[\\s\\S]*\`${code.code}\` · 5% rabatu · ważny do`));

    const other = member(guild);
    const o = guild.addInvite({ inviterId: other.id });
    await invites.refresh(guild);
    config.promos.enabled = false;
    try {
      await verify(guild, await join(guild, o.code));
      assert.equal(promos.list(guild.id).filter((p) => p.userId === other.id).length, 0);
      assert.equal(invites.store(guild.id).rewarded[other.id], undefined);
    } finally {
      config.promos.enabled = true;
    }
  });
});

// ───────────── Missing permission ─────────────

test('without Manage Server: no crash, one console warning, joins are recorded without an inviter', async () => {
  const guild = await setup();
  const alice = member(guild);
  const a = guild.addInvite({ inviterId: alice.id });
  guild.deny('ManageGuild');
  const warnings = [];
  const warn = console.warn;
  console.warn = (...args) => warnings.push(args.join(' '));
  try {
    assert.equal(await invites.refresh(guild), null);
    const first = await join(guild, a.code);
    const second = await join(guild, a.code);
    assert.equal(record(guild, first).inviterId, null);
    assert.equal(record(guild, second).inviterId, null);
    assert.equal(warnings.filter((w) => w.includes('[invites]')).length, 1, 'warned once');
    assert.match(warnings[0], /brak uprawnienia Zarządzanie serwerem/);
    assert.equal(invites.isReadable(guild.id), false);
    const stats = await command(guild, alice, 'stats');
    assert.match(textOf(lastResponse(stats)), /Śledzenie wstrzymane[\s\S]*Zarządzanie serwerem/);
  } finally {
    console.warn = warn;
  }
  guild.deniedPermissions.delete('ManageGuild');
  await invites.refresh(guild);
  assert.equal(invites.isReadable(guild.id), true);
  assert.equal(record(guild, await join(guild, a.code)).inviterId, alice.id, 'works again once the permission is back');
});

// ───────────── /invites ─────────────

test('/invites stats: valid / pending / left, reward levels and the next reward', async () => {
  await withRewards([{ invites: 2, percent: 10 }, { invites: 5, percent: 20 }], async () => {
    const guild = await setup();
    const alice = member(guild);
    const a = guild.addInvite({ inviterId: alice.id });
    await invites.refresh(guild);
    for (let i = 0; i < 3; i += 1) await verify(guild, await join(guild, a.code));
    await join(guild, a.code); // pending
    await leave(guild, await join(guild, a.code));

    const mine = await command(guild, alice, 'stats');
    const out = textOf(lastResponse(mine));
    assert.match(out, /Ważne 3/);
    assert.match(out, /Oczekujące 1 \(bez weryfikacji\)/);
    assert.match(out, /Utracone 1/);
    assert.match(out, /\*\*jeszcze 2 ważne zaproszenia\*\* → \*\*20% rabatu\*\*/);
    assert.match(out, /✅ \*\*2\*\* ważne zaproszenia → 10% rabatu\n⬜ \*\*5\*\* ważnych zaproszeń → 20% rabatu/);
    assert.match(out, /Twoje kody z nagród[\s\S]*`ZAPROSZENIE-[0-9A-F]{6}` · 10% rabatu · ważny do/);
    assert.ok(lastResponse(mine).flags & 64, 'ephemeral');

    // Somebody else's stats: counts, but never their codes
    const other = await command(guild, member(guild), 'stats', { user: alice.user });
    const theirs = textOf(lastResponse(other));
    assert.match(theirs, new RegExp(`Zaproszenia osoby <@${alice.id}>`));
    assert.match(theirs, /Ważne 3/);
    assert.doesNotMatch(theirs, /ZAPROSZENIE-/);

    const invited = (await join(guild, a.code));
    const joinedVia = await command(guild, invited, 'stats');
    assert.match(textOf(lastResponse(joinedVia)), new RegExp(`Zaprosił\\(a\\) Cię <@${alice.id}>`));

    const bot = await command(guild, alice, 'stats', { user: guild.client.user });
    assert.match(textOf(lastResponse(bot)), /Boty nikogo nie zapraszają/);
  });
});

test('/invites top: the 10 best inviters, ranked by valid invites, and your own place', async () => {
  const guild = await setup();
  const empty = await command(guild, member(guild), 'top');
  assert.match(textOf(lastResponse(empty)), /Nikt nie ma jeszcze ważnego zaproszenia/);

  const inviters = Array.from({ length: 12 }, () => member(guild));
  const data = invites.store(guild.id).members;
  inviters.forEach((inviter, i) => {
    for (let k = 0; k <= i; k += 1) data[uid()] = { inviterId: inviter.id, code: 'x', joinedAt: Date.now(), verified: true, left: false };
  });
  data[uid()] = { inviterId: inviters[11].id, code: 'x', joinedAt: Date.now(), verified: false, left: false };
  data[uid()] = { inviterId: inviters[11].id, code: 'x', joinedAt: Date.now(), verified: true, left: true };

  const top = await command(guild, inviters[0], 'top');
  const out = textOf(lastResponse(top));
  const lines = out.split('\n').filter((l) => /<@\d+> – /.test(l));
  assert.equal(lines.length, 10);
  assert.ok(lines[0].startsWith(`🥇 <@${inviters[11].id}> – **12 ważnych zaproszeń** · oczekujące: 1 · utracone: 1`));
  assert.ok(lines[1].startsWith(`🥈 <@${inviters[10].id}> – **11 ważnych zaproszeń**`));
  assert.ok(lines[9].startsWith(`**10.** <@${inviters[2].id}> – **3 ważne zaproszenia**`));
  assert.match(out, /Jesteś na \*\*12\.\*\* miejscu z 1 ważnym zaproszeniem\./);
});

// ───────────── Regressions ─────────────

test('rewards cannot be farmed by rotating the same accounts through different inviters', async () => {
  await withRewards([{ invites: 2, percent: 10 }], async () => {
    const guild = await setup();
    const [alice, bob, carol] = [member(guild), member(guild), member(guild)];
    const inviteOf = new Map();
    for (const who of [alice, bob, carol]) inviteOf.set(who.id, guild.addInvite({ inviterId: who.id }).code);
    await invites.refresh(guild);
    const codes = () => promos.list(guild.id).filter((p) => p.code.startsWith('ZAPROSZENIE'));

    // Two friends join through Alice's invite and verify: Alice's reward
    const ids = [uid(), uid()];
    for (const id of ids) await verify(guild, await join(guild, inviteOf.get(alice.id), { id }));
    assert.equal(invites.counts(guild.id, alice.id).valid, 2);
    assert.equal(codes().length, 1);

    // They leave and come back through Bob's, then Carol's invite and verify again: nobody new gets them
    for (const next of [bob, carol]) {
      for (const id of ids) {
        await leave(guild, guild.members.cache.get(id));
        await verify(guild, await join(guild, inviteOf.get(next.id), { id }));
      }
      assert.deepEqual(invites.counts(guild.id, next.id), { valid: 0, pending: 0, left: 0 }, 'they already counted for Alice');
    }
    assert.equal(codes().length, 1, 'still one reward for two real invites');
    assert.ok(!invites.leaderboard(guild.id).some((c) => c.inviterId !== alice.id));

    // Back through Alice's own invite: they count for her again – once, and no second code
    for (const id of ids) {
      await leave(guild, guild.members.cache.get(id));
      await verify(guild, await join(guild, inviteOf.get(alice.id), { id }));
    }
    assert.deepEqual(invites.counts(guild.id, alice.id), { valid: 2, pending: 0, left: 0 });
    assert.equal(codes().length, 1);

    // Someone who never counted for anyone (left before verifying) can still count for the next inviter
    const unsure = await join(guild, inviteOf.get(bob.id));
    await leave(guild, unsure);
    await verify(guild, await join(guild, inviteOf.get(carol.id), { id: unsure.id }));
    assert.equal(invites.counts(guild.id, carol.id).valid, 1);
  });
});

test('the bot being removed and added again: members are fetched again, invite counts are never dropped from a partial member list', async () => {
  const guild = await setup();
  const alice = member(guild);
  const data = invites.store(guild.id).members;
  for (let i = 0; i < 3; i += 1) data[member(guild).id] = { inviterId: alice.id, code: 'x', joinedAt: Date.now(), verified: true, left: false };
  await invites.prepare(guild); // the start
  assert.deepEqual(invites.counts(guild.id, alice.id), { valid: 3, pending: 0, left: 0 });

  // Re-added: discord.js builds a new Guild object with the same ID – only the bot is cached until the members are fetched
  const everyone = guild.members.cache;
  const readded = Object.assign(Object.create(Object.getPrototypeOf(guild)), guild);
  let fetches = 0;
  readded.members = {
    cache: new Collection([['bot', guild.me]]),
    me: guild.me,
    async fetch(arg) {
      if (arg !== undefined) return guild.members.fetch(arg);
      fetches += 1;
      for (const [id, m] of everyone) this.cache.set(id, m);
      return this.cache;
    },
  };
  await hooks.emit('guildCreate', readded);
  assert.equal(fetches, 1, 'the new server object is fetched (once for every feature)');
  assert.deepEqual(invites.counts(guild.id, alice.id), { valid: 3, pending: 0, left: 0 });

  // A member list that is still missing people (Discord sent fewer than memberCount) never marks anyone as left
  const partial = Object.assign(Object.create(Object.getPrototypeOf(guild)), guild);
  partial.members = { cache: new Collection([['bot', guild.me]]), me: guild.me, fetch: async () => partial.members.cache };
  Object.defineProperty(partial, 'memberCount', { value: everyone.size });
  await invites.prepare(partial);
  assert.deepEqual(invites.counts(guild.id, alice.id), { valid: 3, pending: 0, left: 0 });
});

test('/invites when tracking is turned off', async () => {
  const guild = await setup();
  config.invites.enabled = false;
  try {
    const i = await command(guild, member(guild), 'stats');
    assert.match(textOf(lastResponse(i)), /Śledzenie zaproszeń jest wyłączone/);
    const m = await join(guild);
    assert.equal(record(guild, m), undefined, 'nothing is recorded');
  } finally {
    config.invites.enabled = true;
  }
});
