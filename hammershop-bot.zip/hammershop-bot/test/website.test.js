'use strict';

// The website talks to (fake) Discord and Stripe over HTTP – keep the real fetch the test setup replaces.
const realFetch = global.fetch;
const { db } = require('./helpers/setup');
global.fetch = realFetch;

const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { FakeGuild } = require('./helpers/fakeDiscord');
const { textOf } = require('./helpers/fakeInteraction');
const { startFakes, useFakes } = require('./helpers/webFakes');
const { buildServer } = require('../src/builder/executor');
const { env } = require('../src/env');
const shop = require('../src/features/shop');
const delivery = require('../src/features/delivery');
const website = require('../src/features/website');
const webStore = require('../src/web/store');
const webAuth = require('../src/web/discord');
const hooks = require('../src/lib/hooks');
const { createWebServer } = require('../src/web/server');

let fakes;
let site;
let base;
let guild;
let buyer;
let keys;
let combo;
let netflix;

test.before(async () => {
  fakes = await startFakes();
  guild = new FakeGuild();
  await buildServer({ guild, mode: 'add', invokerId: guild.ownerId });
  buyer = guild.addMember(fakes.state.user.id, [db.roleId(guild.id, 'member')]);
  // The bot's shop – this is what the website sells.
  keys = shop.addProduct(guild, { name: 'Game Keys', price: '9.90', description: 'Instant keys.', category: '🎮 Games' });
  await delivery.setDelivery(guild, keys.id, { text: 'KEY-ABC-123' });
  combo = shop.addProduct(guild, { name: '5 Game Combo', price: '15', description: 'Five games.', category: 'Games' });
  netflix = shop.addProduct(guild, { name: 'Netflix', price: '5', description: 'Premium.', category: 'Accounts' });
  shop.setVariants(guild, netflix.id, '1 month = 5, 3 months = 12');
  shop.addProduct(guild, { name: 'Custom Bot', price: 'from 20€', description: 'Ask us.', category: 'Discord Bots' }); // no fixed price → not sold online
  shop.addProduct(guild, { name: 'Sold out thing', price: '3', description: 'x', stock: 'out' });

  website._setClient(guild.client);
  webAuth.setClientId('123');
  webStore.load();
  site = createWebServer({ catalog: website.catalog, info: () => ({ invite: 'https://discord.gg/hammershop' }), onPaid: website.onPaid, onLogin: website.onLogin, isMember: website.isMember, currency: () => 'eur' });
  await new Promise((r) => site.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${site.address().port}`;
  fakes.state.siteBase = base;
  useFakes(env, fakes.base, base);
});
test.after(() => {
  site?.close();
  fakes?.server.close();
});

const get = (p, cookie = '') => fetch(base + p, { headers: { cookie }, redirect: 'manual' });
const post = (p, body, cookie = '', headers = {}) => fetch(base + p, { method: 'POST', headers: { 'content-type': 'application/json', cookie, ...headers }, body: JSON.stringify(body), redirect: 'manual' });
const cookieOf = (res, name) => (res.headers.getSetCookie?.() ?? [res.headers.get('set-cookie') ?? '']).flatMap((c) => c.split(/,(?=\s*\w+=)/)).map((c) => c.split(';')[0].trim()).find((c) => c.startsWith(`${name}=`)) ?? '';

async function signIn(user = fakes.state.user, landing = '/?connected=1') {
  fakes.state.user = user;
  const start = await get('/api/shop/auth/start');
  const authorize = new URL(start.headers.get('location'));
  assert.equal(authorize.searchParams.get('scope'), 'identify guilds.join');
  const back = await get(`/api/shop/auth/callback?code=good&state=${authorize.searchParams.get('state')}`, cookieOf(start, 'hs_oauth'));
  assert.equal(back.headers.get('location'), landing);
  return cookieOf(back, 'hs_sid');
}
async function buy(sid, body) {
  const res = await (await post('/api/shop/checkout', body, sid)).json();
  assert.match(res.url ?? '', /^https:\/\/checkout\.stripe\.com\//, JSON.stringify(res));
  const id = res.url.split('/').pop();
  fakes.pay(id);
  const v = await (await post('/api/shop/verify', { sessionId: id }, sid)).json();
  assert.equal(v.paid, true);
  return id;
}

test('the website sells the bot\'s shop: fixed prices only, every option, sale prices, sold-out hidden, tabs matched', async () => {
  const s = await (await get('/api/shop/store')).json();
  assert.equal(s.preview, false);
  const byName = Object.fromEntries(s.products.map((p) => [p.name, p]));
  assert.equal(byName['Game Keys'].price, 990);
  assert.equal(byName['Game Keys'].category, 'Games', '"🎮 Games" → the Games tab');
  assert.equal(byName['Game Keys'].eta, 'Dostawa natychmiastowa', 'files/text to deliver → instant delivery on the card');
  assert.equal(byName['Game Keys'].instant, true);
  assert.equal(byName['5 Game Combo'].eta, null);
  assert.equal(byName['5 Game Combo'].art, 'bundle');
  assert.equal(byName['Netflix – 1 month'].price, 500);
  assert.equal(byName['Netflix – 3 months'].price, 1200);
  assert.equal(byName['Custom Bot'], undefined, 'no fixed price → not sold online');
  assert.equal(byName['Sold out thing'], undefined);
  assert.ok(s.products.every((p) => !('imagePath' in p) && !('delivery' in p)));
  assert.equal(
    website.plain('Want to play 1,000+ paid games? <:nox_wallet:1555685339064967370> Get access **now**. Stop overpaying <a:nox_nox:1555685296526332095> 🎮 :nox_star:'),
    'Want to play 1,000+ paid games? Get access now. Stop overpaying 🎮',
    'Discord custom emojis and markdown are left out on the website',
  );

  // A product picture shows on its card and is served by the website.
  const images = require('../src/lib/productImages');
  shop.findProduct(guild.id, keys.id).image = images.save(keys.id, { buffer: Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 1, 2, 3]), ext: 'png' });
  const withImage = (await (await get('/api/shop/store')).json()).products.find((p) => p.name === 'Game Keys');
  assert.equal(withImage.image, `/api/shop/image/${keys.id}`);
  const img = await get(withImage.image);
  assert.equal(img.status, 200);
  assert.equal(img.headers.get('content-type'), 'image/png');

  require('../src/features/flashsales').startSale(guild, combo.id, { percent: 20, durationMs: 3_600_000 });
  const sale = (await (await get('/api/shop/store')).json()).products.find((p) => p.name === '5 Game Combo');
  assert.equal(sale.price, 1200, 'the flash sale price');
});

test('signing in is all it takes: no access fee, and someone not on the server is added with the Member role', async () => {
  const memberRole = db.roleId(guild.id, 'member');
  // A newcomer: the bot adds them to the server (OAuth2 guilds.join) with the Member role.
  const newcomer = { id: '555444333222111000', username: 'fresh', global_name: 'Fresh', avatar: null };
  guild.unknownMembers = new Set([newcomer.id]);
  const sid = await signIn(newcomer, '/?connected=1&joined=1');
  const joined = guild.members.cache.get(newcomer.id);
  assert.ok(joined, 'added to the server');
  assert.ok(joined.roles.cache.has(memberRole), 'with the Member role');
  assert.deepEqual(guild.oauthJoins.at(-1), { id: newcomer.id, accessToken: 'tok', roles: [memberRole] });
  const session = await (await get('/api/shop/session', sid)).json();
  assert.equal(session.access, true, 'signed in = can buy');
  assert.equal(session.member, true);
  assert.equal((await (await get('/api/shop/store')).json()).accessPrice, null);
  assert.equal((await post('/api/shop/checkout', { kind: 'access', requestId: 'old' }, sid)).status, 409, 'there is no access pass to buy');

  // Already on the server without the role (never verified) → the role is given; signing in again changes nothing.
  const lurker = { id: '555444333222111001', username: 'lurker', global_name: null, avatar: null };
  guild.addMember(lurker.id, []);
  await signIn(lurker);
  assert.ok(guild.members.cache.get(lurker.id).roles.cache.has(memberRole));
  const joins = guild.oauthJoins.length;
  await signIn(lurker);
  assert.equal(guild.oauthJoins.length, joins, 'members are never added twice');
  fakes.state.user = { id: '111222333444555666', username: 'tester', global_name: 'Tester', avatar: null };
});

test('paid on the website → the order ticket opens on Discord, paid, and the product is delivered by DM and in the ticket', async () => {
  const sid = await signIn();

  await buy(sid, { kind: 'products', requestId: 'p-1', items: [{ id: keys.id, quantity: 1 }] });
  const ticket = db.tickets((t) => t.guildId === guild.id && t.ownerId === buyer.id).at(-1);
  assert.ok(ticket, 'an order ticket was opened');
  assert.equal(ticket.order.paidWith, 'website');
  assert.equal(ticket.order.total, 9.9);
  const channel = guild.channels.cache.get(ticket.channelId);
  const texts = channel.messageList.map((m) => textOf(m.body ?? m)).join('\n');
  assert.match(texts, /Opłacone na stronie – 9\.90€/);
  assert.doesNotMatch(texts, /## .*(?:Pay|Zapłać) 9\.90€/, 'no "Pay" card – it is paid already');
  assert.ok(guild.dms.some((d) => d.to === buyer.id && /KEY-ABC-123/.test(textOf(d.payload))), 'delivered by DM');
  const receipt = guild.dms.find((d) => d.to === buyer.id && /Zamówienie potwierdzone/.test(textOf(d.payload)));
  assert.ok(receipt, 'an order confirmation by DM');
  assert.match(textOf(receipt.payload), /Game Keys[\s\S]*Zapłacono razem: 9\.90€[\s\S]*Numer zamówienia `HS-[0-9A-F]{10}`/);
  assert.equal(fakes.state.lastCheckout.get('submit_type'), 'pay');
  assert.match(fakes.state.lastCheckout.get('custom_text[submit][message]'), /prywatnym tickecie na Discordzie HammerShop/);
  assert.equal(fakes.state.lastCheckout.get('line_items[0][price_data][product_data][description]'), 'Dostawa natychmiastowa · na Discordzie');
  assert.ok(db.getTicket(ticket.channelId).completedAt, 'completed like any paid Discord order');

  const order = (await (await get('/api/shop/orders', sid)).json()).orders[0];
  assert.match(order.delivery, /^Dostarczone! Twój produkt czeka w tickecie #\d{4} na Discordzie HammerShop i w Twoich wiadomościach prywatnych\.$/);
  assert.equal(order.delivered, true);
  assert.equal(order.ticketNumber, String(ticket.number).padStart(4, '0'));
  assert.equal(order.ticketUrl, `https://discord.com/channels/${guild.id}/${ticket.channelId}`, 'the receipt links straight to the ticket');
});

test('a cart with options: one ticket for everything, staff pinged for what isn\'t automatic', async () => {
  const sid = await signIn();
  const before = db.tickets((t) => t.ownerId === buyer.id).length;
  await buy(sid, { kind: 'products', requestId: 'p-2', items: [{ id: `${netflix.id}~${shop.variantsOf(shop.findProduct(guild.id, netflix.id))[1].id}`, quantity: 2 }, { id: combo.id, quantity: 1 }] });
  const tickets = db.tickets((t) => t.ownerId === buyer.id);
  assert.equal(tickets.length, before + 1);
  const t = tickets.at(-1);
  assert.equal(t.order.items.length, 2);
  assert.equal(t.order.items[0].product, 'Netflix — 3 months');
  assert.equal(t.order.items[0].quantity, 2);
  assert.equal(t.order.total, 24 + 12);
  assert.equal(t.order.status, 'paid');
});

test('the bot couldn\'t add them (no Create Invite permission): signing in still works, the order waits until they join', async () => {
  const stranger = { id: '999888777666555444', username: 'newbie', global_name: 'Newbie', avatar: null };
  guild.unknownMembers = new Set([stranger.id]);
  guild.deny('CreateInstantInvite');
  const sid = await signIn(stranger);
  guild.deniedPermissions.delete('CreateInstantInvite');
  assert.equal((await (await get('/api/shop/session', sid)).json()).member, false);
  await buy(sid, { kind: 'products', requestId: 's-1', items: [{ id: keys.id, quantity: 1 }] });
  let order = (await (await get('/api/shop/orders', sid)).json()).orders.find((o) => o.kind === 'products');
  assert.match(order.delivery, /Dołącz do serwera HammerShop na Discordzie/);
  assert.equal(order.waiting, true);
  assert.equal(db.tickets((t) => t.ownerId === stranger.id).length, 0);

  guild.unknownMembers.delete(stranger.id);
  const member = guild.addMember(stranger.id, [db.roleId(guild.id, 'member')]);
  await hooks.emit('memberAdd', member);
  assert.equal(db.tickets((t) => t.ownerId === stranger.id).length, 1, 'the ticket opened on join');
  order = (await (await get('/api/shop/orders', sid)).json()).orders.find((o) => o.kind === 'products');
  assert.match(order.delivery, /tickecie #\d{4}/);
  assert.equal(order.waiting, false);
  fakes.state.user = { id: '111222333444555666', username: 'tester', global_name: 'Tester', avatar: null };
});

test('the Stripe webhook hands the order to the bot too – once, even if the buyer also comes back', async () => {
  const sid = await signIn();
  const res = await (await post('/api/shop/checkout', { kind: 'products', requestId: 'wh-1', items: [{ id: combo.id, quantity: 1 }] }, sid)).json();
  const id = res.url.split('/').pop();
  const session = fakes.pay(id);
  const before = db.tickets((t) => t.ownerId === buyer.id).length;
  const raw = JSON.stringify({ type: 'checkout.session.completed', data: { object: session } });
  const t = Math.floor(Date.now() / 1000);
  const sig = crypto.createHmac('sha256', 'whsec_test').update(`${t}.${raw}`).digest('hex');
  const ok = await fetch(`${base}/api/shop/stripe/webhook`, { method: 'POST', headers: { 'stripe-signature': `t=${t},v1=${sig}` }, body: raw });
  assert.equal(ok.status, 200);
  await post('/api/shop/verify', { sessionId: id }, sid);
  assert.equal(db.tickets((x) => x.ownerId === buyer.id).length, before + 1, 'one ticket');
});

test('safety: prices from the shop, foreign sites refused, no session → 401, files stay inside web/public', async () => {
  const sid = await signIn();
  await post('/api/shop/checkout', { kind: 'products', requestId: 'cap', items: [{ id: keys.id, quantity: 99, price: 1 }] }, sid);
  assert.equal(fakes.state.lastCheckout.get('line_items[0][quantity]'), '10');
  assert.equal(fakes.state.lastCheckout.get('line_items[0][price_data][unit_amount]'), '990');
  assert.equal((await post('/api/shop/checkout', { kind: 'products', items: [{ id: keys.id, quantity: 1 }] }, sid, { origin: 'https://evil.example' })).status, 403);
  assert.equal((await post('/api/shop/checkout', { kind: 'products', items: [{ id: keys.id, quantity: 1 }] })).status, 401);
  assert.match(await (await get('/')).text(), /<title>HammerShop/);
  assert.doesNotMatch(await (await get('/..%2F..%2Fsrc%2Fenv.js')).text(), /webSettings/);
});

function playwright() {
  for (const p of ['playwright', '/opt/node22/lib/node_modules/playwright', '/usr/local/lib/node_modules/playwright', '/usr/lib/node_modules/playwright']) {
    try {
      return require(p);
    } catch {
      // next
    }
  }
  return null;
}
const pw = playwright();

test('the real page in a browser: bag → sign in → checkout → Stripe → receipt with the ticket, no errors', { skip: !pw && 'Playwright is not installed' }, async () => {
  const fs = require('node:fs');
  const browser = await pw.chromium.launch(fs.existsSync('/opt/pw-browsers/chromium') ? { executablePath: '/opt/pw-browsers/chromium' } : {});
  const page = await (await browser.newContext({ viewport: { width: 1366, height: 900 } })).newPage();
  const problems = [];
  page.on('pageerror', (e) => problems.push(`pageerror: ${e.message}`));
  page.on('console', (m) => m.type() === 'error' && problems.push(`console: ${m.text()}`));
  // Like a plain http://IP:port site: no crypto.randomUUID (browsers only give it on https / localhost).
  await page.addInitScript(() => Object.defineProperty(Object.getPrototypeOf(globalThis.crypto), 'randomUUID', { value: undefined, configurable: true }));
  await page.route((u) => u.hostname === 'checkout.stripe.com', (route) => route.fulfill({ status: 200, contentType: 'text/html', body: '<h1>Stripe</h1>' }));
  try {
    await page.goto(base);
    await page.waitForSelector('text=Game Keys');
    if (process.env.HS_SHOTS) await page.screenshot({ path: `${process.env.HS_SHOTS}/home.png` });
    assert.equal(await page.locator('text=PODGLĄD OFFLINE').count(), 0);
    assert.equal(await page.locator('text=/access pass|access fee unlocks|Activate my access|karta dostępu|opłata za dostęp odblokowuje|Aktywuj mój dostęp/i').count(), 0, 'no paid access anywhere');
    // The bag works before signing in; checkout asks for Discord, and the bag is still there afterwards.
    await page.locator('article.product', { hasText: 'Game Keys' }).getByRole('button', { name: 'Do koszyka' }).click();
    await page.getByRole('button', { name: /Otwórz koszyk, 1 produkt$/ }).click();
    await page.getByRole('button', { name: /Zaloguj się przez Discord, aby zamówić/ }).click();
    await page.getByRole('link', { name: /Kontynuuj z Discordem/ }).click();
    await page.waitForSelector('text=Twój koszyk', { timeout: 10_000 });
    await Promise.all([page.waitForURL(/checkout\.stripe\.com/), page.getByRole('button', { name: /Przejdź do płatności/ }).click()]);
    const sessionId = page.url().split('/').pop();
    fakes.pay(sessionId);
    await page.goto(`${base}/?payment=return&session_id=${sessionId}`);
    await page.waitForSelector('text=Dziękujemy, Tester.');
    await page.waitForSelector('text=PŁATNOŚĆ POTWIERDZONA');
    const ticketLink = page.getByRole('link', { name: /Otwórz ticket #\d{4}/ });
    assert.match(await ticketLink.getAttribute('href'), new RegExp(`^https://discord\\.com/channels/${guild.id}/\\d+$`));
    await page.waitForSelector('text=Dostarczone');
    if (process.env.HS_SHOTS) {
      await page.screenshot({ path: `${process.env.HS_SHOTS}/receipt-desktop.png` });
      await page.setViewportSize({ width: 390, height: 844 });
      await page.screenshot({ path: `${process.env.HS_SHOTS}/receipt-phone.png`, fullPage: false });
      await page.setViewportSize({ width: 1366, height: 900 });
    }
    await page.getByRole('button', { name: 'Moje zamówienia' }).last().click();
    await page.locator('.order-top b', { hasText: 'DOSTARCZONE' }).first().waitFor();
    assert.ok(await page.getByRole('link', { name: /Otwórz ticket #\d{4}/ }).first().isVisible(), 'My orders links to the ticket too');
    if (process.env.HS_SHOTS) {
      await page.screenshot({ path: `${process.env.HS_SHOTS}/orders.png` });
      await page.keyboard.press('Escape');
      await page.getByRole('button', { name: 'Tester' }).click();
      await page.waitForSelector('text=/należysz do Discorda HammerShop z rolą Członek/');
      await page.waitForTimeout(400);
      await page.screenshot({ path: `${process.env.HS_SHOTS}/account.png` });
      await page.keyboard.press('Escape');
      await page.locator('#how').scrollIntoViewIfNeeded();
      await page.screenshot({ path: `${process.env.HS_SHOTS}/how.png` });
    }
    // The "My orders" button in the Discord DM: /?view=orders opens My orders.
    await page.goto(`${base}/?view=orders`);
    await page.locator('.order-top b', { hasText: 'DOSTARCZONE' }).first().waitFor();
    assert.deepEqual(problems, []);
  } finally {
    await browser.close();
  }
});
