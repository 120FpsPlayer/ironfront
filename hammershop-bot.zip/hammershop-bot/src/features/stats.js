'use strict';

const config = require('../lib/config');
const db = require('../lib/db');
const panels = require('../lib/panels');
const { e, COLORS } = require('../lib/theme');
const { ts, plural } = require('../lib/utils');
const { container, text, divider, header, v2 } = require('../lib/v2');
const { channelName, sameChannelName } = require('../builder/style');

/**
 * Server stats: locked voice channels showing the member and vouch count, plus an
 * activity leaderboard (messages this week / all time) in #ranking.
 */

const WEEK = 7 * 86_400_000;
/** Week number, weeks start on Monday 00:00 UTC. */
const weekKey = (t = Date.now()) => Math.floor((t + 3 * 86_400_000) / WEEK);
const weekEnds = (key) => (key + 1) * WEEK - 3 * 86_400_000;

const STAT_NAMES = {
  statMembers: (n) => channelName(`👥 Członkowie: ${n.toLocaleString('en-US')}`),
  statVouches: (n) => channelName(`⭐ Opinie: ${n.toLocaleString('en-US')}`),
};

function trackMessage(message) {
  if (!message.guild || message.author.bot) return;
  if (db.getTicket(message.channel.id)) return; // ticket chats don't count
  const a = db.guild(message.guild.id).activity;
  const key = weekKey();
  if (a.weekKey !== key) {
    a.weekKey = key;
    a.week = {};
  }
  a.total[message.author.id] = (a.total[message.author.id] ?? 0) + 1;
  a.week[message.author.id] = (a.week[message.author.id] ?? 0) + 1;
  db.save();
}

function top(map, n = 10) {
  return Object.entries(map ?? {})
    .sort((x, y) => y[1] - x[1])
    .slice(0, n);
}

function leaderboardPanel(guild) {
  const a = db.guild(guild.id).activity;
  const key = weekKey();
  const week = a.weekKey === key ? a.week : {};
  const medal = (i) => ['🥇', '🥈', '🥉'][i] ?? `\`${String(i + 1).padStart(2, ' ')}.\``;
  const list = (entries) => (entries.length ? entries.map(([id, n], i) => `${medal(i)} <@${id}> – **${n.toLocaleString('en-US')}** ${plural(n, 'wiadomość', 'wiadomości', 'wiadomości')}`).join('\n') : '*Jeszcze nikogo – zacznij pisać!*');

  const c = container(COLORS.brand);
  header(c, `# ${e(guild, 'trophy')} Ranking\nNajaktywniejsi członkowie **${config.brand.name}**. Pisz, pomagaj innym i wspinaj się w rankingu!`, guild.iconURL?.({ size: 256 }));
  c.addSeparatorComponents(divider());
  c.addTextDisplayComponents(text(`### ${e(guild, 'flame')} Ten tydzień\n${list(top(week))}\n-# Wyniki zerują się ${ts(weekEnds(key), 'R')}`));
  c.addSeparatorComponents(divider());
  c.addTextDisplayComponents(text(`### ${e(guild, 'crown')} Od początku\n${list(top(a.total))}`));
  c.addSeparatorComponents(divider());
  c.addTextDisplayComponents(text(`-# Zaktualizowano ${ts(Date.now(), 'R')} · Wiadomości w ticketach i boty się nie liczą.`));
  return v2(c);
}

panels.register('leaderboard', (guild) => leaderboardPanel(guild));

/** The names the stat channels should have right now. */
function statNames(guild) {
  const names = {
    statMembers: STAT_NAMES.statMembers(guild.memberCount ?? 0),
    statVouches: STAT_NAMES.statVouches(db.guild(guild.id).vouches.length),
  };
  const shop = require('./shopstatus').statusChannelName(guild.id);
  if (shop) names.statShop = shop;
  return names;
}

async function updateStatChannels(client) {
  for (const guildId of db.allGuildIds()) {
    const guild = client.guilds.cache.get(guildId);
    if (!guild) continue;
    for (const [key, name] of Object.entries(statNames(guild))) {
      const channel = guild.channels.cache.get(db.channelId(guildId, key) ?? '');
      if (!channel) continue;
      // Discord allows 2 renames per 10 minutes per channel – this runs every 10 minutes at most.
      if (!sameChannelName(channel.name, name)) await channel.setName(name, 'Aktualizacja statystyk').catch(() => null);
    }
  }
}

module.exports = { weekKey, STAT_NAMES, statNames, trackMessage, leaderboardPanel, updateStatChannels, top };
