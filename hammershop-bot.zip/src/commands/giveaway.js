'use strict';

const { SlashCommandBuilder, InteractionContextType, ChannelType, MessageFlags, PermissionFlagsBits } = require('discord.js');
const giveaways = require('../features/giveaways');
const invites = require('../features/invites');
const { COLORS } = require('../lib/theme');
const { embed, reply, replyError, parseDuration, ts, truncate, count } = require('../lib/utils');
const { slash } = require('../lib/commandsPl');
const { isMod } = require('../lib/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('giveaway')
    .setDescription('Run giveaways (moderators)')
    .setContexts(InteractionContextType.Guild)
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addSubcommand((s) =>
      s
        .setName('start')
        .setDescription('Start a giveaway')
        .addStringOption((o) => o.setName('prize').setDescription('What can people win?').setRequired(true).setMaxLength(120))
        .addStringOption((o) => o.setName('duration').setDescription('How long? e.g. 30m, 2h, 1d, 1w, 1d12h').setRequired(true).setMaxLength(20))
        .addIntegerOption((o) => o.setName('winners').setDescription('Number of winners (default 1)').setMinValue(1).setMaxValue(20))
        .addStringOption((o) => o.setName('description').setDescription('Extra info shown on the giveaway').setMaxLength(600))
        .addChannelOption((o) => o.setName('channel').setDescription('Channel (default: #giveaways)').addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement))
        .addRoleOption((o) => o.setName('required_role').setDescription('Only members with this role can enter'))
        .addBooleanOption((o) => o.setName('buyers_only').setDescription('Only customers (at least one completed order) can enter'))
        .addIntegerOption((o) =>
          o.setName('min_invites').setDescription('Only members who invited at least this many members (still on the server)').setMinValue(1).setMaxValue(100),
        )
        .addBooleanOption((o) => o.setName('ping').setDescription('Ping the Giveaways role? (default: yes)'))
        // The AI assistant hands out a Hammer+ prize by itself when it knows how long it is (src/features/ai/prizes.js).
        .addIntegerOption((o) => o.setName('plus_days').setDescription('The prize is Hammer+? For how many days (0 = forever)').setMinValue(0).setMaxValue(3650)),
    )
    .addSubcommand((s) =>
      s
        .setName('end')
        .setDescription('End a giveaway now')
        .addStringOption((o) => o.setName('giveaway').setDescription('Giveaway').setRequired(true).setAutocomplete(true)),
    )
    .addSubcommand((s) =>
      s
        .setName('reroll')
        .setDescription('Draw new winner(s) for an ended giveaway')
        .addStringOption((o) => o.setName('giveaway').setDescription('Giveaway').setRequired(true).setAutocomplete(true))
        .addIntegerOption((o) => o.setName('winners').setDescription('How many new winners (default 1)').setMinValue(1).setMaxValue(20)),
    )
    .addSubcommand((s) => s.setName('list').setDescription('Active and recent giveaways')),

  autocomplete(interaction) {
    const sub = interaction.options.getSubcommand();
    return giveaways.autocomplete(interaction, { active: sub === 'end' ? true : sub === 'reroll' ? false : null });
  },

  async execute(interaction) {
    if (!isMod(interaction.member)) return replyError(interaction, 'Giveawaye mogą prowadzić tylko moderatorzy i administratorzy.');
    const o = interaction.options;
    const sub = o.getSubcommand();
    const guild = interaction.guild;

    if (sub === 'start') {
      const durationMs = parseDuration(o.getString('duration'));
      if (!durationMs) return replyError(interaction, 'Nieprawidłowy czas. Przykłady: `30m`, `2h`, `1d`, `1w`, `1d12h`.');
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const { gw, message } = await giveaways.start(guild, interaction.member, {
        prize: o.getString('prize'),
        durationMs,
        winners: o.getInteger('winners') ?? 1,
        description: o.getString('description'),
        channel: o.getChannel('channel'),
        requiredRole: o.getRole('required_role'),
        buyersOnly: o.getBoolean('buyers_only') ?? false,
        minInvites: o.getInteger('min_invites'),
        ping: o.getBoolean('ping') ?? true,
        plusDays: o.getInteger('plus_days'),
      });
      // Without Manage Server new joins have no inviter – min_invites would only count the invites from before.
      const blind = gw.minInvites && !invites.isReadable(guild.id) ? '\n⚠️ Nie widzę zaproszeń tego serwera (potrzebuję uprawnienia **Zarządzanie serwerem**) – do czasu naprawy nowe zaproszenia nie są liczone.' : '';
      return reply(interaction, `Giveaway z nagrodą **${gw.prize}** wystartował na <#${gw.channelId}> – kończy się ${ts(gw.endsAt, 'R')}. [Przejdź](${message.url})${blind}`);
    }

    if (sub === 'end' || sub === 'reroll') {
      const gw = giveaways.find(guild.id, o.getString('giveaway'));
      if (!gw) return replyError(interaction, 'Nie ma takiego giveawayu. Wybierz jeden z listy podpowiedzi.');
      if (sub === 'end' && gw.ended) return replyError(interaction, `Ten giveaway już się zakończył – użyj \`${slash('giveaway reroll')}\`, żeby wylosować nowego zwycięzcę.`);
      if (sub === 'reroll' && !gw.ended) return replyError(interaction, 'Ten giveaway wciąż trwa – najpierw go zakończ.');
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const winners = await giveaways.end(guild, gw, { reroll: sub === 'reroll', count: sub === 'reroll' ? o.getInteger('winners') ?? 1 : null });
      return reply(interaction, winners.length ? `${winners.length > 1 ? 'Zwycięzcy' : 'Zwycięzca'}: ${winners.map((id) => `<@${id}>`).join(', ')}` : 'Brak ważnych zgłoszeń – nie udało się nikogo wylosować.');
    }

    const list = giveaways.all(guild.id).sort((a, b) => b.createdAt - a.createdAt).slice(0, 15);
    const lines = list.map((g) => `${g.ended ? '✅' : '🎉'} **${truncate(g.prize, 60)}** – ${count(g.entries.length, 'uczestnik', 'uczestników', 'uczestników')} · ${g.ended ? 'zakończony' : 'koniec'} ${ts(g.endsAt, 'R')} · <#${g.channelId}>`);
    return reply(interaction, { embeds: [embed(COLORS.brand).setTitle('🎉 Giveawaye').setDescription(lines.join('\n') || `Nie ma jeszcze giveawayów – zacznij od \`${slash('giveaway start')}\`.`)] });
  },
};
